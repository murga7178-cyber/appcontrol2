plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.appcontrol"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.appcontrol"
        minSdk = 29
        targetSdk = 34
        // GitHub Actions में हर बिल्ड पर नंबर बढ़ता है (अपडेट के लिए ज़रूरी); लोकल में 1
        versionCode = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()
        versionName = "1.0"
    }
    // हर बिल्ड में एक ही पक्की साइनिंग-की: इसी से नया APK पुराने पर अपडेट होता है (अनइंस्टॉल नहीं करना पड़ता)
    signingConfigs {
        create("fixed") {
            storeFile = file("appcontrol.keystore")
            storePassword = "appcontrol123"
            keyAlias = "appcontrol"
            keyPassword = "appcontrol123"
        }
    }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("fixed") }
        getByName("release") { signingConfig = signingConfigs.getByName("fixed") }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")
}
