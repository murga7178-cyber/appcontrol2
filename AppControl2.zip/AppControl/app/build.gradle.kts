plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.appcontrol"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.appcontrol"
        minSdk = 29
        targetSdk = 34
        // हर बिल्ड पर अपने-आप बढ़ता है, ताकि नया APK पुराने के ऊपर अपडेट हो सके
        versionCode = (System.currentTimeMillis() / 60000L).toInt()
        versionName = "1.1"
    }
    // हर कंप्यूटर/बिल्ड पर एक ही साइनिंग की (key) — तभी अपडेट बिना डिलीट किए चढ़ता है
    signingConfigs {
        create("fixed") {
            storeFile = file("appcontrol.keystore")
            storePassword = "appcontrol123"
            keyAlias = "appcontrol"
            keyPassword = "appcontrol123"
        }
    }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("fixed") }
        getByName("release") { signingConfig = signingConfigs.getByName("fixed") }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")
    // बटन के अंदर लिखे अक्षर पढ़ने के लिए (फोन पर ही, बिना इंटरनेट): अंग्रेज़ी/नंबर + हिंदी (देवनागरी)
    implementation("com.google.mlkit:text-recognition:16.0.0")
    implementation("com.google.mlkit:text-recognition-devanagari:16.0.0")
    implementation("com.google.android.gms:play-services-tasks:18.0.2")
}
