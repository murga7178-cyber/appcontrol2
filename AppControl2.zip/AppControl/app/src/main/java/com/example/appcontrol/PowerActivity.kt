package com.example.appcontrol

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import rikka.shizuku.Shizuku

class PowerActivity : ToolPage() {
    private val permListener = Shizuku.OnRequestPermissionResultListener { _, r ->
        toast(if (r == PackageManager.PERMISSION_GRANTED) "Shizuku की अनुमति मिल गई" else "अनुमति नहीं मिली")
        render()
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        try { Shizuku.addRequestPermissionResultListener(permListener) } catch (e: Throwable) {}
        render()
    }

    override fun onDestroy() {
        try { Shizuku.removeRequestPermissionResultListener(permListener) } catch (e: Throwable) {}
        super.onDestroy()
    }

    private fun render() {
        page("⚡ पावर टूल्स (Shizuku / Root)")
        val connected = Shell.rootGranted || Shell.shizukuReady()
        val st = when {
            Shell.rootGranted -> "Root जुड़ा है ✅"
            Shell.shizukuReady() -> "Shizuku जुड़ा है ✅"
            else -> "अभी Root या Shizuku जुड़ा नहीं है"
        }
        box.addView(tv(st, 16f))
        box.addView(btn("🔥 Root जाँचें (Magisk/KernelSU में Allow दबाएँ)") {
            Shell.su("id") { r ->
                Shell.rootGranted = r.contains("uid=0")
                if (!Shell.rootGranted) toast("Root नहीं मिला। ($r)")
                render()
            }
        })
        if (!Shell.shizukuReady()) {
            if (Shell.shizukuAlive()) {
                box.addView(btn("⚡ Shizuku की अनुमति दें") { Shizuku.requestPermission(1) })
            } else {
                box.addView(tv(
                    if (Build.VERSION.SDK_INT >= 30)
                        "Shizuku चालू नहीं है।\n1) Shizuku ऐप इंस्टॉल करें\n2) Developer options में Wireless debugging चालू करें\n3) Shizuku में 'Start via Wireless debugging' करें\n4) फिर यहाँ वापस आएँ"
                    else
                        "Shizuku चालू नहीं है।\nAndroid 10 पर Shizuku को कंप्यूटर से USB के ज़रिए ADB कमांड देकर चालू करना पड़ता है (Shizuku ऐप में 'Start via computer' की गाइड देखें), फिर यहाँ वापस आएँ।", 13f))
            }
        }
        if (!connected) return

        val out = tv("", 13f)
        fun go(cmd: String) {
            out.text = "चल रहा है... (थोड़ा समय लग सकता है)"
            Shell.best(cmd) { out.text = if (it.isBlank()) "हो गया ✅" else it }
        }
        val cacheCmd = if (Shell.rootGranted)
            "rm -rf /data/data/*/cache/* /data/data/*/code_cache/* /sdcard/Android/data/*/cache/*"
        else "pm trim-caches 999G"
        box.addView(btn("🧹 कैश साफ (कैश कंट्रोल के नियमों से)") {
            out.text = "चल रहा है..."
            CachePolicy.clear(this) { out.text = it }
        })
        box.addView(btn("🛠 कैश कंट्रोल खोलें (चालू/बंद, ऐप छोड़ें)") { startActivity(Intent(this, CacheActivity::class.java)) })
        box.addView(btn("🛑 सारे बैकग्राउंड ऐप्स बंद") { go("am kill-all") })
        box.addView(btn("⚙️ ऐप्स ऑप्टिमाइज़ (चार्जिंग पर, समय लगेगा)") { go("cmd package compile -m speed-profile -a") })
        if (Shell.rootGranted) {
            box.addView(btn("💾 रैम कैश खाली (root)") { go("sync; echo 3 > /proc/sys/vm/drop_caches") })
            box.addView(btn("✂️ TRIM (स्टोरेज तेज़, root)") { go("fstrim -v /data; fstrim -v /cache") })
        }
        box.addView(btn("🗑️ सिस्टम ऐप्स बंद / हटाएँ") { startActivity(Intent(this, SystemAppsActivity::class.java)) })
        box.addView(out)
    }
}
