package com.example.appcontrol

import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.text.format.Formatter
import android.widget.*
import rikka.shizuku.Shizuku

/** Root / Shizuku से कमांड चलाने वाला हिस्सा */
object Shell {
    val h = Handler(Looper.getMainLooper())
    var rootGranted = false

    fun shizukuAlive() = try { Shizuku.pingBinder() } catch (e: Throwable) { false }
    fun shizukuReady() = shizukuAlive() &&
        try { Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED } catch (e: Throwable) { false }

    private fun exec(make: () -> Process, done: (String) -> Unit) {
        Thread {
            val out = try {
                val p = make()
                val t = p.inputStream.bufferedReader().readText() + p.errorStream.bufferedReader().readText()
                p.waitFor(); t.trim()
            } catch (e: Throwable) { "त्रुटि: ${e.message}" }
            h.post { done(out) }
        }.start()
    }

    // newProcess नए Shizuku API में private है, इसलिए reflection
    fun shizuku(cmd: String, done: (String) -> Unit) = exec({
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        ).apply { isAccessible = true }
        m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
    }, done)

    fun su(cmd: String, done: (String) -> Unit) =
        exec({ Runtime.getRuntime().exec(arrayOf("su", "-c", cmd)) }, done)

    /** Root हो तो root से, वरना Shizuku से; कुछ नहीं जुड़ा तो false */
    fun best(cmd: String, done: (String) -> Unit): Boolean {
        return when {
            rootGranted -> { su(cmd, done); true }
            shizukuReady() -> { shizuku(cmd, done); true }
            else -> false
        }
    }

    private var triedRoot = false
    private var askedShizuku = false

    /** ऐप खुलते ही अपने-आप Root/Shizuku जोड़ने की कोशिश (हर बार नहीं, एक बार) */
    fun autoConnect(onChange: () -> Unit) {
        if (!rootGranted && !triedRoot) {
            triedRoot = true
            su("id") { r ->
                if (r.contains("uid=0")) rootGranted = true
                onChange()
                askShizuku(onChange)
            }
        } else askShizuku(onChange)
    }

    private fun askShizuku(onChange: () -> Unit) {
        if (!rootGranted && !askedShizuku && shizukuAlive() && !shizukuReady()) {
            askedShizuku = true
            try { Shizuku.requestPermission(7) } catch (e: Throwable) {}
        }
        onChange()
    }

    /** RAM खाली करने के लिए बैकग्राउंड ऐप्स बंद करो, फिर done() */
    fun boost(ctx: Context, keep: Set<String> = emptySet(), done: () -> Unit) {
        // Root हो तो बैकग्राउंड ऐप्स बंद + रैम कैश भी खाली; Shizuku हो तो बैकग्राउंड ऐप्स बंद
        val cmd = if (rootGranted) "am kill-all; sync; echo 3 > /proc/sys/vm/drop_caches" else "am kill-all"
        // कैश साफ करना तभी, जब आपने स्विच चालू रखा हो और 'बूस्ट के साथ' चुना हो
        val after = {
            if (CachePolicy.enabled(ctx) && CachePolicy.withBoost(ctx)) CachePolicy.clear(ctx) { done() } else done()
        }
        if (best(cmd) { after() }) return
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        ctx.packageManager.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        ).map { it.activityInfo }
            .filter { (it.applicationInfo.flags and ApplicationInfo.FLAG_SYSTEM) == 0 &&
                it.packageName != ctx.packageName && it.packageName !in keep }
            .map { it.packageName }.distinct()
            .forEach { am.killBackgroundProcesses(it) }
        after()
    }
}

/** सारे नए पेजों का आधार: स्क्रॉल + नीचे खाली जगह + वापस बटन */
abstract class ToolPage : Activity() {
    protected lateinit var box: LinearLayout

    protected fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    protected fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; isAllCaps = false; setOnClickListener { f() } }
    protected fun tv(t: String, size: Float = 14f) = TextView(this).apply { text = t; textSize = size }
    protected fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    protected fun fmt(n: Long): String = Formatter.formatFileSize(this, n)

    protected fun page(title: String) {
        val sv = ScrollView(this)
        box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(40), dp(14), dp(180))   // नीचे जगह, ताकि आख़िरी ऑप्शन तक स्क्रॉल हो
        }
        sv.addView(box)
        setContentView(sv)
        box.addView(btn("← वापस") { finish() })
        box.addView(tv(title, 20f).apply { setTextColor(Color.BLACK) })
    }
}

/** कैश साफ करने के नियम: चालू/बंद स्विच, बूस्ट के साथ चलाना, और छोड़ी जाने वाली ऐप्स */
object CachePolicy {
    fun prefs(c: Context) = c.getSharedPreferences("apps", Context.MODE_PRIVATE)
    fun enabled(c: Context) = prefs(c).getBoolean("cacheOn", true)
    fun withBoost(c: Context) = prefs(c).getBoolean("cacheWithBoost", false)   // शुरू में बंद
    fun keep(c: Context): Set<String> =
        prefs(c).getString("cacheKeep", "")!!.split("\n").filter { it.isNotBlank() }.toSet()
    fun saveKeep(c: Context, s: Set<String>) =
        prefs(c).edit().putString("cacheKeep", s.joinToString("\n")).apply()

    /** नियमों के हिसाब से कैश साफ करो; नतीजे का मैसेज done में */
    fun clear(c: Context, done: (String) -> Unit) {
        if (!enabled(c)) { done("कैश साफ करना बंद है (कैश कंट्रोल में स्विच चालू करें)"); return }
        val keep = keep(c)
        when {
            Shell.rootGranted -> {
                val pat = if (keep.isEmpty()) "__none__" else keep.joinToString("|")
                // § की जगह बाद में $ लगता है (Kotlin में $ टेम्पलेट बन जाता)
                val sc = ("for d in /data/data/*; do n=§{d##*/}; case \"§n\" in $pat) ;; *) rm -rf \"§d\"/cache/* \"§d\"/code_cache/*;; esac; done; " +
                    "for d in /sdcard/Android/data/*; do n=§{d##*/}; case \"§n\" in $pat) ;; *) rm -rf \"§d\"/cache/*;; esac; done").replace("§", "$")
                Shell.su(sc) { done("कैश साफ ✅ (${keep.size} ऐप छोड़ीं)") }
            }
            Shell.shizukuReady() -> {
                if (keep.isNotEmpty()) done("Shizuku से चुनिंदा ऐप छोड़कर कैश साफ नहीं हो सकता (सिर्फ़ सब का एक साथ)। छोड़ी हुई सूची खाली करें, या Root इस्तेमाल करें।")
                else Shell.shizuku("pm trim-caches 999G") { done("कैश साफ ✅") }
            }
            else -> done("पहले Root या Shizuku जोड़ें")
        }
    }
}
