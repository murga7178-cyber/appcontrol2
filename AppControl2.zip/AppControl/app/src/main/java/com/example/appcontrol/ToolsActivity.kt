package com.example.appcontrol

import android.app.ActivityManager
import android.content.Intent
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.widget.*

class ToolsActivity : ToolPage() {
    private lateinit var status: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        page("🧰 फोन बूस्ट / क्लीन टूल्स")
        status = tv("", 15f)
        box.addView(status)
        fun open(c: Class<*>) = startActivity(Intent(this, c))
        box.addView(btn("🧹 जंक / बड़ी फाइलें साफ करें") { open(CleanActivity::class.java) })
        box.addView(btn("🧹 कैश कंट्रोल (चालू / बंद, ऐप छोड़ें)") { open(CacheActivity::class.java) })
        box.addView(btn("⚡ पावर टूल्स (Shizuku / Root)") { open(PowerActivity::class.java) })
        box.addView(btn("🗑️ सिस्टम ऐप्स बंद / हटाएँ") { open(SystemAppsActivity::class.java) })
        val prefs = getSharedPreferences("apps", MODE_PRIVATE)
        box.addView(Switch(this).apply {
            text = "🚀 ऐप चलाने से पहले अपने-आप बूस्ट (RAM खाली)"
            isChecked = prefs.getBoolean("boostBefore", true)
            setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("boostBefore", c).apply() }
        })
        val gl = tv("", 14f)
        fun gateTxt(v: Int) { gl.text = "📸 स्क्रीनशॉट मिलान: $v% (ज़्यादा = एकदम हूबहू चाहिए, कम = थोड़ा फ़र्क चलेगा)" }
        gateTxt(prefs.getInt("gatePct", 90))
        box.addView(gl)
        box.addView(SeekBar(this).apply {
            max = 29; progress = prefs.getInt("gatePct", 90) - 70      // 70% से 99%
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    gateTxt(p + 70); prefs.edit().putInt("gatePct", p + 70).apply()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
        box.addView(tv("App Control की ऐप सूची ही आपका बूस्ट फोल्डर है। उसमें + से जो ऐप जोड़ेंगे, उन्हें चलाने (ऐप दबाने या 'सभी ऐप चलाएँ') से पहले बैकग्राउंड ऐप्स बंद होंगे और RAM खाली होगी। बेहतर असर के लिए ⚡ पावर टूल्स में Root या Shizuku जोड़ें।", 12f))
    }

    override fun onResume() {
        super.onResume()
        val st = StatFs(Environment.getExternalStorageDirectory().path)
        val mi = ActivityManager.MemoryInfo()
        (getSystemService(ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        status.text = "स्टोरेज इस्तेमाल: ${fmt(st.totalBytes - st.availableBytes)} / ${fmt(st.totalBytes)}\n" +
            "RAM खाली: ${fmt(mi.availMem)} / ${fmt(mi.totalMem)}"
    }
}
