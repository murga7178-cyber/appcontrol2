package com.example.appcontrol

import android.content.Context
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter

/** क्रैश/त्रुटि की वजह फ़ोन में सेव: ऐप खोलने पर दिखती है, ताकि पता चले कि कहाँ और क्यों रुका */
object CrashLog {
    private var installed = false

    fun file(c: Context) = File(c.applicationContext.filesDir, "crash.txt")

    fun write(c: Context, where: String, t: Throwable) {
        try {
            val sw = StringWriter(); t.printStackTrace(PrintWriter(sw))
            val f = file(c)
            val old = if (f.exists()) f.readText() else ""
            val stamp = java.text.SimpleDateFormat("dd MMM HH:mm:ss", java.util.Locale.US).format(java.util.Date())
            f.writeText(("[$stamp] $where\n" + sw.toString().take(3500) + "\n\n" + old).take(12000))
        } catch (e: Throwable) { }
    }

    fun read(c: Context): String? = try { file(c).takeIf { it.exists() }?.readText()?.takeIf { it.isNotBlank() } } catch (e: Throwable) { null }

    fun clear(c: Context) { try { file(c).delete() } catch (e: Throwable) { } }

    fun install(c: Context) {
        if (installed) return
        installed = true
        val app = c.applicationContext
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { th, e ->
            write(app, "क्रैश (${th.name})", e)
            prev?.uncaughtException(th, e)
        }
    }
}
