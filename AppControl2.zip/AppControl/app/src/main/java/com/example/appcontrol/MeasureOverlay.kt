package com.example.appcontrol

import android.accessibilityservice.AccessibilityService
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

/**
 * "📏 जगह नापो": दूसरे ऐप के ऊपर लाल क्रॉस रेखा आती है. उसे उंगली से बटन पर ले जाओ,
 * ऊपर की पट्टी में उसी जगह की  POS:x,y  (स्क्रीन का %) लिखी दिखेगी. "कॉपी" दबाकर कमांड में चिपका दो.
 * दो अलग विंडो: पूरी स्क्रीन की क्रॉस-विंडो (छूना चालू/बंद हो सकता है) + छोटी पट्टी (हमेशा छूने लायक).
 */
class MeasureOverlay(private val svc: AccessibilityService, private val onClose: () -> Unit) {
    private val wm = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var cross: View? = null
    private var panel: LinearLayout? = null
    private var label: TextView? = null
    private var modeBtn: Button? = null
    private var px = 0f
    private var py = 0f
    private var measuring = false
    private var panelTop = true
    private var cur = ""

    private val dw get() = svc.resources.displayMetrics.widthPixels.toFloat()
    private val dh get() = svc.resources.displayMetrics.heightPixels.toFloat()

    private inner class CrossView(ctx: Context) : View(ctx) {
        private val line = Paint().apply { color = Color.RED; strokeWidth = 3f; isAntiAlias = true }
        private val ring = Paint().apply { color = Color.RED; style = Paint.Style.STROKE; strokeWidth = 4f; isAntiAlias = true }
        override fun onDraw(c: Canvas) {
            val loc = IntArray(2); getLocationOnScreen(loc)
            val x = px - loc[0]; val y = py - loc[1]
            c.drawLine(0f, y, width.toFloat(), y, line)
            c.drawLine(x, 0f, x, height.toFloat(), line)
            c.drawCircle(x, y, 42f, ring)
        }
    }

    private fun crossParams(touchable: Boolean): WindowManager.LayoutParams {
        var f = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!touchable) f = f or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        return WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, f, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= 28) layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }

    private fun panelParams(): WindowManager.LayoutParams =
        WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = (if (panelTop) Gravity.TOP else Gravity.BOTTOM) or Gravity.START; y = if (panelTop) 60 else 40 }

    private fun update() {
        val fx = String.format(Locale.US, "%.1f", px / dw * 100f)
        val fy = String.format(Locale.US, "%.1f", py / dh * 100f)
        cur = "POS:$fx,$fy"
        label?.text = if (measuring) "$cur   (px ${px.toInt()}, ${py.toInt()})" else "पहले उस ऐप को खोलो, फिर '📏 नापो' दबाओ"
        cross?.invalidate()
    }

    private fun btn(t: String, onClick: () -> Unit) = Button(svc).apply {
        text = t; textSize = 13f; isAllCaps = false; setTextColor(Color.WHITE)
        background = GradientDrawable().apply { cornerRadius = 30f; setColor(Color.parseColor("#1565C0")) }
        setPadding(14, 4, 14, 4); minWidth = 0; minimumWidth = 0
        setOnClickListener { onClick() }
    }

    private fun nudge(dx: Float, dy: Float) { px = (px + dx).coerceIn(0f, dw); py = (py + dy).coerceIn(0f, dh); update() }

    fun show() {
        if (cross != null) return
        px = dw / 2; py = dh / 2
        val cv = CrossView(svc).apply {
            setOnTouchListener { _, e ->
                if (measuring && (e.action == MotionEvent.ACTION_DOWN || e.action == MotionEvent.ACTION_MOVE || e.action == MotionEvent.ACTION_UP)) {
                    px = e.rawX; py = e.rawY; update(); true
                } else false
            }
        }
        cross = cv
        wm.addView(cv, crossParams(false))

        val lab = TextView(svc).apply { textSize = 16f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(8, 8, 8, 8) }
        label = lab
        val mb = btn("📏 नापो") { measuring = !measuring; applyMode() }
        modeBtn = mb
        val row1 = LinearLayout(svc).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            addView(mb)
            addView(btn("📋 कॉपी") {
                try {
                    (svc.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                        .setPrimaryClip(ClipData.newPlainText("pos", cur))
                    Toast.makeText(svc, "कॉपी हुआ: $cur", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) { Toast.makeText(svc, "कॉपी नहीं हुआ — लिख लो: $cur", Toast.LENGTH_LONG).show() }
            })
            addView(btn("⇅ पट्टी") { panelTop = !panelTop; panel?.let { wm.updateViewLayout(it, panelParams()) } })
            addView(btn("✖ बंद") { hide() })
        }
        val row2 = LinearLayout(svc).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            addView(btn("◀") { nudge(-3f, 0f) }); addView(btn("▶") { nudge(3f, 0f) })
            addView(btn("▲") { nudge(0f, -3f) }); addView(btn("▼") { nudge(0f, 3f) })
        }
        val p = LinearLayout(svc).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply { cornerRadius = 30f; setColor(Color.parseColor("#E6000000")) }
            setPadding(10, 8, 10, 8)
            addView(lab); addView(row1); addView(row2)
        }
        panel = p
        wm.addView(p, panelParams())
        applyMode()
    }

    private fun applyMode() {
        modeBtn?.text = if (measuring) "👆 ऐप चलाओ" else "📏 नापो"
        cross?.let { wm.updateViewLayout(it, crossParams(measuring)) }
        update()
    }

    fun hide() {
        try { cross?.let { wm.removeView(it) } } catch (e: Exception) {}
        try { panel?.let { wm.removeView(it) } } catch (e: Exception) {}
        cross = null; panel = null; label = null; modeBtn = null
        onClose()
    }
}
