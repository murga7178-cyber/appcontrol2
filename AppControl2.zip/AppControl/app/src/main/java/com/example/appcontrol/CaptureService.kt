package com.example.appcontrol

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager

/** Android 10 पर स्क्रीनशॉट के लिए (Android 11+ पर ज़रूरत नहीं) */
class CaptureService : Service() {

    companion object { var instance: CaptureService? = null }

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vd: VirtualDisplay? = null
    private var last: Bitmap? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, id: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("cap", "Screen capture", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "cap")
            .setContentTitle("App Control")
            .setContentText("स्क्रीन देख रहा है")
            .setSmallIcon(android.R.drawable.ic_menu_camera).build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        val code = i?.getIntExtra("code", 0) ?: 0
        @Suppress("DEPRECATION")
        val data = i?.getParcelableExtra<Intent>("data")
        if (data != null) {
            val mpm = getSystemService(MediaProjectionManager::class.java)
            val mp = mpm.getMediaProjection(code, data)
            mp.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { instance = null }
            }, Handler(Looper.getMainLooper()))
            projection = mp
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION")
            (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(dm)
            reader = ImageReader.newInstance(dm.widthPixels, dm.heightPixels, PixelFormat.RGBA_8888, 2)
            vd = mp.createVirtualDisplay("cap", dm.widthPixels, dm.heightPixels, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, null)
            instance = this
        }
        return START_NOT_STICKY
    }

    /** ताज़ा स्क्रीन का Bitmap (नई फ्रेम न हो तो पिछली) */
    fun capture(): Bitmap? {
        val img = reader?.acquireLatestImage()
        if (img != null) {
            val p = img.planes[0]
            val w = img.width; val h = img.height
            val pad = p.rowStride - p.pixelStride * w
            val full = Bitmap.createBitmap(w + pad / p.pixelStride, h, Bitmap.Config.ARGB_8888)
            full.copyPixelsFromBuffer(p.buffer)
            img.close()
            last = Bitmap.createBitmap(full, 0, 0, w, h)
        }
        return last
    }

    override fun onDestroy() {
        vd?.release(); reader?.close(); projection?.stop()
        instance = null
        super.onDestroy()
    }
}
