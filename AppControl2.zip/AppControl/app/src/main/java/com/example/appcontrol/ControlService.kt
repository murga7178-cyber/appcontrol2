package com.example.appcontrol

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.content.Intent
import android.graphics.Color
import android.graphics.Path
import android.graphics.PathMeasure
import android.graphics.Rect
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.view.Display
import java.io.File
import java.util.concurrent.Executors
import kotlin.math.abs
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import org.json.JSONArray
import org.json.JSONObject
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast

class ControlService : AccessibilityService() {

    companion object { var instance: ControlService? = null }

    private val handler = Handler(Looper.getMainLooper())
    private var steps: List<String> = emptyList()
    private var index = 0
    private var gateOkIdx = -1   // जिस कमांड का स्क्रीनशॉट-मिलान पास हो चुका
    private var running = false
    private var badge: TextView? = null
    private var stepStart = 0L
    private var queue: List<String> = emptyList()
    private var qIndex = 0
    private var skippedThisApp = false
    // नंबर वाली कमांड: स्क्रॉल खोज और बार-बार चलाने की स्थिति
    private var numScrolled = false
    private var numFwd = true
    private var numEdges = 0
    private var numScrolls = 0
    private var numPrevSig = 0
    private var numLastScroll = 0L
    private var numCloseStage = 0     // 0 = बंद नहीं कर रहे; 1 = पहला बंद-टेक्स्ट; 2 = दूसरा बंद-टेक्स्ट
    private var numCloses = 0
    private val numSeen = HashSet<Int>()       // इस खुले पेज (जैसे 51–100) में स्क्रॉल करते समय जितनी कॉपी के नंबर दिखे
    private var numPageRange: IntRange? = null  // खुले पेज की रेंज (टाइटल से, जैसे 51–100)
    private var numScanComplete = false         // पेज ऊपर से किनारे तक पूरा देखा जा चुका
    private var crossStreak = 0      // लगातार कितनी कॉपी 🔴 (❌) हुईं; 3 हो जाएँ तो पूरा काम बंद
    private var numCloseAt = 0L
    private val numRangeTapped = HashSet<String>()   // जिन रेंज-टैब (जैसे 51-100) पर इस कमांड में क्लिक हो चुका
    private var numPassClicks = 0
    private var numExhausted = false
    private var numAllowRed = false          // बिना कोशिश वाले नंबर नहीं मिले तो अब 🔴 वालों को लो
    private var altRot = 0            // एक कमांड की दूसरी (वैकल्पिक) कमांडों में अभी किसकी बारी
    private var altKeyCur = -1
    private var altRetries = 0        // "नहीं मिले तो यह दबाओ, फिर पहली फिर खोजो" वाली कमांड में अब तक कितनी बार दूसरी दबी
    private var numLastNums: List<Int> = emptyList()   // पिछले राउंड में जो नंबर चले (Recents से हटाने के लिए)
    private val numCur = HashMap<String, Int>()     // इस राउंड में जिस नंबर पर क्लिक हुआ (राउंड पूरा होने पर ✅/🔴 तय होगा)
    private var autoRetry = false
    private var round = 1
    private var roundFailed = 0
    private var noProgress = 0
    private val bg = Executors.newSingleThreadExecutor()
    private var busy = false
    private var recheck = false
    private var reviewPending = false
    private var reviewWaiting = false
    private var skipReviewOnce = false
    private val tplCache = HashMap<String, Bitmap?>()
    // पिछला ऐप बंद करने की स्थिति
    private var closePkg: String? = null
    private var closeStart = 0L
    private var closeClicked = false
    private var afterClose: (() -> Unit)? = null
    // ऐप खुलने का इंतज़ार: पूरी तरह खुलने (स्क्रीन ठहरने) के बाद ही कमांड शुरू होंगी
    private var openPkg: String? = null
    private var openStart = 0L
    private var openSig = 0
    private var openStable = 0
    // एक ही टेक्स्ट कई जगह दिखे तो बारी-बारी क्लिक
    private var multiTried = 0
    private var holdUntil = 0L   // कमांड पर लगा टाइमर: इस समय तक रुको
    private var clickPending = false
    private var sigBefore = 0

    override fun onServiceConnected() { instance = this }

    // ---------- प्रोजेक्ट कतार: एक पूरा होते ही अगला (बीच में वाईफाई बंद-चालू) ----------
    private var chainOn = false
    private var chainNames: List<String> = emptyList()
    private var chainIdx = 0
    private var wifiOffByUs = false
    // कमांड छूटने पर नेटवर्क सुधार: हर कमांड पर सिर्फ़ एक बार (VPN हो तो VPN, वरना वाईफाई)
    private var netCycling = false
    private var netRetryKey = -1
    private var netStage = 0
    private var forceReview = false     // ऐप दोबारा खुला (सुधार के बाद): रिव्यू फोटो ज़रूर जाँचो
    private var reviewMissKey = -1
    private var rvRootTries = 0
    private var numCurTarget = -1          // अभी जिस नंबर को खोज रहे हैं (न मिला तो वही गिना जाए, कोई और नहीं)
    @Volatile private var numAllowOther = false     // पुराने IP नहीं मिले: जो नंबर दूसरे IP से जुड़े थे वे अब इसी IP पर चल सकते हैं
    private var histCache: Map<Int, String> = emptyMap()
    private var ctryCache: Map<String, String> = emptyMap()      // IP → देश
    private var histKey = ""
    private var histAt = 0L
    private var lastNumCmd: String? = null      // अभी चल रही नंबर वाली कमांड
    private var numRangeTapAt = 0L      // रेंज बटन पर आख़िरी क्लिक का समय (सूची न खुली हो तो फिर दबाओ)
    @Volatile private var failEventsOn = false          // गलती-संदेश कहीं भरा है: सारे इवेंट का टेक्स्ट हमेशा याद रखो (संदेश पल भर का होता है)
    private var failWatching = false                       // कमांड क्लिक के बाद "गलती का संदेश" देख रहे हैं
    private val recentTexts = ArrayList<Pair<Long, String>>()   // देखने के दौरान आए इवेंट के टेक्स्ट (टोस्ट आदि)
    private var rvFromTimeout = false   // रिव्यू जाँच इसी कमांड के समय खत्म होने (न मिलने) से शुरू हुई
    private var rvPreDoneIdx = -1       // इस कमांड पर "रिव्यू से पहले" वाले टेक्स्ट/फोटो स्टेप चल चुके
    private var reviewCheckedIdx = -1   // इस कमांड पर रिव्यू फोटो एक बार जाँची जा चुकी
    private var fewTries = 0           // राउंड 3+ में 1-2 ऐप बचने पर अतिरिक्त कोशिशें
    private var missedApps = 0          // लगातार कितने ऐप में कमांड छूटी


    private fun projData(n: String): Pair<List<String>, List<String>> {
        val sp = getSharedPreferences("apps", MODE_PRIVATE)
        fun l(k: String) = sp.getString(k, "")!!.split("\n").filter { it.isNotBlank() }
        return l("a_$n").distinct() to l("p_$n")
    }

    private fun nextValidProject(from: Int): Int {
        var k = from
        while (k < chainNames.size) {
            val (a, st) = projData(chainNames[k])
            if (a.isNotEmpty() && st.isNotEmpty()) return k
            toast("\"${chainNames[k]}\" में ऐप/कमांड नहीं — छोड़ा")
            k++
        }
        return -1
    }

    fun startChain(names: List<String>) {
        stop()
        chainNames = names; chainOn = true
        val k = nextValidProject(0)
        if (k < 0) { chainOn = false; toast("कोई प्रोजेक्ट चलाने लायक नहीं"); return }
        launchProject(k, false)
    }

    private fun launchProject(k: Int, cycleWifi: Boolean) {
        chainIdx = k
        val n = chainNames[k]
        val spc = getSharedPreferences("apps", MODE_PRIVATE)
        val prev = spc.getString("cur", "") ?: ""
        if (prev.isNotEmpty() && prev != n) ProjSettings.snap(spc, prev)      // पिछले प्रोजेक्ट में चलते समय जो सिखाया वह उसी में सेव रहे
        ProjSettings.apply(spc, n)   // इस प्रोजेक्ट की अपनी सेटिंग (वीपीएन आदि) और सिखाई हुई ऐड-स्क्रीन
        val (apps, st) = projData(n)
        val go = {
            getSharedPreferences("apps", MODE_PRIVATE).edit()
                .putString("cur", n).putString("steps", st.joinToString("\n"))
                .putString("pkgs", apps.joinToString("\n")).putString("failed", apps.joinToString("\n"))
                .putBoolean("ran", true).apply()
            startQueue(apps, st, true, false, true)
        }
        val sp = getSharedPreferences("apps", MODE_PRIVATE)
        val wantWifi = cycleWifi && sp.getBoolean("wifiCycle", true)
        val vpnPkg = sp.getString("vpnPkg", "")!!
        val wantVpn = cycleWifi && sp.getBoolean("vpnCycle", false) && vpnPkg.isNotEmpty()
        val vpnWasOn = onVpn()
        val fail = { why: String -> chainFail("$why — इसलिए प्रोजेक्ट रुका रह गया, अगला प्रोजेक्ट \"$n\" शुरू नहीं हुआ") }
        val afterWifi = { if (wantVpn) vpnCycle(n, vpnPkg, vpnWasOn, go, fail) else go() }
        if (wantWifi) wifiCycle(n, afterWifi, fail) else afterWifi()
    }

    /** वाईफाई की शर्त पूरी न हुई: कतार बंद, सब बंद, होम; ऐप खोलने पर कारण दिखेगा */
    private fun chainFail(msg: String) {
        getSharedPreferences("apps", MODE_PRIVATE).edit().putString("stopMsg", msg).apply()
        chainOn = false
        toast(msg)
        stop()
        try { MainActivity.cur?.finishAndRemoveTask() } catch (e: Exception) {}
        Handler(Looper.getMainLooper()).postDelayed({
            try { performGlobalAction(GLOBAL_ACTION_HOME) } catch (e: Exception) {}
        }, 500)
    }

    /** पूरे ऐप निपटने के बाद अगला प्रोजेक्ट; शुरू हुआ तो true */
    private fun runNextProject(): Boolean {
        if (!chainOn) return false
        val k = nextValidProject(chainIdx + 1)
        if (k < 0) { chainOn = false; return false }
        launchProject(k, true)
        return true
    }

    @Suppress("DEPRECATION")
    private fun onWifi(): Boolean {
        val cm = getSystemService(ConnectivityManager::class.java) ?: return false
        return cm.allNetworks.any { cm.getNetworkCapabilities(it)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true }
    }

    private fun wifiBadge(t: String) { badge?.text = "📶 $t" }

    @Suppress("DEPRECATION")
    private fun onVpn(): Boolean {
        val cm = getSystemService(ConnectivityManager::class.java) ?: return false
        return cm.allNetworks.any { cm.getNetworkCapabilities(it)?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true }
    }

    private fun vpnLines(key: String): List<String> =
        getSharedPreferences("apps", MODE_PRIVATE).getString(key, "")!!.split("\n").map { it.trim() }.filter { it.isNotEmpty() }

    /** वीपीएन ऐप खोलकर आपके लिखे स्टेप क्रम से टैप करो; कोई स्टेप 20 सेकंड में न मिले तो fail */
    private fun runVpnSteps(pkg: String, stepsL: List<String>, ok: () -> Unit, fail: (String) -> Unit) {
        val i = packageManager.getLaunchIntentForPackage(pkg)
        if (i == null) { fail("🔒 वीपीएन ऐप खुल नहीं पाया"); return }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
        var si = 0
        var tries = 0
        fun tap() {
            if (si >= stepsL.size) { ok(); return }
            val root = rootInActiveWindow
            // "POS:50,68" वाला स्टेप: स्क्रीन की चौड़ाई के 50% और ऊँचाई के 68% वाली जगह टैप (फोटो की ज़रूरत नहीं; बीच वाले पावर बटन के लिए)
            if (stepsL[si].startsWith("POS:")) {
                val nums = stepsL[si].removePrefix("POS:").split(",").mapNotNull { it.trim().removeSuffix("%").toFloatOrNull() }
                if (nums.size != 2) { fail("🔒 POS सही नहीं लिखा (जैसे POS:50,68)"); return }
                val retryP = {
                    if (tries >= 20) fail("🔒 वीपीएन ऐप स्क्रीन पर नहीं आया (स्टेप ${si + 1})")
                    else { tries++; handler.postDelayed({ tap() }, 1000) }
                }
                if (root == null || root.packageName != pkg) { retryP(); return }
                val dm = resources.displayMetrics
                val path = Path().apply { moveTo(dm.widthPixels * nums[0] / 100f, dm.heightPixels * nums[1] / 100f) }
                val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(pt(path), 0, 80)).build()
                val sent = dg(g, object : AccessibilityService.GestureResultCallback() {
                    override fun onCompleted(d: GestureDescription?) {
                        badge?.text = "🔒 वीपीएन स्टेप ${si + 1}/${stepsL.size} ✔"
                        si++; tries = 0
                        handler.postDelayed({ tap() }, 1500)
                    }
                    override fun onCancelled(d: GestureDescription?) { retryP() }
                }, null)
                if (!sent) retryP()
                return
            }
            // "IMG:फाइल" वाला स्टेप: स्क्रीनशॉट में फोटो खोजकर उसी जगह टैप करो
            if (stepsL[si].startsWith("IMG:")) {
                val tpl = loadTemplate(stepsL[si].removePrefix("IMG:").trim())
                if (tpl == null) { fail("🔒 वीपीएन की फोटो फाइल नहीं मिली"); return }
                val retry = {
                    if (tries >= 20) fail("🔒 वीपीएन में फोटो वाला बटन नहीं मिला (स्टेप ${si + 1})")
                    else { tries++; handler.postDelayed({ tap() }, 1000) }
                }
                if (root == null || root.packageName != pkg) { retry(); return }
                val onShot = { bmp: Bitmap? ->
                    val pos = if (bmp != null) match(bmp, tpl) else null
                    handler.post {
                        if (pos == null) retry()
                        else {
                            val path = Path().apply { moveTo(pos.first.toFloat(), pos.second.toFloat()) }
                            val g = GestureDescription.Builder()
                                .addStroke(GestureDescription.StrokeDescription(pt(path), 0, 60)).build()
                            val sent = dg(g, object : AccessibilityService.GestureResultCallback() {
                                override fun onCompleted(d: GestureDescription?) {
                                    badge?.text = "🔒 वीपीएन स्टेप ${si + 1}/${stepsL.size} ✔"
                                    si++; tries = 0
                                    handler.postDelayed({ tap() }, 1500)
                                }
                                override fun onCancelled(d: GestureDescription?) { retry() }
                            }, null)
                            if (!sent) retry()
                        }
                    }
                }
                if (Build.VERSION.SDK_INT >= 30) shotApi30 { onShot(it) }
                else {
                    val cs = CaptureService.instance
                    if (cs == null) { fail("🔒 मुख्य ऐप में 'स्क्रीन कैप्चर अनुमति' दें"); return }
                    bg.execute { onShot(cs.capture()) }
                }
                return
            }
            val node = if (root != null && root.packageName == pkg) findNode(root, stepsL[si]) else null
            if (node != null && clickNode(node)) {
                badge?.text = "🔒 वीपीएन स्टेप ${si + 1}/${stepsL.size} ✔"
                si++; tries = 0
                handler.postDelayed({ tap() }, 1500)
                return
            }
            if (tries >= 20) { fail("🔒 वीपीएन में \"${stepsL[si]}\" नहीं मिला"); return }
            tries++; handler.postDelayed({ tap() }, 1000)
        }
        handler.postDelayed({ tap() }, 2500)
    }

    /** वीपीएन जुड़ा था तो: आपके 'बंद' स्टेप (खाली हो तो Force stop) → डिस्कनेक्ट का इंतज़ार → 'चालू' स्टेप → जुड़ने का इंतज़ार (120 सेकंड) */
    private fun vpnCycle(next: String, pkg: String, wasOn: Boolean, go: () -> Unit, fail: (String) -> Unit) {
        if (!wasOn) { go(); return }                          // वीपीएन जुड़ा ही नहीं था
        badge?.text = "🔒 वीपीएन बंद हो रहा… (अगला: $next)"
        var t = 0
        fun waitOn() {
            if (onVpn()) {
                badge?.text = "🔒 वीपीएन जुड़ गया ✔"
                handler.postDelayed({ if (onVpn()) go() else waitOn() }, 3000)   // जुड़े रहने की दोबारा जाँच
                return
            }
            if (t >= 240) { fail("🔒 वीपीएन कनेक्ट नहीं हुआ (120 सेकंड इंतज़ार किया)"); return }
            t++; handler.postDelayed({ waitOn() }, 500)
        }
        fun connect() {
            badge?.text = "🔒 वीपीएन चालू हो रहा…"
            val onSteps = vpnLines("vpnOn")
            if (onSteps.isEmpty()) {                          // बिना स्टेप: ऐप खुलते ही खुद जुड़ेगा
                val i = packageManager.getLaunchIntentForPackage(pkg)
                if (i == null) { fail("🔒 वीपीएन ऐप खुल नहीं पाया"); return }
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i)
                t = 0; handler.postDelayed({ waitOn() }, 1000)
            } else runVpnSteps(pkg, onSteps, { t = 0; waitOn() }, fail)
        }
        fun waitOff() {
            if (!onVpn() || t >= 60) { handler.postDelayed({ connect() }, 3000); return }   // 30 सेकंड तक डिस्कनेक्ट का इंतज़ार
            t++; handler.postDelayed({ waitOff() }, 500)
        }
        val offSteps = vpnLines("vpnOff")
        if (offSteps.isEmpty()) {
            val ok = Shell.best("am force-stop $pkg") { }
            if (!ok) { fail("🔒 वीपीएन बंद नहीं कर पाए (बंद के स्टेप नहीं लिखे और Shizuku/Root भी जुड़ा नहीं)"); return }
            handler.postDelayed({ waitOff() }, 1000)
        } else runVpnSteps(pkg, offSteps, { t = 0; handler.postDelayed({ waitOff() }, 1000) }, fail)
    }

    /** वाईफाई से जुड़ा हो तो: बंद → डिस्कनेक्ट होने तक रुको → चालू → दोबारा जुड़ने तक रुको → फिर go() */
    private fun wifiCycle(next: String, go: () -> Unit, fail: (String) -> Unit) {
        if (!onWifi()) { go(); return }                       // वाईफाई से जुड़ा ही नहीं था
        wifiBadge("वाईफाई बंद हो रहा… (अगला: $next)")
        val ok = Shell.best("svc wifi disable") { }
        if (!ok) { fail("📶 वाईफाई बंद नहीं कर पाए (Shizuku/Root जुड़ा नहीं)"); return }
        wifiOffByUs = true
        var t = 0
        fun waitBack() {
            if (onWifi()) {
                wifiBadge("वाईफाई जुड़ गया ✔")
                handler.postDelayed({ if (onWifi()) go() else waitBack() }, 3000)   // जुड़े रहने की दोबारा जाँच
                return
            }
            if (t >= 240) { fail("📶 वाईफाई कनेक्ट नहीं हुआ (120 सेकंड इंतज़ार किया)"); return }
            t++; handler.postDelayed({ waitBack() }, 500)
        }
        fun enable() {
            wifiBadge("वाईफाई चालू हो रहा…")
            Shell.best("svc wifi enable") { }
            wifiOffByUs = false
            t = 0; handler.postDelayed({ waitBack() }, 1000)
        }
        fun waitOff() {
            if (!onWifi() || t >= 40) {                         // 20 सेकंड तक डिस्कनेक्ट का इंतज़ार
                handler.postDelayed({ enable() }, 3000)         // बंद अवस्था में 3 सेकंड रुको
                return
            }
            t++; handler.postDelayed({ waitOff() }, 500)
        }
        handler.postDelayed({ waitOff() }, 500)
    }

    /** वीपीएन जुड़ा होने पर भी कमांड फिर छूटी: वीपीएन बंद करो → नीचे वाले देश पर टैप (आपके स्टेप) → सूची थोड़ी खिसकाकर
     *  कोई दूसरा देश चुनो (क्लिक हुआ या नहीं, जाँचकर) → तभी वीपीएन चालू → जुड़ जाए तो आगे */
    private fun changeVpnCountry(pkg: String, resume: () -> Unit, fail: (String) -> Unit) {
        val sp = getSharedPreferences("apps", MODE_PRIVATE)
        val tapSteps = vpnLines("vpnCountry")
        val rnd = java.util.Random()
        badge?.text = "🌍 देश बदलने के लिए वीपीएन बंद हो रहा…"
        var curFail: (String) -> Unit = fail       // दोबारा चुनने के दौरान फेल हुआ तो प्रोजेक्ट नहीं रुकेगा, इंतज़ार चलता रहेगा
        var reselect: () -> Unit = {}
        var startFallbackFn: () -> Unit = {}
        var fallbackMode = false                    // नया देश नहीं जुड़ा: सूची से बाहर आकर सीधे 'कनेक्ट' (जो देश चुना हो उसी पर)
        var waitStart = 0L
        val maxWaitMs = 150_000L                    // कुल इंतज़ार (नए देश के लिए)
        val reselectEvery = 60                      // 60 पोल × 0.5 सेकंड = हर 30 सेकंड पर नया देश

        // ---- नया देश चुनने के बाद: वीपीएन चालू और जुड़ने का इंतज़ार ----
        fun afterPick() {
            if (waitStart == 0L) waitStart = System.currentTimeMillis()
            var el = 0
            var okRun = 0
            var stepsTried = false
            fun poll() {
                if (!running) return
                el++
                if (onVpn()) okRun++ else okRun = 0
                if (okRun >= 6 && el >= 8) {            // 3 सेकंड लगातार जुड़ा
                    badge?.text = "🔒 वीपीएन जुड़ गया ✔"
                    resume(); return
                }
                badge?.text = "🔒 नया देश जुड़ने का इंतज़ार… ${el / 2} सेकंड"
                if (el >= 12 && !stepsTried && !onVpn()) {      // 6 सेकंड में खुद न जुड़ा तो आपके 'चालू' स्टेप
                    stepsTried = true
                    val onSteps = vpnLines("vpnOn")
                    if (onSteps.isNotEmpty()) {
                        badge?.text = "🔒 वीपीएन चालू हो रहा…"
                        runVpnSteps(pkg, onSteps, { handler.postDelayed({ poll() }, 500) }, { _ -> handler.postDelayed({ poll() }, 500) })
                        return
                    }
                }
                if (System.currentTimeMillis() - waitStart >= maxWaitMs && !onVpn()) {
                    if (!fallbackMode && vpnLines("vpnOn").isNotEmpty()) { startFallbackFn(); return }   // नया देश नहीं जुड़ा: बाहर आकर कनेक्ट
                    fail("🔒 देश बदलने के बाद वीपीएन कनेक्ट नहीं हुआ (${maxWaitMs / 1000} सेकंड इंतज़ार किया)"); return
                }
                if (!fallbackMode && el >= reselectEvery && !onVpn()) {        // 30 सेकंड में नहीं जुड़ा: दोबारा नया देश चुनो
                    badge?.text = "🌍 30 सेकंड में नहीं जुड़ा — दूसरा देश चुन रहे हैं…"
                    reselect(); return
                }
                handler.postDelayed({ poll() }, 500)
            }
            handler.postDelayed({ poll() }, 500)
        }

        var tries = 0
        var scrollsLeft = -1
        var nameScrolls = 0; var nameSig = 0          // आपके लिखे देश के नाम खोजते समय सूची की स्क्रॉल (−1 = हार मानी, पुराना तरीका)
        var pickFn: () -> Unit = {}
        val junk = Regex("^[\\d.,%\\s]*(ms|mbps|kbps|gb|mb)?$", RegexOption.IGNORE_CASE)

        fun tapRect(r: Rect): Boolean {
            val path = Path().apply { moveTo(r.centerX().toFloat(), r.centerY().toFloat()) }
            val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(pt(path), 0, 60)).build()
            return dg(g, null, null)
        }
        // सूची को ऊपर की ओर स्वाइप (नीचे के देश दिखें); पूरा होने/न होने पर भी आगे बढ़ो
        fun swipeUp(done: () -> Unit) {
            val dm = resources.displayMetrics
            val x = dm.widthPixels / 2f
            val path = Path().apply { moveTo(x, dm.heightPixels * 0.72f); lineTo(x, dm.heightPixels * 0.38f) }
            val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(pt(path), 0, 350)).build()
            val next = { handler.postDelayed({ done() }, 900); Unit }
            val ok = dg(g, object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(d: GestureDescription?) { next() }
                override fun onCancelled(d: GestureDescription?) { next() }
            }, null)
            if (!ok) next()
        }

        // क्लिक करो, 1.5 सेकंड बाद जाँचो कि स्क्रीन बदली या नहीं; न बदली तो सीधा टैप; फिर भी न बदली तो अगला देश
        fun tryClick(order: List<Triple<Int, String, AccessibilityNodeInfo>>, idx: Int, tried: MutableList<String>) {
            if (!running) return
            if (idx >= order.size || idx >= 5) {
                if (++tries >= 4) curFail("🌍 दूसरे देश पर क्लिक नहीं हो पाया")
                else { scrollsLeft = -1; handler.postDelayed({ pickFn() }, 1000) }
                return
            }
            val c = order[idx]
            val rootNow = rootInActiveWindow
            val sigBefore = if (rootNow != null) screenSig(rootNow) else 0
            val r = Rect(); c.third.getBoundsInScreen(r)
            badge?.text = "🌍 चुन रहे हैं: ${c.second}"
            clickNode(c.third)
            fun moved(): Boolean {
                val rr = rootInActiveWindow
                return rr == null || rr.packageName != pkg || screenSig(rr) != sigBefore
            }
            fun chosen() {
                tried.add(c.second)
                sp.edit().putString("vpnTried", tried.takeLast(40).joinToString("\n"))
                    .putString("vpnCurCountry", c.second.lowercase().trim()).remove("vpnWantCountry").apply()
                badge?.text = "🌍 नया देश: ${c.second}"
                afterPick()
            }
            handler.postDelayed({
                if (!running) return@postDelayed
                if (moved()) { chosen(); return@postDelayed }
                if (!r.isEmpty) tapRect(r)                       // क्लिक नहीं लगा: उसी जगह सीधा टैप
                handler.postDelayed({
                    if (!running) return@postDelayed
                    if (moved()) chosen() else tryClick(order, idx + 1, tried)
                }, 1500)
            }, 1500)
        }

        fun pick() {
            val root = rootInActiveWindow
            if (root == null || root.packageName != pkg) {
                if (++tries >= 15) curFail("🌍 देशों की सूची खुली नहीं") else handler.postDelayed({ pickFn() }, 1000)
                return
            }
            // ---- आपके लिखे देश के नाम (हू-ब-हू वही नाम): सूची में दिखे तो वही चुनो, न दिखे तो नीचे स्क्रॉल करके खोजो ----
            // जिस देश में 5 बार चला हुआ IP ही मिला उसे 24 घंटे छोड़ो; सब लिखे देश ऐसे हो गए तो सूची छोड़कर VPN की पूरी सूची में से कोई भी देश
            val wantC = (sp.getString("vpnWantCountry", "") ?: "").lowercase().trim()      // पुराने IP का देश: वही पहले चुनो
            val wanted = if (wantC.isNotEmpty()) listOf(wantC).toSet() else vpnLines("vpnCountryNames").map { it.lowercase().trim() }
                .filter { IpLog.countryFails(this@ControlService, it) == 0 }.toSet()      // पहले चक्कर में सब देश (लिखे हुए पहले); हर देश पर 1 फेल हो जाए तब दूसरा चक्कर
            if (wanted.isNotEmpty() && nameScrolls >= 0) {
                val ms = ArrayList<Triple<Int, String, AccessibilityNodeInfo>>()
                fun walkW(n: AccessibilityNodeInfo?) {
                    if (n == null) return
                    val txt = (n.text ?: n.contentDescription)?.toString()?.trim()
                    if (!txt.isNullOrEmpty() && n.isVisibleToUser && txt.lowercase() in wanted) {
                        val canClick = generateSequence(n) { it.parent }.any { it.isClickable }
                        val r = Rect(); n.getBoundsInScreen(r)
                        if (canClick && !r.isEmpty && ms.none { it.second == txt }) ms.add(Triple(r.top, txt, n))
                    }
                    for (k in 0 until n.childCount) walkW(n.getChild(k))
                }
                walkW(root)
                if (ms.isNotEmpty()) {
                    val tr = sp.getString("vpnTried", "")!!.split("\n").filter { it.isNotBlank() }
                    val fresh = ms.filter { it.second !in tr }
                    val pool = if (fresh.isNotEmpty()) fresh
                               else ms.filter { it.second != tr.lastOrNull() }.ifEmpty { ms }
                    val first = pool[rnd.nextInt(pool.size)]
                    tryClick(listOf(first) + ms.filter { it !== first }, 0, tr.toMutableList())
                    return
                }
                val sg = screenSig(root)
                if (nameScrolls in 1..20 && sg == nameSig) nameScrolls = -1          // सूची का अंत: आपके नाम नहीं मिले → पुराना (अपने-आप) तरीका
                else if (nameScrolls > 20) nameScrolls = -1
                else { nameSig = sg; nameScrolls++; badge?.text = "🌍 आपके लिखे देश खोज रहे हैं…"; swipeUp { pickFn() }; return }
            }
            // सूची को 0-3 बार स्क्रॉल (स्वाइप) करो, ताकि हर बार अलग देश सामने आएँ
            if (scrollsLeft < 0) scrollsLeft = rnd.nextInt(4)
            if (scrollsLeft > 0) {
                scrollsLeft--
                badge?.text = "🌍 सूची स्क्रॉल हो रही है…"
                swipeUp { pickFn() }
                return
            }
            val skipWords = setOf("back", "search", "connect", "disconnect", "cancel", "ok", "yes", "no")
            fun clickableOf(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
                var cur: AccessibilityNodeInfo? = n
                while (true) {
                    val c = cur ?: return null
                    if (c.isClickable) return c
                    cur = c.parent
                }
            }
            val cands = ArrayList<Triple<Int, String, AccessibilityNodeInfo>>()
            val seen = HashSet<String>()

            fun walk(n: AccessibilityNodeInfo?) {
                if (n == null) return
                val txt = (n.text ?: n.contentDescription)?.toString()?.trim()
                if (!txt.isNullOrEmpty() && txt.length in 3..40 && txt.lowercase() !in skipWords
                    && !junk.matches(txt) && !n.isEditable && seen.add(txt)) {
                    val c = clickableOf(n)
                    if (c != null && !n.isSelected && !n.isChecked && !c.isSelected && !c.isChecked) {
                        val r = Rect(); n.getBoundsInScreen(r)
                        if (!r.isEmpty) cands.add(Triple(r.top, txt, n))
                    }
                }
                for (k in 0 until n.childCount) walk(n.getChild(k))
            }
            walk(root)
            cands.sortBy { it.first }
            val tried = sp.getString("vpnTried", "")!!.split("\n").filter { it.isNotBlank() }.toMutableList()
            var list = cands.filter { it.second !in tried }
            if (list.isEmpty()) {                                       // सब आज़मा लिए: चक्कर फिर शुरू, पर आख़िरी चुना वाला नहीं
                val last = tried.lastOrNull()
                tried.clear(); if (last != null) tried.add(last)
                list = cands.filter { it.second != last }
            }
            // जिन देशों पर फेल-गिनती पूरी (3) हो चुकी वे हटाओ (सब ऐसे हों तो रहने दो); फिर सबसे कम फेल वाले देश ही चुनो: पहले सब पर एक-एक बार, फिर दूसरा चक्कर
            run {
                val open = list.filter { IpLog.countryFails(this@ControlService, it.second) < IpLog.MAX_TRIES }
                if (open.isNotEmpty()) list = open
                val minF = list.minOfOrNull { IpLog.countryFails(this@ControlService, it.second) } ?: 0
                list = list.filter { IpLog.countryFails(this@ControlService, it.second) == minF }
            }
            if (list.isEmpty()) {
                if (++tries >= 15) curFail("🌍 सूची में कोई दूसरा देश नहीं मिला") else handler.postDelayed({ pickFn() }, 1000)
                return
            }
            val pool = if (list.size > 3) list.drop(1) else list        // सबसे ऊपर वाला अक्सर अभी का/सुझाया देश
            val first = pool[rnd.nextInt(pool.size)]
            tryClick(listOf(first) + pool.filter { it !== first }, 0, tried)
        }
        pickFn = { pick() }

        // ---- 1) वीपीएन बंद; 2) देश वाला स्टेप; 3) दूसरा देश चुनना ----
        var t = 0
        fun selectStage() {
            badge?.text = "🌍 नीचे वाले देश पर टैप…"
            runVpnSteps(pkg, tapSteps, { handler.postDelayed({ pickFn() }, 1500) }, { w -> curFail(w) })
        }
        fun waitOff() {
            if (!onVpn() || t >= 60) { handler.postDelayed({ selectStage() }, 2000); return }   // 30 सेकंड तक डिस्कनेक्ट का इंतज़ार
            t++; handler.postDelayed({ waitOff() }, 500)
        }
        fun beginOff() {
            val offSteps = vpnLines("vpnOff")
            if (offSteps.isEmpty()) {
                val ok = Shell.best("am force-stop $pkg") { }
                if (!ok) { curFail("🔒 वीपीएन बंद नहीं कर पाए (बंद के स्टेप नहीं लिखे और Shizuku/Root भी जुड़ा नहीं)"); return }
                handler.postDelayed({ waitOff() }, 1000)
            } else runVpnSteps(pkg, offSteps, { t = 0; handler.postDelayed({ waitOff() }, 1000) }, { w -> curFail(w) })
        }
        reselect = {
            // अभी वाला देश नहीं जुड़ा: VPN बंद → देश की सूची → दूसरा देश; फेल हुआ तो इंतज़ार चलता रहे
            t = 0; tries = 0; scrollsLeft = -1; nameScrolls = 0
            curFail = { _ -> handler.postDelayed({ if (running) afterPick() }, 500) }
            beginOff()
        }
        startFallbackFn = {
            fallbackMode = true; waitStart = 0L
            badge?.text = "🔙 नया देश नहीं जुड़ा — सूची से बाहर आकर सीधे कनेक्ट कर रहे हैं…"
            curFail = { w -> fail(w) }                  // अब असली फेल
            val onSteps = vpnLines("vpnOn")
            // सूची/स्क्रीन से बाहर: Back दो बार (हो सके तो ऐप भी बंद), फिर आपके 'चालू' स्टेप (कनेक्ट पर क्लिक)
            Shell.best("am force-stop $pkg") { }
            performGlobalAction(GLOBAL_ACTION_BACK)
            handler.postDelayed({
                performGlobalAction(GLOBAL_ACTION_BACK)
                handler.postDelayed({
                    if (!running) return@postDelayed
                    runVpnSteps(pkg, onSteps, { afterPick() }, { w -> fail(w) })
                }, 1000)
            }, 700)
        }
        beginOff()
    }

    /** ऐप पूरी तरह बंद: पहले Force stop (Shizuku/Root हो तो); न हो पाए तो Recents में ऊपर स्वाइप; फिर then() */
    private fun closeAppThen(pkg: String, then: () -> Unit) {
        if (pkg.startsWith("home:")) {                          // शॉर्टकट का पैकेज पता नहीं: बंद करना छोड़ो
            if (numRange() != null) closeNumCardsThen(false, then) else handler.postDelayed({ then() }, 500)
            return
        }
        val mode = getSharedPreferences("apps", MODE_PRIVATE).getInt("closeMode", 1)
        if (pkg in protectedPkgs()) {                           // सुरक्षित ऐप: कभी बंद नहीं
            if (numRange() != null) closeNumCardsThen(false, then) else handler.postDelayed({ then() }, 300)
            return
        }
        if (mode == 2) {                                        // Force stop: पहले चुपचाप (Shizuku/Root), न हो तो App info वाले रास्ते से
            val doIt = {
                badge?.text = "⛔ ऐप बंद हो रहा है…"
                if (Shell.best("am force-stop $pkg") { }) handler.postDelayed({ then() }, 1200)
                else closeViaSettings(pkg, then)
            }
            if (numRange() != null) closeNumCardsThen(false) { doIt() } else doIt()
            return
        }
        closeThen(pkg, then)                                    // 0 = बंद न करें, 1 = मिनिमाइज़ करके स्वाइप
    }

    /** कमांड नहीं मिली (वैकल्पिक नहीं): रिव्यू फोटो जाँच के बाद —
     *  1) ऐप Force stop (बंद) → 2) वीपीएन में जाओ: जुड़ा हो तो वीपीएन बंद + देश बदलकर फिर चालू (देश के स्टेप न हों तो बस बंद-चालू),
     *     सिर्फ़ वाईफाई हो तो वाईफाई बंद-चालू → 3) ऐप नए सिरे से खोलो, कमांड 1 से।
     *  हर कमांड पर वीपीएन वाला सुधार 2 बार तक, वाईफाई वाला 1 बार; उसके बाद पहले की तरह छोड़कर आगे। शुरू हुआ तो true */
    private fun recoverNetwork(): Boolean {
        val sp = getSharedPreferences("apps", MODE_PRIVATE)
        if (!sp.getBoolean("missCycle", true)) return false
        val key = qIndex * 1000 + index
        if (netRetryKey != key) { netRetryKey = key; netStage = 0 }
        val vpnPkg = sp.getString("vpnPkg", "")!!
        val vpnUp = onVpn() && vpnPkg.isNotEmpty()
        val label = "कमांड ${index + 1} दोबारा"
        val resume = {
            netCycling = false
            if (running) {
                val pkg = queue.getOrNull(qIndex)
                if (pkg != null) {
                    // ऐप पहले ही बंद है: नए सिरे से खोलो, कमांड 1 से चलेंगी
                    index = 0; gateOkIdx = -1; multiTried = 0; clickPending = false; holdUntil = 0L
                    forceReview = true            // ऐप दोबारा खुला: रिव्यू फोटो की जाँच
                    armReview()
                    stepStart = System.currentTimeMillis() + 3000
                    launchApp(pkg, false)
                    updateBadge()
                    handler.removeCallbacks(tick); handler.postDelayed(tick, 3000)
                } else {
                    stepStart = System.currentTimeMillis() + 2500
                    handler.removeCallbacks(tick); handler.postDelayed(tick, 2500)
                }
            }
        }
        val fail = { why: String ->
            netCycling = false
            if (chainOn) chainFail("$why — कमांड ${index + 1} पर रुका")
            else { toast("$why — कमांड ${index + 1} पर रुका"); stop() }
        }
        if (netStage >= 2) return false
        if (!vpnUp && !onWifi()) return false          // न VPN, न वाईफाई: कुछ करने को नहीं
        if (netStage == 1 && !vpnUp) return false      // वाईफाई वाला सुधार एक ही बार
        netStage++
        netCycling = true
        val flow = {
            if (vpnUp) {
                if (vpnLines("vpnCountry").isNotEmpty()) changeVpnCountry(vpnPkg, resume, fail)
                else vpnCycle(label, vpnPkg, true, resume, fail)
            } else wifiCycle(label, resume, fail)
        }
        val pkgNow = queue.getOrNull(qIndex)
        if (pkgNow != null) closeAppThen(pkgNow) { flow() } else flow()
        return true
    }

    /** सभी ऐप में बारी-बारी वही कमांड चलाओ */
    fun startQueue(pkgs: List<String>, list: List<String>, auto: Boolean = false, isRecheck: Boolean = false, chain: Boolean = false) {
        stop()
        if (numOnlyPendN >= 0) { numOnlyKeyG = numOnlyPendKey; numOnlyNG = numOnlyPendN; numOnlyPendN = -1; numOnlyPendKey = "" }
        if (!chain) chainOn = false
        if (pkgs.isEmpty() || list.isEmpty()) { toast("ऐप या कमांड नहीं जोड़ी"); return }
        queue = pkgs; qIndex = 0; steps = list; index = 0; gateOkIdx = -1; running = true
        autoRetry = auto; round = 1; noProgress = 0; fewTries = 0; recheck = isRecheck
        armReview()
        roundFailed = maxOf(failedList().size, pkgs.size)
        numLoopBase = numDoneTotal(); numWhy = ""
        failEventsOn = getSharedPreferences("apps", MODE_PRIVATE).getString("failText", "")!!.isNotBlank()
        numAllowOther = false; histKey = ""
        getSharedPreferences("apps", MODE_PRIVATE).edit().remove("ipCur").remove("vpnCurCountry").remove("vpnWantCountry").apply()      // पिछले दिन का बचा IP आज का न मान लिया जाए; आज पढ़कर ही तय होगा
        showBadge()
        // गिनती (नंबर) वाला काम चालू हो और "नया IP" चालू हो तो पहले VPN जोड़ो, उसका IP पढ़कर दर्ज करो; उसके बाद ही काम शुरू
        ipStartThen {
            stepStart = System.currentTimeMillis() + 2500
            launchApp(pkgs[0])
            handler.postDelayed(tick, 2500)
        }
    }

    fun isRunningNow(): Boolean = running

    /** ग्रिड में 🔴 कॉपी `n` पर दबाया: सिर्फ़ उसी नंबर पर, कमांड शुरू से एक बार चलाओ (दोहराव/IP बदलाव नहीं) */
    fun startNumOnly(cmd: String, n: Int, pkgs: List<String>, list: List<String>) {
        // इस एक कॉपी को खोलना है: इसकी पुरानी स्थिति (हरा/लाल/फेल-गिनती) हटाओ, वरना कोड इसे "हो चुकी/थकी हुई" मानकर खोजता ही नहीं
        run {
            val sp = getSharedPreferences("apps", MODE_PRIVATE)
            val dn = numDone(sp, numKey(cmd))
            val fm = numFailed(sp, numFailKey(cmd))
            dn.remove(n); fm.remove(n)
            sp.edit().putString(numKey(cmd), dn.sorted().joinToString(","))
                .putString(numFailKey(cmd), fm.entries.sortedBy { it.key }.joinToString(",") { "${it.key}:${it.value}" }).apply()
        }
        numOnlyPendKey = "nd_" + cmd.removePrefix("NUM:").substringBefore("¦")
        numOnlyPendN = n
        startQueue(pkgs.take(1), list, false)          // startQueue पहले stop() करता है; उसके बाद पेंडिंग नंबर चालू होता है
        toast("📂 कॉपी $n खोली जाएगी")
    }

    /** VPN बंद हो तो सिर्फ़ चालू करो (बंद करने वाला हिस्सा नहीं), जुड़ने तक रुको, फिर go() */
    private fun vpnConnectOnly(pkg: String, go: () -> Unit, fail: (String) -> Unit) {
        badge?.text = "🔒 वीपीएन चालू हो रहा… (शुरुआत)"
        var t = 0
        fun waitOn() {
            if (!running) return
            if (onVpn()) {
                badge?.text = "🔒 वीपीएन जुड़ गया ✔"
                handler.postDelayed({ if (running) go() }, 3000)
                return
            }
            if (t >= 240) { fail("🔒 वीपीएन कनेक्ट नहीं हुआ (120 सेकंड इंतज़ार किया)"); return }
            t++; handler.postDelayed({ waitOn() }, 500)
        }
        val onSteps = vpnLines("vpnOn")
        if (onSteps.isEmpty()) {
            val i = packageManager.getLaunchIntentForPackage(pkg)
            if (i == null) { fail("🔒 वीपीएन ऐप खुल नहीं पाया"); return }
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i)
            handler.postDelayed({ waitOn() }, 1000)
        } else runVpnSteps(pkg, onSteps, { t = 0; waitOn() }, fail)
    }

    /** काम शुरू होने से पहले: (नंबर वाली कमांड + नया IP चालू) → VPN जोड़ो, IP पढ़ो और दर्ज करो (24 घंटे में चला हुआ हो तो बदलो), फिर next() */
    private fun ipStartThen(next: () -> Unit) {
        val sp = getSharedPreferences("apps", MODE_PRIVATE)
        val pkg = sp.getString("vpnPkg", "")!!
        if (!sp.getBoolean("ipOn", false) || pkg.isEmpty() || numOnlyNG >= 0 || steps.none { numOfStep(it) != null }) { next(); return }
        netCycling = true
        val word = sp.getString("ipWord", "")!!
        val fail = { why: String ->
            netCycling = false
            if (chainOn) chainFail("$why — शुरुआत में VPN/IP")
            else { toast("$why — शुरुआत में VPN/IP, काम रुका"); stop() }
        }
        val readAndGo = {
            readVpnIp(pkg, word) { ip ->
                if (running) {
                    if (ip == null) {
                        netCycling = false
                        toast("🌐 शुरू का IP पढ़ नहीं पाए — काम चालू कर रहे हैं")
                        next()
                    } else if (IpLog.isBlocked(this, ip) && !pendingForIp(ip)) {
                        toast("🌐 शुरू का IP $ip पहले पूरा चल चुका — बदल रहे हैं")
                        ipRotate(pkg, word, { netCycling = false; if (running) next() }, fail)
                    } else {
                        ipActivate(ip, true)
                        netCycling = false
                        toast("🌐 शुरू का IP $ip दर्ज किया")
                        seekThen(next)
                    }
                }
            }
        }
        if (onVpn()) readAndGo() else vpnConnectOnly(pkg, { readAndGo() }, fail)
    }

    private fun reviewImgs(): List<String> =
        getSharedPreferences("apps", MODE_PRIVATE).getString("reviewImgs", "")!!
            .split("\n").filter { it.isNotBlank() }

    /** इस कमांड नंबर (0 = हर कमांड) के "रिव्यू से पहले" वाले स्टेप: हर लाइन  नंबर|स्टेप1¦स्टेप2 */
    private fun reviewPre(n: Int): List<String> =
        getSharedPreferences("apps", MODE_PRIVATE).getString("reviewPre", "")!!.split("\n").filter { it.isNotBlank() }
            .filter { (it.substringBefore("|").toIntOrNull() ?: -1).let { k -> k == n || k == 0 } }
            .flatMap { it.substringAfter("|").split("¦") }.map { it.trim() }.filter { it.isNotEmpty() }

    /** स्टेप एक-एक करके चलाओ (टेक्स्ट / क्रॉस / POS:x,y / IMG:फाइल). हर स्टेप ~4 सेकंड तक खोजता है; न मिले तो छोड़कर अगला. आख़िर में done() */
    private fun runQuick(steps: List<String>, done: () -> Unit) {
        var si = 0; var tries = 0; var token = 0
        var step: () -> Unit = {}
        val next = { token++; si++; tries = 0; handler.postDelayed({ step() }, 1000) }
        val ok = { toast("रिव्यू से पहले: ${steps.getOrElse(si) { "" }} ✔"); next() }
        val retry = {
            if (tries >= 6) { toast("रिव्यू से पहले: ${steps.getOrElse(si) { "" }} ✖ नहीं मिला"); next() }
            else { token++; tries++; handler.postDelayed({ step() }, 600) }
        }
        fun tapAt(x: Float, y: Float) {
            val my = token
            var fired = false
            val path = Path().apply { moveTo(x, y) }
            val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(pt(path), 0, 70)).build()
            val sent = dg(g, object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(d: GestureDescription?) { if (!fired && token == my) { fired = true; ok() } }
                override fun onCancelled(d: GestureDescription?) { if (!fired && token == my) { fired = true; retry() } }
            }, null)
            if (!sent) { fired = true; retry() }
            else handler.postDelayed({ if (!fired && token == my) { fired = true; toast("टैप का जवाब नहीं आया, फिर कोशिश"); retry() } }, 3000)   // जवाब न आए तो अटको मत
        }
        step = {
            if (running) {
                if (si >= steps.size) done()
                else {
                    val st = steps[si]
                    val root = rootInActiveWindow
                    badge?.text = "✅ रिव्यू से पहले [${si + 1}/${steps.size}]: $st  (कोशिश ${tries + 1})"
                    if (root == null) retry()
                    else if (st.startsWith("POS:")) {
                        val nums = st.removePrefix("POS:").split(",").mapNotNull { it.trim().removeSuffix("%").toFloatOrNull() }
                        if (nums.size != 2) next()
                        else { val dm = resources.displayMetrics; tapAt(dm.widthPixels * nums[0] / 100f, dm.heightPixels * nums[1] / 100f) }
                    } else if (st.startsWith("IMG:")) {
                        val tpl = loadTemplate(st.removePrefix("IMG:").trim())
                        if (tpl == null) next()
                        else {
                            val onShot = { bmp: Bitmap? ->
                                val pos = if (bmp != null) match(bmp, tpl) else null
                                handler.post { if (pos == null) retry() else tapAt(pos.first.toFloat(), pos.second.toFloat()) }
                            }
                            if (Build.VERSION.SDK_INT >= 30) shotApi30 { onShot(it) }
                            else {
                                val cs = CaptureService.instance
                                if (cs == null) next() else bg.execute { onShot(cs.capture()) }
                            }
                        }
                    } else {
                        val node = if (isCross(st)) findCross(root) else findNode(root, st)
                        if (node != null && clickNode(node)) ok()
                        else if (isCross(st)) {
                            // नाम/टेक्स्ट वाला क्रॉस नहीं मिला: स्क्रीन पर बना गुणा (×) चित्र खोजकर उसके बीच में टैप
                            val cands = crossCands(root)
                            val onShot = { bmp: Bitmap? ->
                                val pos = crossHit(bmp, cands)
                                handler.post { if (pos == null) retry() else tapAt(pos.first, pos.second) }
                            }
                            if (Build.VERSION.SDK_INT >= 30) shotApi30 { onShot(it) }
                            else {
                                val cs = CaptureService.instance
                                if (cs == null) retry() else bg.execute { onShot(cs.capture()) }
                            }
                        } else retry()
                    }
                }
            }
        }
        step()
    }

    /** दोबारा चेक (राउंड 2+ या 'सिर्फ़ अधूरे') में हर ऐप पर पहले रिव्यू फोटो खोजो */
    private fun armReview() {
        reviewPending = (recheck || round >= 2 || forceReview) && reviewImgs().isNotEmpty()
        reviewWaiting = false; skipReviewOnce = false; reviewCheckedIdx = -1
    }

    /** दोबारा चेक में हर कमांड से पहले स्क्रीन पर रिव्यू फोटो देखो (किसी भी कमांड पर मिल सकती है) */
    /** गिनती (नंबर) वाला काम चालू है और इसी पास में पहले की कोई कमांड छूट चुकी: तब इस कमांड की रिव्यू जाँच/रिव्यू-से-पहले नहीं चलेंगे, क्रॉस अपना काम करेगा */
    private fun earlierMissInCounting(): Boolean = skippedThisApp && steps.any { numOfStep(it) != null }

    private fun startReviewCheck() {
        if (earlierMissInCounting()) { skipReviewOnce = true; return }
        val root = rootInActiveWindow
        // स्क्रीन का रूट कभी-कभी पल भर के लिए खाली (null) रहता है (डायलॉग/ऐप बदलते समय): तुरंत जाँच छोड़ने की जगह कुछ बार रुककर दोबारा देखो
        if (root == null && rvRootTries < 10) {
            rvRootTries++
            reviewWaiting = true
            handler.postDelayed({ reviewWaiting = false; if (running) { handler.removeCallbacks(tick); handler.post(tick) } }, 400)
            return
        }
        rvRootTries = 0
        if (root == null || root.packageName == packageName || System.currentTimeMillis() < stepStart - 1500) {
            skipReviewOnce = true; return        // ऐप अभी खुला नहीं: सामान्य कमांड-पास चलने दो
        }
        // "रिव्यू से पहले" के टेक्स्ट/फोटो (क्रॉस, POS भी) जुड़े हों तो पहले उन्हें चलाओ, फिर रिव्यू फोटो जाँचो
        val pre = reviewPre(index + 1)
        if (pre.isNotEmpty() && rvPreDoneIdx != index) {      // रिव्यू से पहले वाले स्टेप: पहले राउंड में भी और दूसरे (सिर्फ़ ❌ वाले) राउंड में भी, रिव्यू फोटो जाँचने से ठीक पहले
            rvPreDoneIdx = index
            badge?.text = "✅ रिव्यू से पहले के स्टेप चला रहे हैं…"
            busy = true; reviewWaiting = true
            runQuick(pre) {
                busy = false; reviewWaiting = false
                reviewCheckedIdx = -1                // अब असली रिव्यू जाँच होगी
                handler.removeCallbacks(tick); handler.postDelayed(tick, 900)
            }
            return
        }
        // सिर्फ़ इसी कमांड नंबर के लिए जोड़ी गई रिव्यू फोटो (नंबर 0 या बिना नंबर = हर कमांड पर)
        val tpls = reviewImgs().mapNotNull { line ->
            val n = line.substringBefore("|", "0").toIntOrNull() ?: 0
            if (n == 0 || n == index + 1) loadTemplate(line.substringAfter("|")) else null
        }
        reviewCheckedIdx = index                   // इस कमांड पर सिर्फ़ एक बार जाँच
        if (tpls.isEmpty()) { skipReviewOnce = true; return }
        if (Build.VERSION.SDK_INT >= 30) {
            busy = true
            shotApi30 { bmp -> finishReview(bmp, tpls) }
        } else {
            val cs = CaptureService.instance
            if (cs == null) { skipReviewOnce = true; return }
            busy = true
            bg.execute { finishReview(cs.capture(), tpls) }
        }
        reviewWaiting = true
    }

    private fun finishReview(bmp: Bitmap?, tpls: List<Bitmap>) {
        // रिव्यू फोटो हूबहू मिले तभी सफल (सख़्त मिलान; आम फोटो-कमांड से ज़्यादा सख़्त)
        val strict = getSharedPreferences("apps", MODE_PRIVATE).getInt("reviewColor", 12).toDouble()
        val found = bmp != null && tpls.any { matchReview(bmp, it, strict) }
        handler.post {
            busy = false; reviewWaiting = false
            if (!running || !reviewPending) return@post
            toast(if (found) "✅ रिव्यू फोटो मिली → काम सफल माना" else "❌ रिव्यू फोटो नहीं मिली → क्रॉस रहेगा (दूसरे राउंड में फिर)")
            if (found && numCur.isEmpty() && numHasRemaining()) {
                // नंबर वाली (गिनती) कमांड चालू है और अभी कोई नंबर क्लिक नहीं हुआ: नीचे वाले ऐप को ✅ हरा नहीं करना
                // (वरना बाकी नंबरों पर काम रुक जाएगा). सिर्फ़ नंबर ✅ होते हैं; कमांड सामान्य चलती रहे
                reviewPending = false
                skipReviewOnce = true
                handler.removeCallbacks(tick); handler.post(tick)
            } else if (found) {
                reviewPending = false             // रिव्यू फोटो मिली: सही मानो, ✔ लगाओ, आगे बढ़ो
                skippedThisApp = false
                index = 0; gateOkIdx = -1
                finish()
            } else {
                skipReviewOnce = true             
                handler.removeCallbacks(tick); handler.post(tick)
            }
        }
    }

    private fun failedList(): List<String> =
        getSharedPreferences("apps", MODE_PRIVATE).getString("failed", "")!!
            .split("\n").filter { it.isNotBlank() }

    private fun markDone(pkg: String) {
        val l = failedList().filter { it != pkg }
        getSharedPreferences("apps", MODE_PRIVATE).edit()
            .putString("failed", l.joinToString("\n")).apply()
    }

    private fun launchApp(pkg: String, fresh: Boolean = true) {
        if (fresh) {
            numExhausted = false; numPassClicks = 0; numAllowRed = false
            // नया राउंड/नई कोशिश: नंबर खोजने की सारी पुरानी स्थिति साफ़, वरना पिछले राउंड की बची स्थिति (रेंज बटन दबा चुके, स्क्रॉल का किनारा आदि) से कोड भ्रमित हो सकता है
            numRangeTapped.clear(); numRangeTapAt = 0L; numLastScroll = 0L; numCloses = 0
            numScrolled = false; numFwd = true; numEdges = 0; numScrolls = 0; numCloseStage = 0
            numSeen.clear(); numPageRange = null; numScanComplete = false; numPrevSig = 0
        }
        if (pkg.startsWith("home:")) {              // होम स्क्रीन का शॉर्टकट: होम पर जाकर उसी नाम के आइकन पर टैप
            if (fresh) { netRetryKey = -1; reviewMissKey = -1 }
            openPkg = pkg; openStart = System.currentTimeMillis(); openSig = 0; openStable = 0; holdUntil = 0L
            multiTried = 0; clickPending = false
            launchHome(pkg.removePrefix("home:"))
            return
        }
        val i = packageManager.getLaunchIntentForPackage(pkg) ?: return
        if (fresh) { netRetryKey = -1; reviewMissKey = -1 }
        openPkg = pkg; openStart = System.currentTimeMillis(); openSig = 0; openStable = 0; holdUntil = 0L
        multiTried = 0; clickPending = false
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val spB = getSharedPreferences("apps", MODE_PRIVATE)
        if (spB.getBoolean("boostBefore", true)) {
            // "बंद न करें" मोड: + से जुड़े सारे ऐप बूस्ट (force-stop) से भी बचे रहेंगे
            val keepSet = HashSet<String>().apply { add(pkg) }
            if (spB.getInt("closeMode", 1) == 0) queue.filter { !it.startsWith("home:") }.forEach { keepSet.add(it) }
            Shell.boost(this, keepSet) { startActivity(i) }
        } else startActivity(i)
    }


    // ---------- होम स्क्रीन के आइकन / शॉर्टकट (क्रोम शॉर्टकट, क्लोन आदि) ----------
    private fun homeSwipe(done: () -> Unit) {
        val dm = resources.displayMetrics
        val y = dm.heightPixels * 0.40f
        val path = Path().apply { moveTo(dm.widthPixels * 0.88f, y); lineTo(dm.widthPixels * 0.12f, y) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(pt(path), 0, 300)).build()
        val next = { handler.postDelayed({ done() }, 800); Unit }
        val ok = dg(g, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { next() }
            override fun onCancelled(d: GestureDescription?) { next() }
        }, null)
        if (!ok) next()
    }

    /** होम स्क्रीन के सारे पेज देखकर आइकन के नाम लौटाओ */
    fun scanHome(cb: (List<String>) -> Unit) {
        val found = LinkedHashSet<String>()
        val dm = resources.displayMetrics
        var page = 0
        var lastSig = 0
        fun collect(r: AccessibilityNodeInfo) {
            fun walk(n: AccessibilityNodeInfo?) {
                if (n == null) return
                val t = (n.text ?: n.contentDescription)?.toString()?.trim()
                if (!t.isNullOrEmpty() && t.length <= 40 && n.isVisibleToUser) {
                    var x: AccessibilityNodeInfo? = n
                    while (x != null && !x.isClickable && !x.isLongClickable) x = x.parent
                    if (x != null) {
                        val b = Rect(); x.getBoundsInScreen(b)
                        if (b.width() < dm.widthPixels * 0.5 && b.height() < dm.heightPixels * 0.25) found.add(t)
                    }
                }
                for (i in 0 until n.childCount) walk(n.getChild(i))
            }
            walk(r)
        }
        fun finish() {
            performGlobalAction(GLOBAL_ACTION_HOME)
            handler.postDelayed({
                try {
                    startActivity(Intent(this, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP))
                } catch (e: Exception) { }
                handler.postDelayed({ cb(found.toList().sortedBy { it.lowercase() }) }, 900)
            }, 700)
        }
        fun step() {
            val r = rootInActiveWindow
            if (r == null || r.packageName == packageName) { finish(); return }
            collect(r)
            val sg = screenSig(r)
            if (page > 0 && sg == lastSig) { finish(); return }
            lastSig = sg
            if (++page >= 8) { finish(); return }
            homeSwipe { step() }
        }
        performGlobalAction(GLOBAL_ACTION_HOME)
        handler.postDelayed({ performGlobalAction(GLOBAL_ACTION_HOME); handler.postDelayed({ step() }, 900) }, 900)
    }

    /** होम स्क्रीन पर उसी नाम का आइकन खोजकर टैप (ज़रूरत हो तो पेज स्वाइप करके) */
    fun launchHome(name: String) {
        var page = 0
        fun attempt() {
            val r = rootInActiveWindow
            if (r != null && r.packageName != packageName) {
                val n = findNodes(r, name).firstOrNull()
                if (n != null && clickNode(n)) return
            }
            if (++page > 8) { toast("होम स्क्रीन पर \"$name\" नहीं मिला"); return }
            homeSwipe { attempt() }
        }
        performGlobalAction(GLOBAL_ACTION_HOME)
        handler.postDelayed({ performGlobalAction(GLOBAL_ACTION_HOME); handler.postDelayed({ attempt() }, 900) }, 900)
    }

    /** कमांड 1, 2, 3... क्रम से चलाना शुरू */
    fun startSequence(list: List<String>) {
        stop(); chainOn = false
        if (list.isEmpty()) { toast("कोई कमांड नहीं जोड़ी"); return }
        steps = list; index = 0; gateOkIdx = -1; running = true
        numExhausted = false; numPassClicks = 0
        stepStart = System.currentTimeMillis() + 1500
        showBadge()
        handler.postDelayed(tick, 1500) // ऐप खुलने का इंतज़ार
    }

    private fun stop() {
        if (wifiOffByUs) { wifiOffByUs = false; Shell.best("svc wifi enable") { } }   // रोकने पर वाईफाई बंद न रह जाए
        running = false; holdUntil = 0L; netCycling = false; forceReview = false; failWatching = false
        closePkg = null; afterClose = null; reviewPending = false; reviewWaiting = false; skipReviewOnce = false; recheck = false
        numCur.clear(); queue = emptyList(); qIndex = 0; skippedThisApp = false; autoRetry = false; missedApps = 0; crossStreak = 0
        numOnlyNG = -1; numOnlyKeyG = ""
        adOn = false; adIgnoreUntil = 0L; adPrevLum = null; adStill = 0; adTapped = false; adTried.clear(); teachHide()
        teachSessIdx = -1; teachPts.clear(); adTriedTaps.clear()
        handler.removeCallbacksAndMessages(null)
        badge?.let { try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } catch (e: Exception) {} }
        hideBlocker()
        fxRemove()
        badge = null
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            if (netCycling) { handler.postDelayed(this, 500); return }
            if (closePkg == "recents") { handler.postDelayed(this, 700); return }
            if (closePkg != null) { closeTick(); return }
            // नया ऐप खोला है तो पहले अच्छे से खुलने दो (कम से कम 3 सेकंड, स्क्रीन ठहरने तक, अधिकतम 15 सेकंड)
            val op = openPkg
            if (op != null) {
                val el = System.currentTimeMillis() - openStart
                val r = rootInActiveWindow
                val inApp = r != null && (r.packageName == op || (el > 6000 && r.packageName != packageName))
                if (inApp) {
                    val sg = screenSig(r!!)
                    if (sg == openSig) openStable++ else { openStable = 0; openSig = sg }
                }
                if (el < 15000 && !(inApp && el >= 2500 && openStable >= 2)) {
                    handler.postDelayed(this, 250); return
                }
                openPkg = null
                stepStart = System.currentTimeMillis()
            }
            // पिछली कमांड पर टाइमर लगा था तो उतनी देर रुको
            if (System.currentTimeMillis() < holdUntil) { handler.postDelayed(this, 200); return }
            if (reviewPending) {
                if (reviewWaiting) { handler.postDelayed(this, 500); return }
                if (!busy) {
                    if (skipReviewOnce) skipReviewOnce = false
                    else if (reviewCheckedIdx != index) { startReviewCheck(); if (reviewWaiting) return }
                }
            }
            val rawFull = stripLimit(steps[index])
            val perLim = stepLimit(steps[index])        // इस कमांड का अपना खोजने का समय (सेकंड); 0 = सामान्य सेटिंग
            val raw = if (rawFull.contains("~~")) rawFull.substringBeforeLast("~~") else rawFull
            // स्क्रीनशॉट वाली कमांड का रूप:  GATE:<फाइल>:<असली कमांड>  (स्क्रीन मिले तभी असली कमांड चलेगी)
            val gateFile: String? = if (raw.startsWith("GATE:")) raw.removePrefix("GATE:").substringBefore(":") else null
            val cmdFull = if (gateFile != null) raw.removePrefix("GATE:").substringAfter(":") else raw
            // एक कमांड में दूसरी (वैकल्पिक) कमांड:  पहली|ALT|दूसरी|ALT|तीसरी — पहली न मिले तो बारी-बारी से दूसरी भी खोजो
            val altKey = qIndex * 1000 + index
            if (altKey != altKeyCur) { altKeyCur = altKey; altRot = 0; altRetries = 0 }
            val variants = cmdFull.split("|ALT|")
            val mainCmd = variants[0]
            val cmdRaw = variants[Math.floorMod(altRot, variants.size)]
            val altRetry = cmdRaw.startsWith("↺")      // ↺ वाली दूसरी कमांड: दबाने के बाद आगे नहीं बढ़ती, पहली कमांड फिर खोजती है
            val cmd = cmdRaw.removePrefix("↺")
            // स्वाइप कमांड का रूप:  SWIPE:<left|right|up|down>:<टेक्स्ट या IMG:req:फाइल या खाली>
            val parts = cmd.split(":", limit = 3)
            val swipeDir: String? = if (cmd.startsWith("SWIPE:")) parts[1] else null
            val target = if (swipeDir != null) parts.getOrElse(2) { "" } else cmd
            val isImg = target.startsWith("IMG:")
            val mainSwipe = mainCmd.startsWith("SWIPE:")
            val mainTarget = if (mainSwipe) mainCmd.split(":", limit = 3).getOrElse(2) { "" } else mainCmd
            val optional = (!mainSwipe && isCross(mainCmd)) || mainTarget.startsWith("IMG:opt:")
            // वैकल्पिक कमांड ~4 सेकंड में न मिले तो आगे बढ़ जाओ
            val secs = getSharedPreferences("apps", MODE_PRIVATE).getInt("limit", 8)
            val limit0 = if (perLim > 0) perLim * 1000 else if (optional) minOf(secs, 4) * 1000 else secs * 1000
            // ग्रिड से कॉपी खोलते समय पेज (जैसे 51–100) पूरा स्कैन होने तक समय बढ़ाओ, ताकि पूरा पेज देखकर गायब नंबर पहचान सकें
            val limit = limit0 + (if (numOnlyNG >= 0 && numPageRange != null && !numScanComplete) 25000 else 0)
            // ऐड गार्ड: कमांड खोजते समय ऐड चल रहा हो तो उसे चलने दो, रुकने पर क्रॉस/स्किप/बैक/Escape से बंद करो (इस दौरान कमांड का समय नहीं कटता)
            if (!busy && adGuardOn() && adHandle(cmd, target, swipeDir)) { handler.postDelayed(this, 350); return }
            if (!busy && System.currentTimeMillis() - stepStart > limit) {
                if (numOnlyNG >= 0 && numParse(cmd) != null && numOnlyNotFound()) return      // ग्रिड वाला "सिर्फ़ यह कॉपी खोलो": न मिली तो वहीं रुको
                // नंबर वाली कमांड में नंबर समय में नहीं मिला: छोड़ो + दो बार बैक + कमांड शुरू से (सीधे अगली कमांड/मिनिमाइज़ नहीं)
                if (numParse(cmd) != null && numCloseOn(cmd) && numCloses < 30) {
                    numScanComplete = false
                    numNotFoundRestart(cmd)
                    handler.postDelayed(this, 800); return
                }
                // कमांड छूटी: नेटवर्क सुधार से पहले एक बार रिव्यू फोटो जाँचो (मिल गई = काम हो चुका)
                val rk = qIndex * 1000 + index
                val hasReviewHere = reviewImgs().any { line ->
                    val n = line.substringBefore("|", "0").toIntOrNull() ?: 0
                    n == 0 || n == index + 1
                }
                if (!optional && hasReviewHere && reviewMissKey != rk && !earlierMissInCounting()) {
                    reviewMissKey = rk
                    rvFromTimeout = true
                    forceReview = true; reviewPending = true; reviewWaiting = false; skipReviewOnce = false
                    reviewCheckedIdx = -1
                    badge?.text = "✅ रिव्यू फोटो जाँच रहे हैं…"
                    stepStart = System.currentTimeMillis() - limit + 3000
                    handler.postDelayed(this, 250); return
                }
                // (बदलाव) कमांड छूटने पर अब हर बार वाईफाई/VPN नहीं बदलता: सिर्फ़ छोड़कर आगे बढ़ता है।
                // वाईफाई/VPN सुधार तब होगा जब लगातार ~3 ऐप में कमांड छूटें (देखो netFixThen)
                // ग्रिड से "सिर्फ़ यही कॉपी खोलो" चल रहा हो और कोई कमांड छूटी: कॉपी नहीं खुली, ऐप बंद करके अपने ऐप की सूची पर लौटो
                if (!optional && numOnlyNG >= 0 && numOnlyNotFound()) return
                // गिनती वाला काम चालू हो और कोई कमांड (1, 2, 3…) छूटी: आगे की कमांड और रिव्यू फोटो नहीं, ❌ क्रॉस मानकर अगला सीधे कमांड 1 से
                if (!optional && steps.any { numOfStep(it) != null }) {
                    if (numParse(cmd) != null) numMarkMiss(cmd)      // नंबर वाली कमांड ही नहीं मिली और ऊपर का "बंद करें" वाला रास्ता नहीं चला: कोशिश गिनो, फिर भी आगे की कमांड नहीं
                    countMiss(); return
                }
                if (optional) toast("⏭ कमांड ${index + 1} वैकल्पिक (क्रॉस/opt) है — न मिली तो छोड़कर आगे बढ़े")
                if (!optional) skippedThisApp = true
                numMarkMiss(cmd)        // नंबर वाली कमांड में नंबर नहीं मिला = उसकी कोशिश गिनो (3 बार में छोड़ दिया जाएगा), फिर अगली कमांड
                if (!advance(false)) return
                handler.postDelayed(this, 250); return
            }
            // स्क्रीनशॉट से मिलान: जब तक खुली स्क्रीन स्क्रीनशॉट जैसी न हो, कमांड नहीं चलेगी
            if (gateFile != null && gateOkIdx != index) {
                val r0 = rootInActiveWindow
                if (!busy && r0 != null && r0.packageName != packageName) checkGate(gateFile, index)
                handler.postDelayed(this, 350); return
            }
            val root = rootInActiveWindow
            // हमारे अपने ऐप की स्क्रीन पर नहीं खोजना
            if (root != null && root.packageName != packageName) {
                // 🧠 सिखाई जाने वाली कमांड: "L" = उँगली का परदा आएगा, जहाँ छोड़ोगे वही जगह सीख लेगा;  "T:x,y" = सीखी हुई जगह पर टैप
                val teach = stepTeach(steps[index])
                if (teach != null) {
                    val pts = teachPoints(teach)
                    if (teach.startsWith("T:")) {              // सिखाए सारे बटन क्रम से दबाओ, फिर अगली कमांड
                        if (!busy) {
                            if (pts.isEmpty()) { toast("सिखाई हुई जगह सही नहीं — दोबारा सिखाइए"); if (!advance()) return }
                            else runTaps(pts, index, true) { }
                        }
                        handler.postDelayed(this, 300); return
                    }
                    if (teachSessIdx != index) {
                        if (teach.startsWith("A:")) {            // पहले वाले बटन दोहराओ, फिर आगे और सिखाओ
                            if (!busy) runTaps(pts, index, false) {
                                teachSessIdx = index; teachPts.clear(); teachPts.addAll(pts.map { "${it.first},${it.second}" })
                            }
                            handler.postDelayed(this, 300); return
                        }
                        teachSessIdx = index; teachPts.clear()
                    }
                    stepStart = System.currentTimeMillis()          // सिखाते समय कमांड का समय नहीं कटेगा
                    if (teachView == null && !busy) teachShow(true)
                    handler.postDelayed(this, 400); return
                }
                // "POS:50,68" कमांड: स्क्रीन की चौड़ाई के 50% और ऊँचाई के 68% वाली जगह टैप (टेक्स्ट/फोटो न हो तब)
                if (cmd.startsWith("POS:")) {
                    if (!busy) {
                        val nums = cmd.removePrefix("POS:").split(",").mapNotNull { it.trim().removeSuffix("%").toFloatOrNull() }
                        if (nums.size == 2) {
                            val dm = resources.displayMetrics
                            val path = Path().apply { moveTo(dm.widthPixels * nums[0] / 100f, dm.heightPixels * nums[1] / 100f) }
                            runGesture(path, 80, index)
                        } else { toast("POS सही नहीं लिखा (जैसे POS:50,68)"); if (!advance()) return }
                    }
                    handler.postDelayed(this, 300); return
                }
                if (isImg) {
                    if (!busy) findAndTapImage(target, swipeDir)
                    handler.postDelayed(this, 500); return
                }
                if (swipeDir != null) {
                    // टेक्स्ट मिल जाए तो उसी जगह से स्वाइप (क्लिक नहीं); खाली हो तो स्क्रीन के बीच से
                    if (!busy) {
                        if (target.isEmpty()) {
                            val dm = resources.displayMetrics
                            swipeAt(dm.widthPixels / 2, dm.heightPixels / 2, swipeDir, index)
                        } else {
                            val node = findNode(root, target)
                            if (node != null) {
                                val r = Rect(); node.getBoundsInScreen(r)
                                if (!r.isEmpty) swipeAt(r.centerX(), r.centerY(), swipeDir, index)
                            }
                        }
                    }
                    handler.postDelayed(this, 250); return
                }
                if (isCross(cmd)) {
                    val node = findCross(root)
                    if (node != null && clickNode(node)) {
                        if (!advance()) return
                        handler.postDelayed(this, 450) // अगली स्क्रीन का इंतज़ार
                        return
                    }
                    if (!busy) findAndTapCross(root)     // नाम वाला क्रॉस न मिले तो स्क्रीन पर गुणा (×) जैसा चित्र खोजकर टैप
                } else if (numParse(cmd) != null) {
                    // नंबर वाली कमांड: स्क्रीन पर दिखे "टेक्स्ट <नंबर>" में से सबसे छोटा नंबर जो अभी हुआ नहीं, उसी पर क्लिक;
                    // कोई न दिखे तो सूची स्क्रॉल करके खोजो (ऊपर-नीचे दोनों ओर)
                    val (lo, hi, base) = numParse(cmd)!!
                    val sp = getSharedPreferences("apps", MODE_PRIVATE)
                    val key = numKey(cmd)
                    val done = numDone(sp, key)
                    val failed = numFailed(sp, numFailKey(cmd))
                    val total = hi - lo + 1
                    val exh = failed.count { it.value >= NUM_MAX_FAILS && it.key !in done && it.key in lo..hi }      // सिर्फ़ इसी रेंज के थके हुए नंबर (बाहर वाले नहीं)
                    if (done.count { it in lo..hi } + exh >= total) {   // सारे नंबर पूरे (या 3 बार कोशिश के बाद छोड़े)
                        if (numGiveUp(true)) handler.postDelayed(this, 450)
                        return
                    }
                    val untried = total - done.count { it in lo..hi } - failed.count { it.key !in done && it.key in lo..hi }
                    val wantRed = untried <= 0 || numAllowRed          // पहले राउंड में सारे नंबर; 🔴 वाले दूसरे राउंड में
                    lastNumCmd = cmd
                    numSeen.addAll(seenNumbers(root, base))
                    if (numPageRange == null && numSeen.isNotEmpty()) numPageRange = pageRangeOf(root)
                    // IP के हिसाब से इस IP पर चलने वाले नंबर (अगले दिन भी वही IP → वही नंबर). खाली निकले तो रोक हटा दो, वरना कोड खोजता ही रह जाता है और रेंज बटन नहीं दबाता
                    val allowed0 = numAllowed(cmd, lo, hi, done, failed, wantRed)
                    val allowed = if (allowed0 != null && allowed0.isEmpty()) null else allowed0
                    val candAll = findNumbered(root, base, lo, hi, done, failed).filter { allowed == null || it.first in allowed }
                    val cand = if (wantRed) candAll else candAll.filter { !failed.containsKey(it.first) }
                    if (!busy) {
                        if (cand.isNotEmpty()) {
                            val (num, node) = cand[0]
                            if (clickNode(node)) {
                                numCur[cmd] = num; numPassClicks++; numCloses = 0
                                if (numOnlyNG >= 0) {                      // ग्रिड में नंबर पर दबाया था: सिर्फ़ कॉपी खोलकर यहीं छोड़ दो, और ✅ हरा कर दो (आपने खुद खोली है)
                                    numMarkManualDone(cmd, num)
                                    toast("📂 $base $num खुल गई, ✅ हरी कर दी — यहीं छोड़ दिया")
                                    stop(); return
                                }
                                toast("$base $num …")
                                if (!advance()) return
                                handler.postDelayed(this, 450); return
                            }
                        } else {
                            val now = System.currentTimeMillis()
                            val backOn = numCloseOn(cmd)     // नंबर न मिलने पर आपके लिखे टेक्स्ट पर क्लिक (खाली = बंद)
                            // स्क्रॉल से पहले: जो नंबर चाहिए (सबसे छोटा बचा हुआ) उसकी रेंज वाला टैब (जैसे \"51-100\") सीधे खोजकर क्लिक
                            val tRange = if (allowed == null) (lo..hi).toList() else allowed.sorted()
                            val target = tRange.firstOrNull { it !in done && !failed.containsKey(it) }
                                ?: tRange.firstOrNull { it !in done && (failed[it] ?: 0) < NUM_MAX_FAILS }
                            numCurTarget = target ?: -1
                            if (target != null) badge?.text = numProgress() + "  📂 कॉपी $target खोज रहे हैं: रेंज बटन " + (findRangeTab(root, target)?.let { (it.text ?: it.contentDescription)?.toString() } ?: "स्क्रीन पर नहीं दिखा")
                            if (target != null && now - numLastScroll >= 900) {
                                val tab = findRangeTab(root, target)
                                if (tab != null) {
                                    val tabKey = "$target|" + (tab.text ?: tab.contentDescription)?.toString()?.trim()
                                    val firstTime = numRangeTapped.add(tabKey)
                                    if ((firstTime || now - numRangeTapAt > 3500) && clickNode(tab)) {
                                        numRangeTapAt = now
                                        numSeen.clear(); numPageRange = null; numScanComplete = false
                                        toast("रेंज टैब → $base $target")
                                        numLastScroll = now + 600     // टैब की सूची खुलने का इंतज़ार, फिर ही स्क्रॉल
                                        stepStart = now
                                        handler.postDelayed(this, 700); return
                                    }
                                }
                            }
                            if (now - numLastScroll >= 1100) {
                                val sg = screenSig(root)
                                if (numScrolled && sg == numPrevSig) {        // स्क्रॉल से कुछ बदला नहीं = सूची का किनारा
                                    // खुली सूची पूरी देख ली, नंबर नहीं मिला और उसकी रेंज का टैब भी नहीं दिख रहा → यह कॉपी है ही नहीं:
                                    // हमेशा के लिए छोड़ो, दो बार बैक दबाओ, और इसी ऐप की सारी कमांड शुरू से चलाओ (अगली कॉपी से)
                                    numScanComplete = true
                                    if (backOn && numCloses < 30 && closeTextVisible(root, cmd)) {      // सूची पूरी देखी, नंबर नहीं, और \"बंद करें\" जैसा आपका टेक्स्ट स्क्रीन पर दिख रहा है
                                        numNotFoundRestart(cmd)
                                        handler.postDelayed(this, 800); return
                                    }
                                    numEdges++
                                    if (numEdges >= 2 || numScrolls > 60) {
                                        if (!wantRed && failed.any { it.value < NUM_MAX_FAILS && it.key !in done }) {
                                            // बिना कोशिश वाले नंबर कहीं नहीं मिले → अब 🔴 वालों को दोबारा
                                            numAllowRed = true; numEdges = 0; numScrolled = false; numScrolls = 0; numFwd = true
                                            handler.postDelayed(this, 250); return
                                        }
                                        if (backOn && numCloses < 30) { numNotFoundRestart(cmd); handler.postDelayed(this, 800); return }
                                        if (numGiveUp(done.isNotEmpty() || numPassClicks > 0)) handler.postDelayed(this, 450)
                                        return
                                    }
                                    numFwd = !numFwd
                                }
                                numPrevSig = sg; numScrolled = true; numLastScroll = now; numScrolls++
                                numScroll(root, numFwd)
                                // (बदलाव) यहाँ stepStart नहीं बदलता: नंबर न मिले तो कमांड का समय खत्म होते ही अगली कमांड पर चले जाओ
                            }
                        }
                    }
                } else {
                    // पिछले क्लिक के बाद स्क्रीन बदल गई = काम हो गया, अगली कमांड पर चलो
                    if (clickPending) {
                        clickPending = false
                        if (screenSig(root) != sigBefore) {
                            if (!advance()) return
                            handler.postDelayed(this, 450); return
                        }
                    }
                    val nodes0 = findNodes(root, cmd).ifEmpty { findByHint(root, cmd) }   // टेक्स्ट न मिले तो आइकन/चित्र के नाम (description / ID) से
                    // ↺ वाली दूसरी कमांड: पहली को कम से कम ~1.2 सेकंड मौका दो, और ज़्यादा से ज़्यादा 10 बार
                    val nodes = if (altRetry && (System.currentTimeMillis() - stepStart < 1200 || altRetries >= 10)) emptyList() else nodes0
                    if (altRetry && nodes.isNotEmpty()) {
                        if (clickNode(nodes[0])) {
                            altRetries++; altRot = 0; stepStart = System.currentTimeMillis(); multiTried = 0; clickPending = false
                            toast("↺ «${prettyStep(mainCmd)}» नहीं मिला — «$cmd» दबाया, अब फिर «${prettyStep(mainCmd)}» खोजेंगे")
                            handler.postDelayed(this, 800); return
                        }
                    }
                    if (nodes.isNotEmpty()) {
                        if (nodes.size == 1 && multiTried == 0) {
                            if (clickNode(nodes[0])) {
                                if (!advance()) return
                                handler.postDelayed(this, 450); return
                            }
                        } else {
                            if (multiTried >= nodes.size) {   // सब जगह क्लिक हो चुका
                                if (!advance()) return
                                handler.postDelayed(this, 450); return
                            }
                            val n = nodes[multiTried]; multiTried++
                            sigBefore = screenSig(root)
                            if (clickNode(n)) { clickPending = true; handler.postDelayed(this, 800); return }
                        }
                    }
                }
            }
            if (variants.size > 1 && !busy) altRot++      // यह कमांड नहीं मिली: अगली बार दूसरी कमांड आज़माओ
            handler.postDelayed(this, 250) // मिला नहीं तो खोजते रहो
        }
    }


    // ---------- ऐड गार्ड ----------
    // कमांड खोजते समय स्क्रीन पर ऐड आ जाए तो: ऐड को चलने दो (कमांड का समय नहीं कटेगा); जब ऐड रुक जाए
    // (स्क्रीन ठहर जाए) तब बंद करो — पहले क्रॉस/स्किप/Close बटन, फिर × की तस्वीर, फिर बैक, फिर Escape
    private var adOn = false
    private var adStart = 0L
    private var adLastSeen = 0L
    private var adSig = 0
    private var adSigAt = 0L
    private var adLastTry = 0L
    private var adTries = 0
    private var adIgnoreUntil = 0L
    private var adPrevLum: IntArray? = null
    private var adStill = 0
    private var adSampBusy = false
    private var adSampAt = 0L
    private var adXBusy = false
    private val adTried = HashSet<String>()      // इस स्क्रीन पर जो बटन आज़मा चुके
    private var adPkg: String? = null            // ऐड जिस ऐप के अंदर चला
    private var adTapped = false                 // ऐड पर खुद टैप किया था (वह दूसरा पेज खोल सकता है)
    private var adTapAt = 0L
    @Volatile private var adWinClass = ""
    @Volatile private var adWinPkg = ""

    private fun adGuardOn() = getSharedPreferences("apps", MODE_PRIVATE).getBoolean("adGuard", true)
    private fun adPlayFully() = getSharedPreferences("apps", MODE_PRIVATE).getBoolean("adPlayFully", true)

    private val adStrongTokens = listOf("gms.ads", "adactivity", "unity3d.ads", "unityads", "applovin", "ironsource", "vungle",
        "mbridge", "mintegral", "inmobi", "chartboost", "adcolony", "startapp", "openadsdk", "pangle", "facebook.ads",
        "audiencenetwork", "fyber", "tapjoy", "smaato", "admob", "interstitial", "rewardedad", "fullscreenad", "adsactivity")
    private val adIdRe = Regex("(^|[^a-z])(ad|ads|admob|adview|adcontainer|interstitial|rewarded)([^a-z]|$)")
    private val adStrongText = listOf(
        Regex("^(skip ads?|skip video|ads?|advertisement|close ad|विज्ञापन|विज्ञापन छोड़ें|विज्ञापन बंद करें)$"),
        Regex("^ad ?[·•|:-] ?.*"), Regex("^ad \\d+ (of|/) \\d+$"), Regex("^ads? by .*"),
        Regex("^(reward(ed)?|ad|video) (in|will end in|ends in) .*"), Regex("^you can (close|skip) .*"),
        Regex("^(close|skip) in \\d+.*"), Regex("^watch .* to (get|earn|unlock|receive).*"))
    private val adWeakText = setOf("skip", "learn more", "install", "install now", "download", "sponsored", "स्किप",
        "और जानें", "इंस्टॉल करें", "reward", "पुरस्कार", "open")

    private fun adScore(root: AccessibilityNodeInfo): Int {
        var score = 0
        val pkg = root.packageName?.toString()?.lowercase() ?: ""
        if (adWinPkg == root.packageName?.toString() && adStrongTokens.any { adWinClass.contains(it) }) score += 3
        if (adStrongTokens.any { pkg.contains(it) }) score += 3
        var count = 0; var idHit = false; var strong = 0; var weak = 0
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || ++count > 500) return
            val id = n.viewIdResourceName?.lowercase() ?: ""
            if (!idHit) {
                val cls = n.className?.toString()?.lowercase() ?: ""
                if (adStrongTokens.any { id.contains(it) || cls.contains(it) } || adIdRe.containsMatchIn(id.substringAfter('/'))) idHit = true
            }
            val t = ((n.text ?: n.contentDescription)?.toString() ?: "").trim().lowercase()
            if (t.isNotEmpty() && t.length <= 40) {
                if (adStrongText.any { it.containsMatchIn(t) }) strong++ else if (t in adWeakText) weak++
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        if (idHit) score += 3
        score += minOf(strong, 2) * 2 + minOf(weak, 2)
        if (score in 1..2 && adFindClose(root) != null) score += 1      // ऐड जैसा कुछ + क्रॉस/स्किप बटन
        return score
    }

    /** क्रॉस / स्किप / Close / Esc जैसा बटन (दिखता हुआ). पहले टेक्स्ट/डिस्क्रिप्शन से, फिर ID से */
    private fun adFindClose(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val exact = setOf("×", "✕", "✖", "✗", "╳", "x", "close", "close ad", "skip", "skip ad", "skip ads", "skip video",
            "dismiss", "no thanks", "esc", "escape", "बंद", "बंद करें", "क्रॉस", "स्किप", "छोड़ें", "छोड़ दें", "विज्ञापन बंद करें")
        val idWords = listOf("close", "skip", "dismiss", "btn_x", "ad_x", "cross")
        var byText: AccessibilityNodeInfo? = null; var byId: AccessibilityNodeInfo? = null; var count = 0
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || byText != null || ++count > 500) return
            if (n.isVisibleToUser) {
                val t = n.text?.toString()?.trim()?.lowercase()
                val d = n.contentDescription?.toString()?.trim()?.lowercase()
                if ((t != null && (t in exact || t.startsWith("skip"))) || (d != null && (d in exact || d.startsWith("skip") || d.startsWith("close")))) { byText = n; return }
                val id = n.viewIdResourceName?.lowercase()
                if (byId == null && id != null && idWords.any { id.substringAfter('/').contains(it) }) byId = n
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return byText ?: byId
    }

    private fun adTap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(pt(path), 0, 60)).build()
        dg(g, null, null)      // यहाँ advance() नहीं: ऐड बंद करना कमांड गिनती में नहीं आता
    }

    /** स्क्रीन ~1 सेकंड में एक बार छोटी करके जाँचो; पिछली से लगभग वही = ठहरी हुई (वीडियो रुका) */
    private fun adSample() {
        val now = System.currentTimeMillis()
        if (adSampBusy || now - adSampAt < 900) return
        adSampAt = now; adSampBusy = true
        val fin: (Bitmap?) -> Unit = { bmp ->
            var lum: IntArray? = null
            try { if (bmp != null) lum = gray(Bitmap.createScaledBitmap(bmp, 36, 64, true), 36, 64) } catch (e: Throwable) { }
            handler.post {
                adSampBusy = false
                val cur = lum
                if (cur != null) {
                    val prev = adPrevLum
                    if (prev != null && prev.size == cur.size) {
                        var d = 0L
                        for (i in cur.indices) d += abs(cur[i] - prev[i])
                        if (d / cur.size.toDouble() < 1.5) adStill++ else adStill = 0
                    }
                    adPrevLum = cur
                }
            }
        }
        if (Build.VERSION.SDK_INT >= 30) shotApi30(fin)
        else { val cs = CaptureService.instance; if (cs == null) adSampBusy = false else bg.execute { fin(cs.capture()) } }
    }


    private class AdCand(val prio: Int, val key: String, val node: AccessibilityNodeInfo, val r: Rect)

    private fun adLabel(n: AccessibilityNodeInfo, depth: Int = 0): String {
        val t = (n.text ?: n.contentDescription)?.toString()?.trim()?.lowercase() ?: ""
        if (t.isNotEmpty() || depth >= 2) return t
        for (i in 0 until minOf(n.childCount, 4)) { val c = n.getChild(i) ?: continue; val x = adLabel(c, depth + 1); if (x.isNotEmpty()) return x }
        return ""
    }

    /** पूरे पेज के सारे क्लिक-योग्य बटन (पीछे/छिपे हुए भी, और उसी ऐप की दूसरी विंडो के भी), आज़माने के क्रम में:
     *  0 = बंद/स्किप/बैक/नेक्स्ट जैसा नाम, 1 = ऊपर-नीचे का छोटा आइकन, 2 = बाकी छोटे आइकन, 3 = बाकी बटन,
     *  4 = जो दिख नहीं रहे (पीछे हैं), 5 = इंस्टॉल/डाउनलोड जैसे (सबसे आख़िर में) */
    private fun adCandidates(root: AccessibilityNodeInfo): List<AdCand> {
        val d = resources.displayMetrics.density
        val H = resources.displayMetrics.heightPixels
        val good = setOf("×", "✕", "✖", "✗", "╳", "x", "close", "close ad", "skip", "skip ad", "skip ads", "skip video", "dismiss",
            "no thanks", "esc", "escape", "back", "navigate up", "up", "next", "continue", "done", "got it", "resume", "exit", "cancel",
            "बंद", "बंद करें", "क्रॉस", "स्किप", "छोड़ें", "छोड़ दें", "विज्ञापन बंद करें", "वापस", "पीछे", "आगे", "जारी रखें", "ठीक है")
        val idWords = listOf("close", "skip", "dismiss", "back", "cross", "next", "continue", "btn_x", "exit", "done")
        val bad = listOf("install", "download", "learn more", "shop", "buy", "visit", "play now", "इंस्टॉल", "और जानें", "डाउनलोड", "खरीद")
        val roots = ArrayList<AccessibilityNodeInfo>(); roots.add(root)
        try { for (w in windows) { val r = w.root ?: continue; if (r.packageName == root.packageName && r != root) roots.add(r) } } catch (e: Throwable) { }
        val out = ArrayList<AdCand>(); var count = 0
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || ++count > 900) return
            if (n.isClickable) {
                val r = Rect(); n.getBoundsInScreen(r)
                if (!r.isEmpty && r.width() >= 8 * d && r.height() >= 8 * d) {
                    val t = adLabel(n)
                    val id = n.viewIdResourceName?.lowercase()?.substringAfter('/') ?: ""
                    val pr = when {
                        t in good || t.startsWith("skip") || idWords.any { id.contains(it) } -> 0
                        bad.any { t.contains(it) } -> 5
                        !n.isVisibleToUser -> 4
                        t.isEmpty() && r.width() <= 80 * d && r.height() <= 80 * d -> if (r.centerY() < H * 0.35 || r.centerY() > H * 0.9) 1 else 2
                        else -> 3
                    }
                    out.add(AdCand(pr, "${r.flattenToString()}|$t|$id", n, r))
                }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        for (r in roots) walk(r)
        return out.sortedWith(compareBy({ it.prio }, { it.r.top }, { it.r.left }))
    }


    /** true = ऐड संभाल रहे हैं (इस बार कमांड नहीं खोजनी); false = ऐड नहीं, सामान्य रूप से चलो */
    private fun adHandle(cmd: String, target: String, swipeDir: String?): Boolean {
        val now = System.currentTimeMillis()
        if (now < adIgnoreUntil) return false
        val root = rootInActiveWindow
        if (root == null || root.packageName == packageName) {
            if (adOn && now - adLastSeen < 2000) { stepStart = now; return true }       // ऐड बदल रहा है (स्क्रीन पल भर खाली)
            adOn = false; return false
        }
        // ऐड पर टैप से दूसरा पेज (स्टोर/ब्राउज़र) खुल गया हो तो बैक दबाकर ऐड वाले ऐप में लौटो
        if (adTapped) {
            val cp = root.packageName?.toString()
            if (now - adTapAt > 25_000) adTapped = false
            else if (adPkg != null && cp != adPkg) {
                if (now - adLastTry > 1200) { adLastTry = now; toast("◀ दूसरा पेज खुला — वापस जा रहे हैं"); performGlobalAction(GLOBAL_ACTION_BACK) }
                stepStart = now; return true
            } else if (now - adTapAt > 4000) adTapped = false
        }
        if (isCross(cmd)) { adOn = false; return false }          // आपकी अपनी क्रॉस कमांड है: वही ऐड बंद करेगी
        val hit = adScore(root) >= 3
        if (!hit) {
            if (adOn && now - adLastSeen < 1500) { stepStart = now; return true }        // ऐड बंद होने के बाद स्क्रीन बदलने का इंतज़ार
            if (adOn) { adOn = false; adTries = 0; stepStart = now; toast("✅ ऐड बंद हो गया"); adEnd() }
            return false
        }
        // आपकी कमांड (टेक्स्ट) स्क्रीन पर दिख रही हो तो ऐड गार्ड बीच में नहीं आएगा
        if (swipeDir == null && !cmd.startsWith("POS:") && !target.startsWith("IMG:") && numParse(cmd) == null &&
            findNodes(root, cmd).isNotEmpty()) return false
        if (!adOn) {
            adOn = true; adStart = now; adTries = 0; adLastTry = 0L
            adSig = screenSig(root); adSigAt = now; adPrevLum = null; adStill = 0
            adPkg = root.packageName?.toString(); adTapped = false; adTried.clear()
            adVisitIdx = -1; adVisitN = 0; adTeachIdx = -1; adTeachSig = 0; adTaughtN = 0; adUserAt = 0L
            toast("📺 ऐड मिला — चलने दे रहे हैं, रुकने पर सिर्फ़ सिखाया हुआ करेंगे")
        }
        adLastSeen = now; stepStart = now
        val sg = screenSig(root)
        if (sg != adSig) { adSig = sg; adSigAt = now; adTried.clear(); adVisitIdx = -1; adVisitN = 0; adTriedTaps.clear() }       // स्क्रीन बदली = नई स्क्रीन, फिर से पहचानो
        adSample()
        val closeNode = adFindClose(root)
        val sigStable = now - adSigAt >= 1500
        val still = if (adPrevLum != null) adStill >= 2 else now - adSigAt >= 4000      // स्क्रीनशॉट न मिले तो टेक्स्ट ठहरने से
        val stopped = sigStable && still
        val early = !adPlayFully() && closeNode != null
        val tooLong = now - adStart > 120_000
        if (!(stopped || early || tooLong)) return true            // ऐड चल रहा है: इंतज़ार
        if (now - adLastTry < 1800) return true
        if (now - adUserAt < 3_000) return true                    // आप उँगली से सिखा रहे हैं: अभी रुको
        adLastTry = now
        // इस जैसी स्क्रीन पहले सिखाई थी? तो उसके सिखाए टैप दोहराओ (हर तरह की स्क्रीन अलग याद रहती है)
        val all = screensAll()
        val mi = adMatch(all, root.packageName?.toString() ?: "", adWinClass, adTokens(root), adThumb())
        if (mi >= 0) {
            val taps = all.getJSONObject(mi).optJSONArray("taps")
            if (adVisitIdx != mi) { adVisitIdx = mi; adVisitN = 0 }
            if (taps != null && adVisitN < taps.length()) {
                adTries = 0
                adReplay(root, taps.getJSONObject(adVisitN), adVisitN + 1, taps.length()); adVisitN++
                return true
            }
        }
        // ठीक वैसी स्क्रीन नहीं सिखाई: सीखे हुए में से जो इस स्क्रीन के हिसाब से लगे (मिलती-जुलती पहले) वही आज़माओ
        if (adTryLearned(root, all)) { adTries = 0; return true }
        adTries++
        if (adTries > 80) {          // बहुत लंबी कोशिश के बाद ही छोड़ो (हाथ से रोकें बैज दबा सकते हैं)
            teachHide(); adIgnoreUntil = now + 30_000; adOn = false; stepStart = now
            toast("⚠ ऐड बंद नहीं हुआ — आगे बढ़ रहे हैं")
            return false
        }
        teachShow()                       // अपने-आप कोई कोशिश (बैक/क्लिक/टैप) नहीं: सिर्फ़ वही जो सिखाया गया हो — नहीं सिखाया तो उँगली का परदा
        return true
    }


    // ---------- ऐड बंद करना सिखाना ----------
    // अपने-आप ऐड न हटे तो एक पारदर्शी परदा आता है: उँगली को क्रॉस पर ले जाकर छोड़ो, वहाँ टैप हो जाएगा और याद रहेगा.
    // हर तरह की ऐड-स्क्रीन अलग सिखाओ: अगली बार वैसी ही स्क्रीन आए तो उसका सिखाया टैप अपने-आप दोहराया जाता है.
    private var teachView: View? = null
    private var teachLp: WindowManager.LayoutParams? = null
    private var adUserAt = 0L
    private var adVisitIdx = -1      // इस स्क्रीन पर सीखी हुई कौन-सी एंट्री दोहरा रहे हैं
    private var adVisitN = 0         // उसके कितने टैप दोहरा चुके
    private var adTeachIdx = -1      // जिस स्क्रीन पर अभी सिखा रहे हैं उसकी एंट्री
    private var adTeachSig = 0       // उस स्क्रीन की पहचान (बदलने पर नई स्क्रीन)
    private val adTriedTaps = HashSet<String>()   // इस स्क्रीन पर सीखे हुए जो टैप आज़मा चुके
    private var adTaughtN = 0

    // हर तरह की ऐड-स्क्रीन अलग याद रहती है:  {p: ऐप, w: विंडो, t: स्क्रीन के हिस्सों की पहचान, th: छोटी तस्वीर, taps: [सिखाए टैप]}
    private fun screensAll(): JSONArray = try {
        JSONArray(getSharedPreferences("apps", MODE_PRIVATE).getString("adScreens", "[]") ?: "[]")
    } catch (e: Exception) { JSONArray() }

    private fun screensSave(a: JSONArray) {
        getSharedPreferences("apps", MODE_PRIVATE).edit().putString("adScreens", a.toString()).apply()
    }

    /** स्क्रीन की बनावट: दिखते हिस्सों की ID/क्लास + छोटे बिना-अंक वाले टेक्स्ट (काउंटडाउन के अंक छोड़कर) */
    private fun adTokens(root: AccessibilityNodeInfo): Set<String> {
        val out = HashSet<String>(); var c = 0
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || ++c > 400) return
            if (n.isVisibleToUser) {
                val id = n.viewIdResourceName?.substringAfter('/') ?: ""
                val cls = n.className?.toString()?.substringAfterLast('.') ?: ""
                out.add(if (id.isNotEmpty()) "i:$id" else "c:$cls")
                val t = ((n.text ?: n.contentDescription)?.toString() ?: "").trim().lowercase()
                if (t.isNotEmpty() && t.length <= 20 && t.none { it.isDigit() }) out.add("t:$t")
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return out
    }

    /** पिछली ली हुई छोटी (36x64) स्क्रीन-तस्वीर को 18x32 करके सेव योग्य रूप में */
    private fun adThumb(): String? {
        val l = adPrevLum ?: return null
        if (l.size != 36 * 64) return null
        val b = ByteArray(18 * 32)
        for (y in 0 until 32) for (x in 0 until 18) {
            val sum = l[(2 * y) * 36 + 2 * x] + l[(2 * y) * 36 + 2 * x + 1] + l[(2 * y + 1) * 36 + 2 * x] + l[(2 * y + 1) * 36 + 2 * x + 1]
            b[y * 18 + x] = (sum / 4).coerceIn(0, 255).toByte()
        }
        return android.util.Base64.encodeToString(b, android.util.Base64.NO_WRAP)
    }

    private fun thumbDiff(a: String?, b: String?): Double {
        if (a.isNullOrEmpty() || b.isNullOrEmpty()) return -1.0
        return try {
            val x = android.util.Base64.decode(a, android.util.Base64.NO_WRAP); val y = android.util.Base64.decode(b, android.util.Base64.NO_WRAP)
            if (x.size != y.size || x.isEmpty()) return -1.0
            var d = 0L
            for (i in x.indices) d += abs((x[i].toInt() and 255) - (y[i].toInt() and 255))
            d / x.size.toDouble()
        } catch (e: Exception) { -1.0 }
    }

    /** सीखी हुई सबसे मिलती-जुलती स्क्रीन का नंबर (-1 = ऐसी स्क्रीन पहले नहीं सिखाई).
     *  बनावट ≥80% मिले तो वही; हिस्से बहुत कम हों (वीडियो/वेब ऐड) तो छोटी तस्वीर से मिलान */
    private fun adMatch(all: JSONArray, pkg: String, win: String, toks: Set<String>, th: String?): Int {
        var best = -1; var bestS = 0.0
        for (k in 0 until all.length()) {
            val e = all.optJSONObject(k) ?: continue
            if (e.optString("p") != pkg) continue
            val et = HashSet<String>()
            e.optJSONArray("t")?.let { for (j in 0 until it.length()) et.add(it.optString(j)) }
            var sc = 0.0
            if (et.size >= 3 && toks.size >= 3) {
                val inter = toks.count { it in et }
                val j = inter.toDouble() / (toks.size + et.size - inter)
                if (j >= 0.8) sc = j
            } else {
                val d = thumbDiff(e.optString("th"), th)
                if (d in 0.0..14.0) sc = 1.0 - d / 100.0
            }
            if (sc > 0.0 && e.optString("w") == win) sc += 0.05
            if (sc > 0.0 && sc >= bestS) { bestS = sc; best = k }     // बराबरी में बाद में सिखाई हुई जीतेगी
        }
        return best
    }

    /** उँगली से सिखाया टैप इस स्क्रीन के नाम से सेव: पहली बार सिखाने पर इस तरह की स्क्रीन का पुराना तरीका बदलता है,
     *  उसी स्क्रीन पर दूसरा टैप सिखाओ तो पहले के बाद जुड़ता है */
    private fun adRecord(st: JSONObject) {
        val root = rootInActiveWindow ?: return
        val pkg = root.packageName?.toString() ?: return
        val toks = adTokens(root); val th = adThumb()
        val all = screensAll()
        val idx: Int
        if (adTeachIdx in 0 until all.length() && adTeachSig == adSig) {
            all.getJSONObject(adTeachIdx).optJSONArray("taps")?.put(st); idx = adTeachIdx
        } else {
            val mi = adMatch(all, pkg, adWinClass, toks, th)
            val taps = JSONArray().put(st)
            if (mi >= 0) { all.getJSONObject(mi).put("taps", taps); idx = mi }
            else {
                if (all.length() >= 300) all.remove(0)
                all.put(JSONObject().put("p", pkg).put("w", adWinClass).put("t", JSONArray(toks.toList()))
                    .put("th", th ?: "").put("taps", taps))
                idx = all.length() - 1
            }
        }
        screensSave(all)
        adTeachIdx = idx; adTeachSig = adSig
        adVisitIdx = idx; adVisitN = all.getJSONObject(idx).optJSONArray("taps")?.length() ?: 0   // इसी स्क्रीन पर अभी दोबारा न दोहराओ
        adTries = 0
        toast("🧠 सीख लिया — अब तक ${all.length()} तरह की स्क्रीन याद हैं")
    }

    private fun adEnd() {
        teachHide()
        adTaughtN = 0
    }

    private fun teachPass(pass: Boolean) {
        val v = teachView ?: return; val lp = teachLp ?: return
        lp.flags = if (pass) lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE else lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        try { (getSystemService(WINDOW_SERVICE) as WindowManager).updateViewLayout(v, lp) } catch (e: Exception) { }
    }

    private var teachForStep = false      // true = किसी कमांड की जगह सिखा रहे हैं (ऐड वाली सीख नहीं)

    private var teachBtn: TextView? = null
    private var teachSessIdx = -1                 // जिस कमांड का सिखाने का सत्र चल रहा है
    private val teachPts = ArrayList<String>()    // इस सत्र में सिखाए बटन "x,y" (स्क्रीन का %)

    private fun teachShow(forStep: Boolean = false) {
        if (teachView != null || !running) return
        try {
            teachForStep = forStep
            val d = resources.displayMetrics.density
            val touch = View(this)
            touch.setOnTouchListener { _, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> { adUserAt = System.currentTimeMillis(); fingerFollow(e.rawX, e.rawY) }
                    MotionEvent.ACTION_UP -> {
                        adUserAt = System.currentTimeMillis()
                        if (teachForStep) stepTaught(e.rawX, e.rawY) else teachTap(e.rawX, e.rawY)
                    }
                }
                true
            }
            val root: View
            if (forStep) {
                // कमांड सिखाने में हर बटन के बाद परदा रहता है; सारे बटन सिखा लें तो ऊपर "✔ पूरा" दबाइए
                val fl = FrameLayout(this)
                fl.addView(touch, FrameLayout.LayoutParams(-1, -1))
                val btn = TextView(this).apply {
                    textSize = 15f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
                    setPadding((16 * d).toInt(), (10 * d).toInt(), (16 * d).toInt(), (10 * d).toInt())
                    background = GradientDrawable().apply { setColor(Color.parseColor("#2E7D32")); cornerRadius = 24 * d }
                    setOnClickListener { stepTeachDone() }
                }
                teachBtn = btn
                fl.addView(btn, FrameLayout.LayoutParams(-2, -2).apply {
                    gravity = Gravity.TOP or Gravity.END; topMargin = (96 * d).toInt(); rightMargin = (12 * d).toInt()
                })
                root = fl
                updateTeachBtn()
            } else root = touch
            val lp = blockerParams(true)
            (getSystemService(WINDOW_SERVICE) as WindowManager).addView(root, lp)
            teachView = root; teachLp = lp
            toast(if (forStep) "✋ कमांड ${index + 1}: हर बटन पर उँगली छोड़ते जाइए, पूरा होने पर ऊपर ✔ दबाइए"
                  else "✋ ऐड हटाना सिखाइए — उँगली को क्रॉस पर ले जाकर छोड़िए, मैं सीख लूँगा")
        } catch (e: Throwable) { teachView = null; teachLp = null; teachBtn = null }
    }

    private fun updateTeachBtn() {
        handler.post { teachBtn?.text = "✔ पूरा  (${teachPts.size} बटन सीखे)" }
    }

    private fun teachHide() {
        teachView?.let { try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } catch (e: Exception) { } }
        teachView = null; teachLp = null; teachForStep = false; teachBtn = null
    }

    /** सिखाते समय उँगली जहाँ छोड़ी: वहाँ असली टैप भेजो और उस बटन को इस सत्र में जोड़ लो (परदा रहता है, अगला बटन सिखाइए) */
    private fun stepTaught(x: Float, y: Float) {
        if (!running || index >= steps.size) return
        ptr(x, y)
        val dm = resources.displayMetrics
        val px = Math.round(x / dm.widthPixels * 1000f) / 10f
        val py = Math.round(y / dm.heightPixels * 1000f) / 10f
        teachPts.add("$px,$py")
        updateTeachBtn()
        toast("🧠 बटन ${teachPts.size} सीखा")
        dg(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(Path().apply { moveTo(x, y) }, 0, 60)).build(), null, null)
    }

    /** ✔ पूरा: सिखाए सारे बटन कमांड के साथ सेव (प्रोजेक्ट में भी) और अगली कमांड पर */
    private fun stepTeachDone() {
        val my = index
        if (!running || my >= steps.size) { teachHide(); return }
        val old = steps[my]
        val nw = if (teachPts.isEmpty()) stripTeach(old) else stripTeach(old) + "^^T:" + teachPts.joinToString(";")
        saveTaught(my, old, nw)
        val n = teachPts.size
        teachHide(); teachSessIdx = -1; teachPts.clear()
        toast(if (n > 0) "🧠 सीख लिया: कमांड ${my + 1} के $n बटन याद रखे" else "सिखाना रद्द: कमांड सामान्य चलेगी")
        if (n > 0) {
            busy = true
            handler.postDelayed({
                busy = false
                if (running && index == my && advance()) { handler.removeCallbacks(tick); handler.postDelayed(tick, 450) }
            }, 600)
        }
    }

    /** सिखाए बटन एक-एक करके दबाओ (बीच में थोड़ा रुककर) */
    private fun runTaps(pts: List<Pair<Float, Float>>, my: Int, advanceAfter: Boolean, onDone: () -> Unit) {
        busy = true
        val dm = resources.displayMetrics
        fun go(k: Int) {
            if (!running || index != my) { busy = false; return }
            if (k >= pts.size) {
                busy = false; onDone()
                if (advanceAfter && advance()) { handler.removeCallbacks(tick); handler.postDelayed(tick, 450) }
                return
            }
            val path = Path().apply { moveTo(dm.widthPixels * pts[k].first / 100f, dm.heightPixels * pts[k].second / 100f) }
            val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(pt(path), 0, 80)).build()
            val ok = dg(g, object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(d: GestureDescription?) { handler.postDelayed({ go(k + 1) }, 700) }
                override fun onCancelled(d: GestureDescription?) { handler.postDelayed({ go(k + 1) }, 700) }
            }, null)
            if (!ok) handler.postDelayed({ go(k + 1) }, 700)
        }
        go(0)
    }

    private fun saveTaught(i: Int, old: String, nw: String) {
        steps = steps.toMutableList().also { if (i < it.size) it[i] = nw }
        val sp = getSharedPreferences("apps", MODE_PRIVATE)
        val e = sp.edit()
        for ((k, v) in sp.all) {
            if ((k == "steps" || k.startsWith("p_")) && v is String) {
                val l = v.split("\n").toMutableList()
                if (i < l.size && l[i] == old) { l[i] = nw; e.putString(k, l.joinToString("\n")) }
            }
        }
        e.apply()
    }

    /** छूते-छूते उँगली 👆 आपकी उँगली के साथ चले (सेटिंग बंद हो तब भी, सिखाते समय) */
    private fun fingerFollow(x: Float, y: Float) {
        handler.post {
            if (fxLayer() == null) return@post
            val f = fxFinger ?: return@post
            val d = resources.displayMetrics.density
            handler.removeCallbacks(fxHide)
            f.animate().cancel(); f.alpha = 1f
            f.translationX = x - 24 * d; f.translationY = y - 6 * d
        }
    }

    /** उँगली जहाँ छोड़ी वहाँ असली टैप भेजो और उसका संदर्भ (बटन का नाम/ID + स्क्रीन पर जगह %) याद रखो */
    private fun teachTap(x: Float, y: Float) {
        ptr(x, y)
        val dm = resources.displayMetrics
        var lab = ""; var id = ""
        rootInActiveWindow?.let { val h = adNodeAt(it, x, y); lab = h.first; id = h.second }
        val st = JSONObject().put("x", x / dm.widthPixels * 100.0).put("y", y / dm.heightPixels * 100.0).put("l", lab).put("i", id)
        adTaughtN++
        adRecord(st)
        val path = Path().apply { moveTo(x, y) }
        dg(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 60)).build(), null, null)
    }

    /** (x, y) पर सबसे छोटा नाम/ID वाला बटन-जैसा हिस्सा (पूरी स्क्रीन वाले बड़े हिस्से छोड़कर) */
    private fun adNodeAt(root: AccessibilityNodeInfo, x: Float, y: Float): Pair<String, String> {
        val dm = resources.displayMetrics
        val maxA = dm.widthPixels.toLong() * dm.heightPixels / 2
        var best: AccessibilityNodeInfo? = null; var bestA = Long.MAX_VALUE; var c = 0
        val r = Rect()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || ++c > 900) return
            n.getBoundsInScreen(r)
            if (r.contains(x.toInt(), y.toInt()) && n.isVisibleToUser) {
                val a = r.width().toLong() * r.height()
                val info = n.isClickable || !n.text.isNullOrEmpty() || !n.contentDescription.isNullOrEmpty() || !n.viewIdResourceName.isNullOrEmpty()
                if (info && a in 1 until maxA && a < bestA) { best = n; bestA = a }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        val b = best ?: return Pair("", "")
        return Pair(adLabel(b), b.viewIdResourceName?.substringAfter('/') ?: "")
    }

    /** सीखा हुआ एक टैप दोहराओ: पहले ID/नाम से बटन ढूँढो, न मिले तो स्क्रीन पर वही % जगह टैप */
    private fun adTapTarget(root: AccessibilityNodeInfo, st: JSONObject): AdCand? {
        val id = st.optString("i"); val lab = st.optString("l")
        val cands = adCandidates(root)
        return cands.firstOrNull { id.isNotEmpty() && it.node.viewIdResourceName?.substringAfter('/') == id }
            ?: cands.firstOrNull { lab.isNotEmpty() && adLabel(it.node) == lab }
    }

    /** स्क्रीन कुछ-कुछ अलग हो तो भी: सीखी हुई सारी स्क्रीन को इस स्क्रीन से मिलान के क्रम में (सबसे मिलती पहले) देखो और
     *  जिसका सिखाया बटन इस स्क्रीन पर सच में मौजूद हो उसे दबाओ. बटन न दिखे तो अंदाज़े की जगह टैप नहीं करता. true = कुछ दबाया */
    private fun adTryLearned(root: AccessibilityNodeInfo, all: JSONArray): Boolean {
        val pkg = root.packageName?.toString() ?: return false
        val toks = adTokens(root); val th = adThumb()
        val order = ArrayList<Pair<Double, Int>>()
        for (k in 0 until all.length()) {
            val e = all.optJSONObject(k) ?: continue
            if (e.optString("p") != pkg) continue
            val et = HashSet<String>()
            e.optJSONArray("t")?.let { for (j in 0 until it.length()) et.add(it.optString(j)) }
            var sc = 0.0
            if (et.isNotEmpty() && toks.isNotEmpty()) { val inter = toks.count { it in et }; sc = inter.toDouble() / (toks.size + et.size - inter) }
            val d = thumbDiff(e.optString("th"), th)
            if (d >= 0) sc += (1.0 - minOf(d, 100.0) / 100.0) * 0.3
            if (e.optString("w") == adWinClass) sc += 0.05
            order.add(Pair(sc, k))
        }
        order.sortByDescending { it.first }
        for ((_, k) in order) {
            val taps = all.getJSONObject(k).optJSONArray("taps") ?: continue
            for (j in 0 until taps.length()) {
                val key = "$k:$j"
                if (key in adTriedTaps) continue
                val st = taps.getJSONObject(j)
                val hit = adTapTarget(root, st) ?: continue
                adTriedTaps.add(key)
                toast("🧠 सीखे हुए में से आज़माया (${st.optString("l").ifEmpty { "बटन" }})")
                if (!clickNode(hit.node)) adTap(hit.r.exactCenterX(), hit.r.exactCenterY())
                return true
            }
        }
        return false
    }

    private fun adReplay(root: AccessibilityNodeInfo, st: JSONObject, n: Int, tot: Int) {
        val hit = adTapTarget(root, st)
        toast("🧠 सीखा हुआ टैप $n/$tot")
        if (hit != null) { if (!clickNode(hit.node)) adTap(hit.r.exactCenterX(), hit.r.exactCenterY()) }
        else {
            val dm = resources.displayMetrics
            adTap((st.optDouble("x") / 100.0 * dm.widthPixels).toFloat(), (st.optDouble("y") / 100.0 * dm.heightPixels).toFloat())
        }
    }

    // ---------- स्क्रीनशॉट से स्क्रीन का मिलान ----------
    private fun checkGate(file: String, my: Int) {
        val ref = loadTemplate(file)
        if (ref == null) { toast("स्क्रीनशॉट फाइल नहीं मिली"); return }
        if (Build.VERSION.SDK_INT >= 30) {
            busy = true
            shotApi30 { bmp -> finishGate(bmp, ref, my) }
        } else {
            val cs = CaptureService.instance
            if (cs == null) {
                if (System.currentTimeMillis() % 5 == 0L) toast("मुख्य ऐप में 'स्क्रीन कैप्चर अनुमति' दें")
                return
            }
            busy = true
            bg.execute { finishGate(cs.capture(), ref, my) }
        }
    }

    private fun finishGate(bmp: Bitmap?, ref: Bitmap, my: Int) {
        val ok = bmp != null && sameScreen(bmp, ref)
        handler.post {
            busy = false
            if (running && index == my && ok) gateOkIdx = my
        }
    }

    /** पूरी स्क्रीन की तुलना (स्टेटस बार/नेव बार छोड़कर). थोड़ा फ़र्क चलता है; मिलान % सेटिंग में बदल सकते हैं */
    private fun sameScreen(scr: Bitmap, ref: Bitmap): Boolean {
        val w = 54; val h = 96
        val a = gray(Bitmap.createScaledBitmap(scr, w, h, true), w, h)
        val b = gray(Bitmap.createScaledBitmap(ref, w, h, true), w, h)
        val y0 = (h * 0.06).toInt(); val y1 = h - (h * 0.06).toInt()
        var same = 0; var tot = 0
        for (y in y0 until y1) for (x in 0 until w) {
            tot++
            if (abs(a[y * w + x] - b[y * w + x]) <= 28) same++
        }
        val need = getSharedPreferences("apps", MODE_PRIVATE).getInt("gatePct", 90)
        return tot > 0 && same * 100 >= need * tot
    }

    // ---------- फोटो से खोजना ----------
    private fun loadTemplate(name: String): Bitmap? = tplCache.getOrPut(name) {
        BitmapFactory.decodeFile(File(filesDir, name).path)
    }

    private fun findAndTapImage(cmd: String, dir: String? = null) {
        val tpl = loadTemplate(cmd.substringAfterLast(":")) ?: return
        val my = index
        if (Build.VERSION.SDK_INT >= 30) {
            busy = true
            shotApi30 { bmp -> finishMatch(bmp, tpl, my, dir) }
        } else {
            val cs = CaptureService.instance
            if (cs == null) {
                if (System.currentTimeMillis() % 5 == 0L) toast("मुख्य ऐप में 'स्क्रीन कैप्चर अनुमति' दें")
                return
            }
            busy = true
            bg.execute { finishMatch(cs.capture(), tpl, my, dir) }
        }
    }

    @android.annotation.TargetApi(30)
    private fun shotApi30(done: (Bitmap?) -> Unit) {
        takeScreenshot(Display.DEFAULT_DISPLAY, bg, object : AccessibilityService.TakeScreenshotCallback {
            override fun onSuccess(r: AccessibilityService.ScreenshotResult) {
                val hb = r.hardwareBuffer
                val bmp = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)?.copy(Bitmap.Config.ARGB_8888, false)
                hb.close()
                done(bmp)
            }
            override fun onFailure(code: Int) { done(null) }
        })
    }

    /** (bg थ्रेड पर) मिलान करो, फिर मुख्य थ्रेड पर टैप (dir खाली) या स्वाइप */
    private fun finishMatch(bmp: Bitmap?, tpl: Bitmap, my: Int, dir: String?) {
        val pos = if (bmp != null) match(bmp, tpl) else null
        handler.post {
            if (!running || index != my || pos == null) {
                busy = false
                if (running && index == my && pos == null) altRot++      // फोटो नहीं मिली: दूसरी कमांड की बारी
                return@post
            }
            if (dir == null) {
                val path = Path().apply { moveTo(pos.first.toFloat(), pos.second.toFloat()) }
                runGesture(path, 60, my)
            } else swipeAt(pos.first, pos.second, dir, my)
        }
    }

    /** (cx, cy) के आसपास उंगली से स्वाइप. left = उंगली दाएँ से बाएँ चलेगी */
    private fun swipeAt(cx: Int, cy: Int, dir: String, my: Int) {
        val dm = resources.displayMetrics
        val w = dm.widthPixels; val h = dm.heightPixels
        val hx = (w * 0.30f).toInt(); val hy = (h * 0.20f).toInt()
        fun cx_(v: Int) = v.coerceIn(20, w - 20)
        fun cy_(v: Int) = v.coerceIn(20, h - 20)
        val (sx, sy, ex, ey) = when (dir) {
            "left" -> listOf(cx + hx, cy, cx - hx, cy)
            "right" -> listOf(cx - hx, cy, cx + hx, cy)
            "up" -> listOf(cx, cy + hy, cx, cy - hy)
            else -> listOf(cx, cy - hy, cx, cy + hy)   // down
        }
        val path = Path().apply {
            moveTo(cx_(sx).toFloat(), cy_(sy).toFloat())
            lineTo(cx_(ex).toFloat(), cy_(ey).toFloat())
        }
        runGesture(path, 350, my)
    }

    private fun runGesture(path: Path, dur: Long, my: Int) {
        busy = true
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(pt(path), 0, dur)).build()
        val ok = dg(g, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) {
                busy = false
                if (running && index == my && advance()) {
                    handler.removeCallbacks(tick); handler.postDelayed(tick, 450)
                }
            }
            override fun onCancelled(d: GestureDescription?) { busy = false }
        }, null)
        if (!ok) busy = false
    }

    private fun gray(b: Bitmap, w: Int, h: Int): IntArray {
        val px = IntArray(w * h)
        b.getPixels(px, 0, w, 0, 0, w, h)
        for (i in px.indices) {
            val c = px[i]
            px[i] = (((c shr 16) and 255) * 3 + ((c shr 8) and 255) * 6 + (c and 255)) / 10
        }
        return px
    }

    /** रिव्यू फोटो का रंग समेत मिलान: पहले जगह ढूँढो (ग्रे, ढीला), फिर उसी जगह का रंग (R,G,B) हूबहू देखो.
     *  हल्का लाल बनाम बिना रंग वाला (एक ही लिखावट) अलग माना जाएगा */
    private fun matchReview(scr: Bitmap, tpl: Bitmap, maxDiff: Double): Boolean {
        if (tpl.width > scr.width || tpl.height > scr.height) return false
        val pos = match(scr, tpl, 45.0) ?: return false
        val x0 = (pos.first - tpl.width / 2).coerceIn(0, scr.width - tpl.width)
        val y0 = (pos.second - tpl.height / 2).coerceIn(0, scr.height - tpl.height)
        val crop = Bitmap.createBitmap(scr, x0, y0, tpl.width, tpl.height)
        val w = 48
        val h = (48f * tpl.height / tpl.width).toInt().coerceIn(8, 96)
        val a = Bitmap.createScaledBitmap(crop, w, h, true)
        val b = Bitmap.createScaledBitmap(tpl, w, h, true)
        var sum = 0L
        for (y in 0 until h) for (x in 0 until w) {
            val pa = a.getPixel(x, y); val pb = b.getPixel(x, y)
            sum += abs(((pa shr 16) and 0xFF) - ((pb shr 16) and 0xFF)) +
                   abs(((pa shr 8) and 0xFF) - ((pb shr 8) and 0xFF)) +
                   abs((pa and 0xFF) - (pb and 0xFF))
        }
        return sum / (w * h * 3.0) < maxDiff
    }

    /** स्क्रीनशॉट में फोटो की सबसे मिलती जगह (केंद्र x, y) या null */
    private fun match(scr: Bitmap, tpl: Bitmap, maxAvg: Double = 15.0): Pair<Int, Int>? {
        val f = 2                       // तेज़ी के लिए आधा आकार
        val sw = scr.width / f; val sh = scr.height / f
        val tw = tpl.width / f; val th = tpl.height / f
        if (tw < 4 || th < 4 || tw > sw || th > sh) return null
        val S = gray(Bitmap.createScaledBitmap(scr, sw, sh, true), sw, sh)
        val T = gray(Bitmap.createScaledBitmap(tpl, tw, th, true), tw, th)
        var best = Long.MAX_VALUE; var bx = -1; var by = -1
        var y = 0
        while (y <= sh - th) {
            var x = 0
            while (x <= sw - tw) {
                var sum = 0L
                for (ty in 0 until th) {
                    val so = (y + ty) * sw + x; val to = ty * tw
                    for (tx in 0 until tw) sum += abs(S[so + tx] - T[to + tx])
                    if (sum >= best) break
                }
                if (sum < best) { best = sum; bx = x; by = y }
                x += 2
            }
            y += 2
        }
        val avg = best.toDouble() / (tw * th)
        return if (avg < maxAvg) Pair((bx + tw / 2) * f, (by + th / 2) * f) else null
    }

    /** अगली कमांड पर जाओ; सब पूरी हों तो false */
    private fun stepDelay(st: String): Int =
        stripLimit(st).let { t -> if (t.contains("~~")) t.substringAfterLast("~~").toIntOrNull() ?: 0 else 0 }

    /** applyDelay=false: कमांड छूटी (नहीं मिली) तो उसका टाइमर नहीं लगेगा */
    /** इस कमांड नंबर पर लिखे "गलती के संदेश" (हर लाइन एक टेक्स्ट) */
    private fun failTextFor(n: Int): List<String> =
        getSharedPreferences("apps", MODE_PRIVATE).getString("failText", "")!!.split("\n").filter { it.isNotBlank() }
            .filter { it.substringBefore("|").toIntOrNull() == n }
            .flatMap { it.substringAfter("|").split("¦") }.map { nz(it) }.filter { it.isNotEmpty() }

    /** तुलना के लिए: छोटे अक्षर, सिर्फ़ अक्षर-अंक (स्पेस, "-", "!" आदि हटाकर). "Repeated check-in" ≈ "repeated Check In!" */
    private fun nz(s: String): String = s.lowercase().filter { it.isLetterOrDigit() }

    private fun treeHasText(n: AccessibilityNodeInfo?, ft: List<String>): Boolean {
        if (n == null) return false
        val t = nz(listOfNotNull(n.text?.toString(), n.contentDescription?.toString()).joinToString(" "))
        if (t.isNotEmpty() && ft.any { t.contains(it) }) return true       // स्क्रीन का वाक्य लंबा हो (आगे के शब्द अलग) तब भी लिखा हुआ हिस्सा मिल जाए
        for (i in 0 until n.childCount) if (treeHasText(n.getChild(i), ft)) return true
        return false
    }

    /** स्क्रीन (सारी विंडो) या अभी आए टोस्ट/इवेंट में गलती का टेक्स्ट दिखा? */
    private fun failSeen(ft: List<String>, since: Long): String? {
        try { synchronized(recentTexts) { if (recentTexts.any { it.first >= since && ft.any { f -> nz(it.second).contains(f) } }) return "इवेंट/टोस्ट" } } catch (e: Exception) {}
        try { if (treeHasText(rootInActiveWindow, ft)) return "स्क्रीन" } catch (e: Exception) {}
        try { for (w in windows) if (treeHasText(w.root, ft)) return "विंडो" } catch (e: Exception) {}
        return null
    }

    /** गिनती वाला काम चालू है और कोई कमांड छूट गई: ❌ क्रॉस; आगे की कमांड/रिव्यू फोटो नहीं; सीधे अगला (कमांड 1 से). लगातार 2/3 क्रॉस के नियम वैसे ही लागू */
    private fun countMiss() {
        toast("❌ कमांड ${index + 1} नहीं मिली → क्रॉस; आगे की कमांड और रिव्यू नहीं, अगला कमांड 1 से")
        skippedThisApp = true
        reviewPending = false; forceReview = false; rvFromTimeout = false
        if (numCur.isEmpty()) {            // अभी तक कोई कॉपी क्लिक ही नहीं हुई थी: फिर भी यह क्रॉस गिनो, और अगला नंबर चलने दो
            crossStreak++
            IpLog.addFail(this, getSharedPreferences("apps", MODE_PRIVATE).getString("ipCur", "") ?: "")
            numPassClicks = maxOf(numPassClicks, 1)
        }
        index = 0; gateOkIdx = -1; multiTried = 0; clickPending = false
        finish()
    }

    /** गलती का संदेश दिखा: यह कॉपी ❌ क्रॉस, रिव्यू फोटो नहीं खोजनी, आगे की कमांड नहीं; सीधे अगला (क्रॉस वाला रास्ता: IP/फोर्स स्टॉप, दूसरे राउंड में फिर) */
    private fun countFail(seen: List<String>, via: String) {
        toast("❌ गलती का संदेश दिखा (${seen.firstOrNull() ?: ""}, $via से) → क्रॉस, अगला खुलेगा")
        skippedThisApp = true
        reviewPending = false; forceReview = false; rvFromTimeout = false
        crossStreak = maxOf(crossStreak, 1)       // गलती का संदेश मिला: इसी पर 2 क्रॉस पूरे हों ताकि फोर्स स्टॉप + दूसरा IP तुरंत हो
        index = 0; gateOkIdx = -1; multiTried = 0; clickPending = false
        finish()
    }

    private fun advance(applyDelay: Boolean = true): Boolean {
        // गिनती वाला काम चालू हो और इस कमांड पर गलती का संदेश लिखा हो: क्लिक के बाद कुछ सेकंड स्क्रीन देखो, संदेश दिखे तो ❌
        if (applyDelay && !failWatching && index < steps.size && steps.any { numOfStep(it) != null }) {
            val ft = failTextFor(index + 1)
            if (ft.isNotEmpty()) {
                failWatching = true
                val start = System.currentTimeMillis()
                val since = start - 1500                                    // क्लिक के ठीक पहले-साथ आया संदेश भी गिनो (इवेंट का टेक्स्ट पहले से याद रखा जा रहा है)
                holdUntil = start + 9000; stepStart = holdUntil            // देखते समय अगली कमांड रुकी रहे
                fun poll() {
                    if (!running) { failWatching = false; return }
                    val via = failSeen(ft, since)
                    if (via != null) { failWatching = false; holdUntil = 0L; countFail(ft, via); return }
                    val el = System.currentTimeMillis() - start
                    if (el >= 5000) {
                        failWatching = false; holdUntil = 0L
                        if (advanceCore(true)) { handler.removeCallbacks(tick); handler.postDelayed(tick, 300) }
                        return
                    }
                    badge?.text = "👀 गलती का संदेश देख रहे हैं… ${(5000 - el) / 1000 + 1}"
                    handler.postDelayed({ poll() }, 120)
                }
                poll()
                return true
            }
        }
        return advanceCore(applyDelay)
    }

    private fun advanceCore(applyDelay: Boolean = true): Boolean {
        val d = if (applyDelay && index < steps.size) stepDelay(steps[index]) else 0
        index++; gateOkIdx = -1; multiTried = 0; clickPending = false
        numSeen.clear(); numPageRange = null; numScanComplete = false; numCurTarget = -1
        rvPreDoneIdx = -1; rvFromTimeout = false
        reviewMissKey = -1; reviewCheckedIdx = -1        // अगली बार (नंबर वाले अगले राउंड में भी) इस कमांड पर रिव्यू फोटो फिर जाँची जाएगी
        numScrolled = false; numFwd = true; numEdges = 0; numScrolls = 0; numRangeTapped.clear(); numCloseStage = 0; numCloses = 0
        altRetries = 0
        if (index >= steps.size) {
            if (d > 0) handler.postDelayed({ if (running) finish() }, d * 1000L) else finish()
            return false
        }
        holdUntil = System.currentTimeMillis() + d * 1000L
        stepStart = holdUntil
        updateBadge()
        return true
    }

    /** सूची को स्क्रॉल (आगे/पीछे). सबसे बड़ी स्क्रॉल होने वाली जगह पर; न मिले तो स्वाइप */
    private fun numScroll(root: AccessibilityNodeInfo, fwd: Boolean) {
        var best: AccessibilityNodeInfo? = null
        var bestArea = 0
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            if (n.isScrollable && n.isVisibleToUser) {
                val r = Rect(); n.getBoundsInScreen(r)
                val a = r.width() * r.height()
                if (a > bestArea) { bestArea = a; best = n }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        val act = if (fwd) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        val b = best
        if (b != null && b.performAction(act)) return
        val dm = resources.displayMetrics
        val x = dm.widthPixels / 2f
        val y1 = dm.heightPixels * (if (fwd) 0.70f else 0.35f)
        val y2 = dm.heightPixels * (if (fwd) 0.35f else 0.70f)
        val path = Path().apply { moveTo(x, y1); lineTo(x, y2) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(pt(path), 0, 350)).build()
        dg(g, null, null)
    }

    /** नंबर वाली कमांड में अब और नंबर नहीं मिले: complete=true तो ऐप पूरा माना जाए (✅), वरना कमांड छूटी */
    /** स्क्रीन पर दिखे वे टेक्स्ट जिनमें दो संख्याएँ हों (जैसे "51–100", "कॉपी 51 से 100") — पहचान न होने पर यही दिखाकर पता चलता है कि कोड को क्या दिखा */
    private fun rangeHints(root: AccessibilityNodeInfo?): String {
        val out = LinkedHashSet<String>()
        val re = Regex("\\d+\\D{1,12}\\d+")
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || out.size >= 6) return
            val t = (n.text ?: n.contentDescription)?.toString()?.trim()
            if (t != null && t.length <= 60 && n.isVisibleToUser && re.containsMatchIn(t)) out.add(t)
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return out.joinToString("  |  ")
    }

    /** अपना ऐप (नंबर की स्थिति वाली सूची) सामने लाओ */
    private fun bringSelfToFront() {
        try {
            startActivity(Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP))
        } catch (e: Exception) {}
    }

    /**
     * ग्रिड से "सिर्फ़ यही कॉपी खोलो" चल रहा है और कॉपी नहीं मिली (है ही नहीं): कोई ✅ नहीं.
     * जुड़ा ऐप बंद/मिनिमाइज़ करो (VPN और अपना ऐप सुरक्षित, "बंद करने का तरीका" की सेटिंग के हिसाब से), फिर अपना ऐप सामने लाओ ताकि वही नंबर की सूची दिखे
     */
    private fun numOnlyNotFound(): Boolean {
        if (numOnlyNG < 0) return false
        val n = numOnlyNG
        val hints = try { rangeHints(rootInActiveWindow) } catch (e: Exception) { "" }
        Toast.makeText(this, "⚠ कॉपी $n नहीं मिली (शायद है ही नहीं), ऐप बंद करके वापस ले जा रहे हैं." + (if (hints.isNotEmpty()) "\nस्क्रीन पर दिखे रेंज जैसे टेक्स्ट: $hints" else ""), Toast.LENGTH_LONG).show()
        val pkg = queue.getOrNull(qIndex)
        numOnlyNG = -1; numOnlyKeyG = ""                 // दोबारा इसी रास्ते में न आओ (और बंद करने में पूरी रेंज दिखे)
        // पेज पूरा देखा जा चुका हो तो जो नंबर उसमें हैं ही नहीं, वे सब अभी सफ़ेद (है ही नहीं) कर दो; अगली बार उन पर दबाना बेअसर रहेगा
        lastNumCmd?.let { try { numMarkMissingScan(it) } catch (e: Exception) {} }
        holdUntil = System.currentTimeMillis() + 60000     // बंद करते समय नंबर वाली खोज रुकी रहे
        val back = { stop(); bringSelfToFront() }
        if (pkg != null && !pkg.startsWith("home:")) closeThen(pkg) { back() } else back()
        return true
    }

    private var numWhy = ""           // गिनती रुकने की वजह (आख़िरी संदेश में दिखाने के लिए)

    private fun numGiveUp(complete: Boolean): Boolean {
        if (numOnlyNotFound()) return false
        numWhy = "नंबर " + (if (numCurTarget >= 0) numCurTarget.toString() else "अगला") + " इस ऐप की पूरी सूची घूमकर भी नहीं मिला"
        toast("⚠ $numWhy")
        numExhausted = true
        if (complete) index = steps.size - 1 else skippedThisApp = true
        return advance(false)
    }

    /** राउंड पूरा: जिस नंबर पर क्लिक हुआ था वह सारी कमांड सफल रहीं तो ✅ (हरा), वरना 🔴 (लाल, दोबारा कोशिश होगी) */
    private fun numCommit() {
        numAllowRed = false
        if (numCur.isEmpty()) return
        numLastNums = numCur.values.toList()
        val sp = getSharedPreferences("apps", MODE_PRIVATE)
        for ((cmd, n) in numCur) {
            val p = numParse(cmd) ?: continue
            val done = numDone(sp, numKey(cmd))
            val failed = numFailed(sp, numFailKey(cmd))
            if (!skippedThisApp) { done.add(n); failed.remove(n); toast("${p.third} $n ✅"); sp.edit().putInt("ipCount", sp.getInt("ipCount", 0) + 1).apply(); IpLog.addCopy(this, sp.getString("ipCur", "") ?: ""); IpNum.record(this, numKey(cmd), sp.getString("ipCur", "") ?: "", n); histKey = "" }
            else { failed[n] = (failed[n] ?: 0) + 1; toast("${p.third} $n 🔴 (फिर कोशिश होगी)"); numAllowOther = true }      // रिकॉर्ड वैसा ही रहे, पर इस IP/देश पर न चले तो दूसरे IP/देश पर भी चल सकेगा (और वहीं दर्ज होगा)
            sp.edit().putString(numKey(cmd), done.sorted().joinToString(","))
                .putString(numFailKey(cmd), failed.entries.sortedBy { it.key }.joinToString(",") { "${it.key}:${it.value}" }).apply()
        }
        if (skippedThisApp) { crossStreak++; IpLog.addFail(this, sp.getString("ipCur", "") ?: "") } else crossStreak = 0      // एक बार में एक ही गिनती; फेल हुआ तो अभी वाले IP की फेल-गिनती +1
        numCur.clear()
        try { updateBadge() } catch (e: Exception) {}
    }

    /** आख़िर में भी कोई नंबर 🔴 बचा हो तो ऐप ⚠ (पूरा नहीं) दिखे */
    private fun numFinalCheck() {
        val sp = getSharedPreferences("apps", MODE_PRIVATE)
        for (st in steps) {
            val c = numOfStep(st) ?: continue
            val done = numDone(sp, numKey(c))
            if (numFailed(sp, numFailKey(c)).any { it.key !in done && it.value < 99 }) skippedThisApp = true
        }
    }

    /** सारी नंबर वाली कमांड की सीमा मिलाकर (सबसे छोटा..सबसे बड़ा); कोई नहीं तो null */
    private fun numRange(): IntRange? {
        var lo = Int.MAX_VALUE; var hi = Int.MIN_VALUE
        for (st in steps) {
            val p = numOfStep(st)?.let { numParse(it) } ?: continue
            lo = minOf(lo, p.first); hi = maxOf(hi, p.second)
        }
        return if (lo <= hi) lo..hi else null
    }

    /** Recents खोलकर उन सारे कार्ड को ऊपर स्वाइप करो जिनके नाम में नंबर (जैसे 37, 37B, D37) सीमा के अंदर हो — पहले अभी वाला नंबर */
    private fun closeNumCardsThen(queueToo: Boolean = false, go: () -> Unit) {
        val r = numRange()
        if (r == null) { go(); return }
        closePkg = "recents"; afterClose = go
        rNumRange = r; rNumCur = numLastNums + numCur.values
        val sp = getSharedPreferences("apps", MODE_PRIVATE)
        val prot = HashSet<String>()
        prot.addAll(labelsOfPkg(packageName))
        val vpn = sp.getString("vpnPkg", "") ?: ""
        if (vpn.isNotEmpty()) prot.addAll(labelsOfPkg(vpn))
        // जुड़े ऐप: "मिनिमाइज़ करके बंद" मोड में इसी चक्कर में हटेंगे (queueToo); बाकी मोड में कभी नहीं छूने
        val qs = HashSet<String>()
        for (q in queue) qs.addAll(labelsOfPkg(q))
        if (queueToo) rQueue = qs else { rQueue = emptySet(); prot.addAll(qs) }
        val pl = protectedLabels()
        prot.addAll(pl); rQueue = rQueue - pl
        rProtect = prot
        rClearAll = sp.getBoolean("numClearAll", false)
        rLabels = installedLabels()
        rTries.clear(); rLog.clear(); rSeen.clear()
        rLabel = ""; rAttempts = 0; rNotFound = 0
        closeStart = System.currentTimeMillis()
        handler.removeCallbacks(tick)
        performGlobalAction(GLOBAL_ACTION_RECENTS)
        handler.postDelayed(recentsStep, 1300)
    }

    // ---------- सुरक्षित ऐप: चुने हुए ऐप Recents से कभी नहीं हटेंगे, बंद भी नहीं होंगे ----------
    private fun protectedPkgs(): Set<String> =
        getSharedPreferences("apps", MODE_PRIVATE).getString("protectPkgs", "")!!
            .split("\n").map { it.trim() }.filter { it.isNotEmpty() }.toSet()

    private fun protectedLabels(): Set<String> {
        val out = HashSet<String>()
        protectedPkgs().forEach { out.addAll(labelsOfPkg(it)) }
        getSharedPreferences("apps", MODE_PRIVATE).getString("protectNames", "")!!
            .split("\n").map { it.trim().lowercase() }.filter { it.isNotEmpty() }.forEach { out.add(it) }
        return out
    }

    /** ऐप के सारे नाम: ऐप का नाम + लॉन्चर वाली गतिविधियों के नाम (Recents में कार्ड पर इनमें से कोई दिख सकता है). होम शॉर्टकट हो तो उसका नाम */
    private fun labelsOfPkg(pkg: String): Set<String> {
        val out = HashSet<String>()
        if (pkg.startsWith("home:")) { out.add(pkg.removePrefix("home:").trim().lowercase()); return out }
        try { out.add(packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString().trim().lowercase()) } catch (e: Exception) {}
        try {
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setPackage(pkg)
            packageManager.queryIntentActivities(i, 0).forEach { out.add(it.loadLabel(packageManager).toString().trim().lowercase()) }
        } catch (e: Exception) {}
        out.remove("")
        return out
    }

    private fun isProtectedLabel(tl: String): Boolean = rProtect.any { p ->
        tl == p || (p.length >= 4 && (tl.contains(p) || (tl.length >= 4 && p.contains(tl))))
    }

    private val numRe = Regex("(?<!\\d)(\\d{1,9})(?!\\d)")
    private fun numsIn(t: String): List<Int> =
        if (t.length > 40 || t.contains(':') || t.contains('%')) emptyList()
        else numRe.findAll(t).mapNotNull { it.groupValues[1].toIntOrNull() }.toList()

    private fun installedLabels(): Set<String> = try {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        packageManager.queryIntentActivities(i, 0)
            .map { it.loadLabel(packageManager).toString().trim().lowercase() }
            .filter { it.isNotEmpty() }.toSet()
    } catch (e: Exception) { emptySet() }

    /** Recents में हटाने लायक कार्ड, तीन दर्जे: (1) नाम में अभी वाला नंबर, (2) नाम में सीमा का कोई और नंबर, (3) फ़ोन का कोई और ऐप.
     *  नंबर वाले कार्ड हमेशा पहले; VPN, अपना ऐप और सुरक्षित ऐप के नाम वाले कार्ड कभी नहीं (पर नंबर वाला कार्ड सुरक्षित नहीं माना जाता
     *  जब तक उसका पूरा नाम ही सुरक्षित नाम न हो). (कार्ड का इलाका, पहचान) */
    private fun findRecentNumCard(range: IntRange, cur: List<Int>): Pair<Rect, String>? {
        val roots = ArrayList<AccessibilityNodeInfo>()
        rootInActiveWindow?.let { roots.add(it) }
        try { windows.forEach { w -> w.root?.let { roots.add(it) } } } catch (e: Exception) {}
        val dm = resources.displayMetrics
        val screen = Rect(0, 0, dm.widthPixels, dm.heightPixels)
        val screenArea = dm.widthPixels.toLong() * dm.heightPixels
        val best = arrayOfNulls<Pair<Rect, String>>(4)
        val bestA = LongArray(4)
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            val ts = listOf(n.text, n.contentDescription).mapNotNull { it?.toString()?.trim() }
                .filter { it.isNotEmpty() && it.length <= 60 }
            for (t in ts) {
                val tl = t.lowercase()
                if (t.length <= 40 && rSeen.size < 40) rSeen.add(t)
                val nums = numsIn(t)
                val numMatch = nums.any { it in range }
                val tier: Int
                val isQueue = rQueue.any { p -> tl == p || (p.length >= 4 && (tl.contains(p) || (tl.length >= 4 && p.contains(tl)))) }
                if (isQueue) {
                    tier = 2                                   // जुड़ा ऐप (सिर्फ़ मिनिमाइज़ मोड में), नंबर वाले कार्ड के बाद
                } else if (numMatch) {
                    if (isProtectedLabel(tl)) continue      // VPN/App Control का कार्ड नंबर वाला नहीं माना जाएगा
                    tier = if (nums.any { it in cur }) 0 else 1
                } else {
                    if (!rClearAll || isProtectedLabel(tl) || tl !in rLabels) continue
                    tier = 3
                }
                if ((rTries[tl] ?: 0) >= 4) continue
                val r = Rect(); n.getBoundsInScreen(r)
                if (!r.intersect(screen) || r.isEmpty) continue
                val area = r.width().toLong() * r.height()
                if (area > screenArea * 0.6) continue
                if (area > bestA[tier]) { best[tier] = Pair(r, tl); bestA[tier] = area }
                break
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        for (r in roots) if (r.packageName != packageName) walk(r)
        return best[0] ?: best[1] ?: best[2] ?: best[3]
    }

    /** ऐप को मिनिमाइज़ करके Recents में उसका कार्ड ऊपर स्वाइप (बैकग्राउंड से हटाना); शॉर्टकट वाली एंट्री में बंद करना छोड़ो */
    private fun closeRecentsThen(pkg: String, go: () -> Unit) {
        if (pkg.startsWith("home:")) closeThen(pkg, go) else closeViaRecents(pkg, go)
    }

    /** पूरी कमांड-सूची एक बार चल चुकी; बाकी (या 🔴) नंबर हैं और इस बार किसी नंबर पर काम हुआ तो उसी ऐप में फिर से शुरू */
    /** नंबर वाली कमांड में अभी कोई नंबर बाकी है (न हुआ, न छोड़ा गया)? */
    private fun numHasRemaining(): Boolean {
        val sp = getSharedPreferences("apps", MODE_PRIVATE)
        return steps.any { st ->
            val c = numOfStep(st)
            val p = if (c != null) numParse(c) else null
            if (c == null || p == null) false
            else {
                val done = numDone(sp, numKey(c))
                val exh = numFailed(sp, numFailKey(c)).count { it.value >= NUM_MAX_FAILS && it.key !in done && it.key in p.first..p.second }
                done.count { it in p.first..p.second } + exh < (p.second - p.first + 1)
            }
        }
    }

    /** गिनती वाला काम रुका पर नंबर बाकी हों तो साफ़ बताओ: कितने ✅, कितने बाकी, अगला कौन-सा और रुकने की वजह */
    private fun numRemainingText(): String {
        val sp = getSharedPreferences("apps", MODE_PRIVATE)
        for (st in steps) {
            val c = numOfStep(st) ?: continue
            val p = numParse(c) ?: continue
            val done = numDone(sp, numKey(c))
            val left = (p.first..p.second).filter { it !in done }
            if (left.isNotEmpty())
                return "\n🔢 ${p.second - p.first + 1 - left.size} ✅, बाकी ${left.size} (अगला: ${left.first()})" + (if (numWhy.isNotEmpty()) " — वजह: $numWhy" else "")
        }
        return ""
    }

    private var numLoopBase = 0       // पिछले दौर के अंत में कुल कितने नंबर ✅ थे

    /** सारी नंबर वाली कमांड में रेंज के अंदर कुल कितने नंबर ✅ हो चुके */
    private fun numDoneTotal(): Int {
        val sp = getSharedPreferences("apps", MODE_PRIVATE)
        var t = 0
        for (st in steps) {
            val c = numOfStep(st) ?: continue
            val p = numParse(c) ?: continue
            t += numDone(sp, numKey(c)).count { it in p.first..p.second }
        }
        return t
    }

    private fun numRepeat(): Boolean {
        if (!running || numExhausted || numPassClicks <= 0 || numOnlyNG >= 0) return false      // एक नंबर वाला रन दोहराया नहीं जाता
        val sp = getSharedPreferences("apps", MODE_PRIVATE)
        val remaining = numHasRemaining()
        if (!remaining) return false
        // इस राउंड में कमांड फेल हुई थी: एक क्रॉस पर सिर्फ़ आगे बढ़ो; लगातार 2 क्रॉस हों तब ही फोर्स स्टॉप + VPN/नया IP
        val failedPass = skippedThisApp && crossStreak >= 2
        numPassClicks = 0
        skippedThisApp = false
        index = 0; gateOkIdx = -1; multiTried = 0; clickPending = false
        val pkg = queue.getOrNull(qIndex)
        val closer: (() -> Unit) -> Unit = { g -> if (pkg != null) closeThen(pkg, g) else closeNumCardsThen(false, g) }
        closer {                                     // नंबर वाले कार्ड हटाओ + जुड़े ऐप पर ऊपर की सेटिंग लगाओ
            if (pkg != null) {
                val go = {
                    armReview()
                    stepStart = System.currentTimeMillis() + 3000
                    launchApp(pkg, false)
                    updateBadge()
                    handler.removeCallbacks(tick); handler.postDelayed(tick, 3000)
                }
                // क्रॉस (❌) आया: जुड़े ऐप को फोर्स स्टॉप करो → नया IP (पहले जैसा) → ऐप फिर खोलकर सारी कमांड शुरू से
                if (failedPass) forceStopThen(pkg) { crossThen(true, true) { seekThen { go() } } } else seekThen { go() }
            } else {
                val go = {
                    stepStart = System.currentTimeMillis() + 1500
                    updateBadge()
                    handler.removeCallbacks(tick); handler.postDelayed(tick, 1500)
                }
                if (failedPass) crossThen(true, true) { seekThen { go() } } else seekThen { go() }
            }
        }
        return true
    }

    private fun isCross(cmd: String) = cmd.trim().lowercase() in
        setOf("क्रॉस", "cross", "x", "×", "close", "बंद")

    // क्रॉस/बंद का निशान: टेक्स्ट ×, ✕, X या description/ID में close, dismiss आदि
    private fun findCross(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val marks = setOf("×", "✕", "✖", "✗", "╳", "x")
        val words = listOf("close", "dismiss", "cross", "बंद", "क्रॉस")
        val all = ArrayList<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            all.add(n)
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return all.firstOrNull { n ->
            val t = n.text?.toString()?.trim()?.lowercase()
            val d = n.contentDescription?.toString()?.trim()?.lowercase()
            val id = n.viewIdResourceName?.lowercase()
            (t != null && t in marks) || (d != null && d in marks) ||
            (d != null && words.any { d.contains(it) }) ||
            (id != null && words.any { id.contains(it) })
        }
    }


    // ---------- पिछला ऐप बंद करना (App info -> Force stop) ----------
    private val forceLabels = setOf("force stop", "force-stop", "force close", "जबरन रोकें",
        "जबरदस्ती रोकें", "फ़ोर्स स्टॉप", "फोर्स स्टॉप", "बलपूर्वक रोकें", "जबरन बंद करें")
    private val okLabels = setOf("ok", "ठीक है", "ओके", "yes", "हाँ")

    /** अगले ऐप/राउंड पर जाने से पहले: ऊपर के तीन बटन के हिसाब से जुड़ा ऐप — 0 बंद न करें, 1 मिनिमाइज़+स्वाइप, 2 Force stop.
     *  नंबर वाली कमांड हो तो उसके नंबर वाले कार्ड Recents से अलग से हटते हैं (मोड 1 में जुड़ा ऐप उसी चक्कर में) */
    /** ऐप को फोर्स स्टॉप करो (Shizuku/Root हो तो चुपचाप, वरना App info खोलकर Force stop दबाओ), फिर go() */
    private fun forceStopThen(pkg: String, go: () -> Unit) {
        if (pkg.startsWith("home:") || pkg in protectedPkgs()) { go(); return }
        toast("⛔ क्रॉस आया: $pkg को फोर्स स्टॉप कर रहे हैं")
        val ok = Shell.best("am force-stop $pkg") { }
        if (ok) handler.postDelayed({ if (running) go() }, 1500)
        else closeViaSettings(pkg) {              // Shizuku/Root नहीं: App info खोलकर Force stop दबाया गया → होम पर जाकर वह स्क्रीन हटाओ → फिर आगे
            performGlobalAction(GLOBAL_ACTION_HOME)
            handler.postDelayed({ if (running) go() }, 1000)
        }
    }

    private fun closeThen(pkg: String, go: () -> Unit) {
        val mode = getSharedPreferences("apps", MODE_PRIVATE).getInt("closeMode", 1)
        val isProt = pkg in protectedPkgs()
        if (numRange() != null) {
            closeNumCardsThen(mode == 1 && !pkg.startsWith("home:") && !isProt) {
                if (mode == 2 && !pkg.startsWith("home:") && !isProt) closeViaSettings(pkg, go) else go()
            }
            return
        }
        if (pkg.startsWith("home:") || mode == 0 || isProt) { go(); return }
        if (mode == 1) { closeViaRecents(pkg, go); return }
        closeViaSettings(pkg, go)
    }

    /** App info खोलकर Force stop दबाना */
    private fun closeViaSettings(pkg: String, go: () -> Unit) {
        closePkg = pkg; afterClose = go; closeStart = System.currentTimeMillis(); closeClicked = false
        try {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) { endClose(); return }
        handler.removeCallbacks(tick); handler.postDelayed(tick, 1500)
    }


    // ---------- मिनिमाइज़ (Recents) में सिर्फ़ उसी ऐप का कार्ड ऊपर स्वाइप ----------
    private var rLabel = ""
    private var rNumRange: IntRange? = null          // नंबर वाला मोड: Recents में इन नंबरों वाले सारे कार्ड हटाओ
    private var rNumCur: List<Int> = emptyList()
    private var rQueue: Set<String> = emptySet()       // मिनिमाइज़ मोड में हटने वाले जुड़े ऐप के नाम
    private var rClearAll = false                      // नंबर वाले कार्ड के साथ बाकी ऐप के कार्ड भी हटाओ (सेटिंग, डिफ़ॉल्ट बंद)
    private var rProtect: Set<String> = emptySet()   // Recents में जो कार्ड नहीं हटाने (VPN, अपना ऐप, और "बंद न करें" हो तो जुड़े ऐप)
    private var rLabels: Set<String> = emptySet()    // फ़ोन के सारे ऐप के नाम (कार्ड पहचानने के लिए)
    private val rTries = HashMap<String, Int>()
    private val rLog = ArrayList<String>()                // इस बार Recents से जो कार्ड हटाए
    private val rSeen = LinkedHashSet<String>()           // Recents में जो नाम दिखे (जाँच के लिए)
    private var rAttempts = 0
    private var rNotFound = 0

    private fun appLabel(pkg: String): String = if (pkg.startsWith("home:")) pkg.removePrefix("home:") else try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) { pkg }

    /** Recents में उस ऐप के नाम वाला कार्ड खोजो; स्क्रीन पर दिखने वाला हिस्सा लौटाओ */
    private fun findRecentCard(label: String): Rect? {
        val roots = ArrayList<AccessibilityNodeInfo>()
        rootInActiveWindow?.let { roots.add(it) }
        try { windows.forEach { w -> w.root?.let { roots.add(it) } } } catch (e: Exception) {}
        val dm = resources.displayMetrics
        val screen = Rect(0, 0, dm.widthPixels, dm.heightPixels)
        val want = label.trim().lowercase()
        var exact: Rect? = null; var exactA = 0L
        var part: Rect? = null; var partA = 0L
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            val ts = listOf(n.text, n.contentDescription).mapNotNull { it?.toString()?.trim()?.lowercase() }
            val isExact = ts.any { it == want }
            val isPart = !isExact && ts.any { it.contains(want) }
            if (isExact || isPart) {
                val r = Rect(); n.getBoundsInScreen(r)
                if (r.intersect(screen) && !r.isEmpty) {
                    val area = r.width().toLong() * r.height()
                    if (isExact && area > exactA) { exact = r; exactA = area }
                    if (isPart && area > partA) { part = r; partA = area }
                }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        for (r in roots) if (r.packageName != packageName) walk(r)
        return exact ?: part
    }

    private fun closeViaRecents(pkg: String, go: () -> Unit) {
        closePkg = "recents"; afterClose = go
        rNumRange = null
        rLabel = appLabel(pkg); rAttempts = 0; rNotFound = 0
        closeStart = System.currentTimeMillis()
        handler.removeCallbacks(tick)
        performGlobalAction(GLOBAL_ACTION_RECENTS)
        handler.postDelayed(recentsStep, 1300)
    }

    private val recentsStep = object : Runnable {
        override fun run() {
            if (!running || closePkg != "recents") return
            val numMode = rNumRange != null
            if (System.currentTimeMillis() - closeStart > (if (numMode) 60000 else 14000)) { leaveRecents(); return }
            val hit = if (numMode) findRecentNumCard(rNumRange!!, rNumCur) else null
            val card = if (numMode) hit?.first else findRecentCard(rLabel)
            if (hit != null) { rTries[hit.second] = (rTries[hit.second] ?: 0) + 1; rLog.add(hit.second) }
            if (card == null) {
                // पहली बार में न दिखे तो Recents खुलने का थोड़ा इंतज़ार; बाद में न दिखे = बंद हो चुका
                if (rAttempts == 0 && rNotFound < (if (numMode) 9 else 4)) { rNotFound++; handler.postDelayed(this, 700); return }
                leaveRecents(); return
            }
            if (rAttempts >= (if (numMode) 40 else 3)) { leaveRecents(); return }
            rAttempts++
            val dm = resources.displayMetrics
            val x = card.centerX().toFloat()
            val y0 = card.centerY().toFloat()
            val y1 = (y0 - dm.heightPixels * 0.45f).coerceAtLeast(20f)
            val path = Path().apply { moveTo(x, y0); lineTo(x, y1) }
            val g = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(pt(path), 0, 220)).build()
            val again = { handler.postDelayed(this, 900) }
            val ok = dg(g, object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(d: GestureDescription?) { again() }
                override fun onCancelled(d: GestureDescription?) { again() }
            }, null)
            if (!ok) again()
        }
    }

    private fun leaveRecents() {
        if (rNumRange != null) {
            val msg = if (rLog.isNotEmpty()) "🧹 Recents से हटाए: " + rLog.joinToString(", ")
                      else "Recents में कोई कार्ड नहीं हटा. दिखे नाम: " + rSeen.take(12).joinToString(" | ")
            Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
        }
        performGlobalAction(GLOBAL_ACTION_HOME)          // Recents से बाहर
        handler.postDelayed({ if (running && closePkg == "recents") endClose() }, 700)
    }

    private fun endClose() {
        closePkg = null; rNumRange = null
        val a = afterClose; afterClose = null
        handler.removeCallbacks(tick)
        a?.invoke()
    }

    private fun nodesByText(root: AccessibilityNodeInfo, labels: Set<String>): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            val t = (n.text ?: n.contentDescription)?.toString()?.trim()?.lowercase()
            if (t != null && t in labels) out.add(n)
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return out
    }

    private fun closeTick() {
        if (System.currentTimeMillis() - closeStart > 12000) { endClose(); return }   // न हो पाए तो आगे बढ़ो
        val root = rootInActiveWindow
        if (root != null && root.packageName != packageName) {
            if (!closeClicked) {
                val n = nodesByText(root, forceLabels).firstOrNull()
                if (n != null) {
                    if (!n.isEnabled) { endClose(); return }        // बटन बंद = ऐप पहले से रुका / सिस्टम ऐप
                    if (clickNode(n)) { closeClicked = true }
                }
            } else {
                val ok = nodesByText(root, okLabels + forceLabels).firstOrNull { it.isEnabled }
                if (ok != null && clickNode(ok)) {
                    handler.removeCallbacks(tick)
                    handler.postDelayed({ if (closePkg != null) endClose() }, 800)
                    return
                }
            }
        }
        handler.postDelayed(tick, 700)
    }

    // ---------- नया IP: VPN ऐप में नीचे वाला IP (ऊपर वाला असली IP नहीं) ----------
    private val ipRe = Regex("""\b(?:\d{1,3}\.){3}\d{1,3}\b""")

    private fun ipNodeText(n: AccessibilityNodeInfo): String? =
        listOfNotNull(n.text?.toString(), n.contentDescription?.toString()).joinToString(" ").ifBlank { null }

    /** VPN ऐप की स्क्रीन पर दिखे IP में से सबसे नीचे वाला. (word लिखा हो तो उस शब्द, जैसे from, के पास वाला IP). दो अलग IP न दिखें तो null */
    private fun pickVpnIp(root: AccessibilityNodeInfo, word: String): String? {
        val found = LinkedHashMap<String, Pair<Int, Boolean>>()   // IP -> (ऊँचाई, शब्द पास में)
        val w = word.trim().lowercase()
        fun valid(x: String) = x.split(".").all { (it.toIntOrNull() ?: 999) <= 255 }
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            val t = ipNodeText(n)
            if (t != null && n.isVisibleToUser) {
                val ips = ipRe.findAll(t).map { it.value }.filter { valid(it) }.toList()
                if (ips.isNotEmpty()) {
                    val r = Rect(); n.getBoundsInScreen(r)
                    var near = false
                    if (w.isNotEmpty()) {
                        near = t.lowercase().contains(w)
                        if (!near) {
                            val par = n.parent
                            if (par != null) for (i in 0 until par.childCount) {
                                val ct = par.getChild(i)?.let { ipNodeText(it) }
                                if (ct != null && ct.lowercase().contains(w)) near = true
                            }
                        }
                    }
                    for (ip in ips) {
                        val old = found[ip]
                        if (old == null || r.top > old.first) found[ip] = Pair(r.top, near || (old?.second == true))
                    }
                }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        val withWord = found.filter { it.value.second }
        // "from" जैसा शब्द दिया हो तो सिर्फ़ उसी के पास वाला IP काफ़ी है (ऊपर का Original IP न दिखे तब भी)
        if (w.isNotEmpty() && withWord.isNotEmpty()) return withWord.maxByOrNull { it.value.first }?.key
        if (found.size < 2) return null
        val pool = if (withWord.isNotEmpty()) withWord else found
        return pool.maxByOrNull { it.value.first }?.key
    }

    /** VPN ऐप खोलकर नीचे वाला IP पढ़ो (दो बार लगातार वही दिखे तब पक्का). 25 सेकंड में न मिले तो आख़िरी दिखा हुआ या null */
    private fun readVpnIp(pkg: String, word: String, cb: (String?) -> Unit) {
        val i = packageManager.getLaunchIntentForPackage(pkg)
        if (i == null) { cb(null); return }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i)
        var tries = 0; var last: String? = null; var same = 0
        fun poll() {
            if (!running) return
            val root = rootInActiveWindow
            val ip = if (root != null && root.packageName == pkg) pickVpnIp(root, word) else null
            if (ip != null) { if (ip == last) same++ else { last = ip; same = 1 } } else { same = 0 }
            badge?.text = "🌐 IP पढ़ रहे हैं…" + (ip?.let { " $it" } ?: "")
            if (same >= 3) { cb(ip); return }          // लगातार 3 बार (~4.5 सेकंड) वही IP दिखे तब पक्का: बीच में बदलते 2-3 IP नहीं लिए जाएँगे
            tries++
            if (tries >= 20) { cb(last); return }
            handler.postDelayed({ poll() }, 1500)
        }
        handler.postDelayed({ poll() }, 4000)
    }

    /** अभी वाला IP लिखो → VPN बंद-चालू करके नया IP पढ़ो; 24 घंटे में चल चुका हो तो फिर बंद-चालू (हर 3री कोशिश पर देश बदलो) → नया मिले तो फाइल में लिखो */
    private fun ipRotate(pkg: String, word: String, resume: () -> Unit, fail: (String) -> Unit, seek: Boolean = false) {
        val sp = getSharedPreferences("apps", MODE_PRIVATE)
        var attempt = 0
        var seekMode = seek        // पुराने (नंबर से जुड़े) IP खोज रहे हैं
        val seekCountries = if (seek) pendingIpCountries() else emptyList()      // उन IP के देश: पहले वही देश चुनो
        val seekLimit = if (seekCountries.isEmpty()) 5 else minOf(10, seekCountries.size * 2 + 1)
        var strict = true          // पहले सिर्फ़ बिलकुल नया IP (24 घंटे में कभी न चला); न मिले तो पहले चला हुआ (बंद नहीं हुआ) IP भी चलेगा
        val strictMax = 40         // VPN में 50+ देश हैं: नया IP मिलने तक हर कोशिश में नया देश आज़माओ
        var tryNext: () -> Unit = {}
        fun onIp(ip: String?) {
            if (!running) return
            if (ip == null) { fail("🌐 VPN ऐप में नीचे वाला IP स्क्रीन पर नहीं दिखा"); return }
            // जिस IP पर रिकॉर्ड किया हुआ नंबर (जैसे 93) अभी बाकी है, वह 24 घंटे/कॉपी/फेल की रोक के बावजूद लिया जा सकता है
            if (IpLog.isBlocked(this, ip) && !pendingForIp(ip)) {
                val cc = sp.getString("vpnCurCountry", "") ?: ""
                if (cc.isNotEmpty()) IpLog.addCountryFail(this, cc)
                toast("🌐 IP $ip अभी नहीं ले सकते (पूरा चल चुका / ${IpLog.MAX_TRIES} बार फेल)" + (if (cc.isNotEmpty()) " ($cc: ${IpLog.countryFails(this, cc)}/${IpLog.MAX_TRIES})" else "") + " — फिर बदल रहे हैं")
                tryNext(); return
            }
            if (seekMode && !pendingForIp(ip)) {            // इस IP पर पुराने बचे नंबर नहीं: दूसरा खोजो
                toast("🌐 IP $ip पर पुराने नंबर नहीं — दूसरा IP खोज रहे हैं")
                tryNext(); return
            }
            if (strict && IpLog.isKnown(this, ip) && !(seekMode && pendingForIp(ip))) {      // यह IP पहले भी चल चुका (बंद नहीं): नया खोजते रहो
                val cc = sp.getString("vpnCurCountry", "") ?: ""
                if (cc.isNotEmpty()) IpLog.addCountryFail(this, cc)      // इस देश से नया IP नहीं मिला: 3 बार पर यह देश छूटेगा
                toast("🌐 IP $ip पहले भी चला है" + (if (cc.isNotEmpty()) " ($cc: ${IpLog.countryFails(this, cc)}/${IpLog.MAX_TRIES})" else "") + " — नया IP खोज रहे हैं")
                tryNext(); return
            }
            ipActivate(ip, true)
            toast("🌐 " + (if (strict) "नया IP " else "पहले चला हुआ IP ") + ip + " ✔")
            resume()
        }
        tryNext = {
            attempt++
            if (seekMode && attempt > seekLimit) { seekMode = false; numAllowOther = true; toast("🌐 पुराने IP नहीं मिले ($seekLimit कोशिश) — बचे नंबर इसी नए IP पर चलेंगे और इससे जुड़ जाएँगे") }
            else if (seekMode) badge?.text = "🔎 पुराने (नंबर वाले) IP खोज रहे हैं $attempt/$seekLimit" + (seekCountries.getOrNull(((attempt - 1) / 2) % maxOf(1, seekCountries.size))?.let { " · देश: $it" } ?: "")
            if (attempt > strictMax && strict) { strict = false; toast("🌐 नया IP नहीं मिला — अब पहले चले (अधूरे) IP भी चलेंगे") }
            if (attempt > strictMax + 6) fail("🌐 चलने लायक IP नहीं मिला (${strictMax + 6} कोशिश)")
            else {
                val goRead = { readVpnIp(pkg, word) { ip -> onIp(ip) } }
                val cc = sp.getString("vpnCurCountry", "") ?: ""
                val exhausted = cc.isNotEmpty() && IpLog.countryFails(this, cc) >= IpLog.MAX_TRIES     // इस देश में 3 बार हो चुका → अब दूसरा देश
                if (seekMode && seekCountries.isNotEmpty() && vpnLines("vpnCountry").isNotEmpty()) {
                    // पुराना IP खोज रहे हैं: उस IP का देश पहले चुनो (हर देश पर पहले देश बदलो, फिर वहीं एक बार दोबारा जोड़कर देखो)
                    val tc = seekCountries[((attempt - 1) / 2) % seekCountries.size]
                    if (attempt % 2 == 1) { sp.edit().putString("vpnWantCountry", tc).apply(); changeVpnCountry(pkg, goRead, fail) }
                    else vpnCycle("पुराना IP", pkg, true, goRead, fail)
                }
                else if ((attempt >= 2 || exhausted) && vpnLines("vpnCountry").isNotEmpty()) changeVpnCountry(pkg, goRead, fail)      // पहली कोशिश सिर्फ़ बंद-चालू; आगे हर कोशिश में नया देश
                else vpnCycle("नया IP", pkg, true, goRead, fail)
            }
        }
        // पहले अभी चल रहा IP फाइल में लिखो (वह 24 घंटे दोबारा नहीं आएगा), फिर बदलो
        readVpnIp(pkg, word) { cur ->
            if (cur != null) ipActivate(cur, false)
            tryNext()
        }
    }

    /** इस कमांड के नंबर→IP का इतिहास (हर 5 सेकंड में ताज़ा) */
    private fun numHist(key: String): Map<Int, String> {
        val now = System.currentTimeMillis()
        if (key != histKey || now - histAt > 5000) { histCache = IpNum.map(this, key); ctryCache = IpNum.countryMap(this); histKey = key; histAt = now }
        return histCache
    }

    /** अभी के IP के हिसाब से कौन-से नंबर चल सकते हैं: 1) इसी IP पर पहले खुले (अगले दिन भी वही), 2) जिनका कोई IP नहीं, 3) दूसरे IP से जुड़े (तभी जब पुराने IP खोजने पर नहीं मिले). null = कोई रोक नहीं */
    private fun numAllowed(cmd: String, lo: Int, hi: Int, done: Set<Int>, failed: Map<Int, Int>, wantRed: Boolean): Set<Int>? {
        val sp = getSharedPreferences("apps", MODE_PRIVATE)
        val cur = sp.getString("ipCur", "") ?: ""
        if (numOnlyNG >= 0 || !sp.getBoolean("ipOn", false) || cur.isEmpty() || !onVpn()) return null      // VPN बंद हो तो IP का हिसाब लगाना बेकार: कोई रोक नहीं
        val h = numHist(numKey(cmd))
        if (h.isEmpty()) return null
        val pool = (lo..hi).filter { it !in done && (failed[it] ?: 0) < NUM_MAX_FAILS && (wantRed || !failed.containsKey(it)) }
        if (pool.isEmpty()) return null
        val curC = (sp.getString("vpnCurCountry", "") ?: "").lowercase().trim()
        // 1) इसी IP पर पहले खुले, 2) इसी देश (दूसरे IP) पर पहले खुले, 3) जिनका कोई रिकॉर्ड नहीं, 4) दूसरे देश/IP से जुड़े
        fun cls(n: Int): Int {
            val hip = h[n] ?: return 3
            return when { hip == cur -> 1; curC.isNotEmpty() && ctryCache[hip] == curC -> 2; else -> 4 }
        }
        val best = pool.minOf { cls(it) }
        if (best == 4 && !numAllowOther) return emptySet()
        return pool.filter { cls(it) == best }.toSet()
    }

    /** बचे सारे नंबर दूसरे IP से जुड़े हैं और अभी का IP उनमें से किसी का नहीं: पुराना IP खोजना पड़ेगा */
    private fun numSeekNeeded(): Boolean {
        val sp = getSharedPreferences("apps", MODE_PRIVATE)
        val cur = sp.getString("ipCur", "") ?: ""
        if (numAllowOther || numOnlyNG >= 0 || !sp.getBoolean("ipOn", false) || !sp.getBoolean("ipSeek", true) || cur.isEmpty()) return false
        var any = false
        for (st in steps) {
            val c = numOfStep(st) ?: continue
            val p = numParse(c) ?: continue
            val done = numDone(sp, numKey(c)); val failed = numFailed(sp, numFailKey(c))
            val h = numHist(numKey(c))
            if (h.isEmpty()) return false
            val pool = (p.first..p.second).filter { it !in done && (failed[it] ?: 0) < NUM_MAX_FAILS }
            if (pool.isEmpty()) continue
            val curC = (sp.getString("vpnCurCountry", "") ?: "").lowercase().trim()
            if (pool.any { val hip = h[it]; hip == null || hip == cur || (curC.isNotEmpty() && ctryCache[hip] == curC) }) return false
            any = true
        }
        return any
    }

    /** जिन IP पर बचे नंबर पहले खुले थे, उनके देश (सबसे छोटे नंबर वाले पहले) */
    private fun pendingIpCountries(): List<String> {
        val sp = getSharedPreferences("apps", MODE_PRIVATE)
        val pairs = ArrayList<Pair<Int, String>>()
        for (st in steps) {
            val c = numOfStep(st) ?: continue
            val p = numParse(c) ?: continue
            val done = numDone(sp, numKey(c)); val failed = numFailed(sp, numFailKey(c))
            val h = numHist(numKey(c))
            for (n in p.first..p.second) if (n !in done && (failed[n] ?: 0) < NUM_MAX_FAILS) h[n]?.let { ip -> val cn = IpNum.countryOf(this, ip); if (cn.isNotBlank()) pairs.add(Pair(n, cn)) }
        }
        return pairs.sortedBy { it.first }.map { it.second }.distinct()
    }

    /** इस IP पर पहले खुले कोई नंबर अब भी बाकी हैं? */
    private fun pendingForIp(ip: String): Boolean {
        val sp = getSharedPreferences("apps", MODE_PRIVATE)
        for (st in steps) {
            val c = numOfStep(st) ?: continue
            val p = numParse(c) ?: continue
            val done = numDone(sp, numKey(c)); val failed = numFailed(sp, numFailKey(c))
            val h = numHist(numKey(c))
            val curC = (sp.getString("vpnCurCountry", "") ?: "").lowercase().trim()
            // इसी IP पर, या इसी देश (जो अभी चुना है) के किसी IP पर पहले खुला नंबर बाकी है
            if ((p.first..p.second).any { n -> n !in done && (failed[n] ?: 0) < NUM_MAX_FAILS && h[n]?.let { hip -> hip == ip || (curC.isNotEmpty() && ctryCache[hip] == curC) } == true }) return true
        }
        return false
    }

    /** बचे नंबर दूसरे IP के हैं: उन IP को खोजो (न मिलें तो इसी IP पर चलाओ और जोड़ लो), फिर next() */
    private fun seekThen(next: () -> Unit) {
        if (!ipEnabledNow() || !numSeekNeeded()) { next(); return }
        val sp = getSharedPreferences("apps", MODE_PRIVATE)
        netCycling = true
        val fail = { why: String ->
            netCycling = false
            if (chainOn) chainFail("$why — पुराना IP खोजते समय") else { toast("$why — पुराना IP खोजते समय रुका"); stop() }
        }
        toast("🌐 बचे सारे नंबर दूसरे IP से जुड़े हैं — पहले वे IP खोज रहे हैं (5 कोशिश तक)")
        ipRotate(sp.getString("vpnPkg", "")!!, sp.getString("ipWord", "")!!, { netCycling = false; if (running) next() }, fail, true)
    }

    /** यह IP अब काम में आएगा: हिसाब बनाओ/पुराना लो, "अभी वाला IP" याद रखो, और इस IP पर चली कॉपी की गिनती लो */
    private fun ipActivate(ip: String, setCount: Boolean) {
        val c = IpLog.activate(this, ip)
        getSharedPreferences("apps", MODE_PRIVATE).getString("vpnCurCountry", "")?.let { if (it.isNotBlank()) IpNum.setCountry(this, ip, it) }      // इस IP का देश भी याद रखो
        val e = getSharedPreferences("apps", MODE_PRIVATE).edit().putString("ipCur", ip)
        if (setCount) e.putInt("ipCount", c)
        e.apply()
    }

    /** क्रॉस पर फोर्स स्टॉप/नया IP कब: गिनती (नंबर) वाला काम हो तो लगातार 2 क्रॉस पर; बाकी कामों में हर क्रॉस पर */
    private fun crossRotate(crossed: Boolean): Boolean {
        if (!crossed) return false
        return if (steps.any { numOfStep(it) != null }) crossStreak >= 2 else true
    }

    /** नया IP चालू है और VPN जुड़ा है? */
    private fun ipEnabledNow(): Boolean {
        val sp = getSharedPreferences("apps", MODE_PRIVATE)
        return sp.getBoolean("ipOn", false) && !sp.getString("vpnPkg", "").isNullOrEmpty() && onVpn()
    }

    /** कोई कमांड/कॉपी छूटी (❌ क्रॉस) हो तो तुरंत नया IP (गिनती 20 का इंतज़ार नहीं); वरना गिनती पूरी होने पर. IP सुविधा बंद हो तो पुराना नेटवर्क सुधार */
    private fun crossThen(crossed: Boolean, forceNet: Boolean, next: () -> Unit) {
        if (crossed && ipEnabledNow()) { missedApps = 0; ipThen(true, next) }
        else netFixThen(forceNet && crossed) { ipThen(false, next) }
    }

    /** force=true (क्रॉस आया) हो तभी नया IP लो, फिर next(). कॉपी की गिनती से अपने-आप नहीं बदलता */
    private fun ipThen(force: Boolean = false, next: () -> Unit) {
        val sp = getSharedPreferences("apps", MODE_PRIVATE)
        val pkg = sp.getString("vpnPkg", "")!!
        val every = maxOf(1, sp.getInt("ipEvery", 20))
        if (!sp.getBoolean("ipOn", false) || pkg.isEmpty() || !force || !onVpn()) { next(); return }      // IP सिर्फ़ क्रॉस (❌) आने पर बदलता है; कॉपी की कोई ऊपरी सीमा नहीं
        netCycling = true
        val resume = { netCycling = false; if (running) next() }
        val fail = { why: String ->
            netCycling = false
            if (chainOn) chainFail("$why — नया IP लेते समय रुका")
            else { toast("$why — नया IP लेते समय रुका"); stop() }
        }
        ipRotate(pkg, sp.getString("ipWord", "")!!, resume, fail)
    }

    /** लगातार "missApps" (डिफ़ॉल्ट 3) ऐप में कमांड छूटी हों तो अगला ऐप खोलने से पहले वाईफाई/VPN बंद-चालू (VPN हो तो देश बदलकर);
     *  वरना सीधे next() */
    private fun netFixThen(force: Boolean = false, next: () -> Unit) {
        val sp = getSharedPreferences("apps", MODE_PRIVATE)
        val limit = sp.getInt("missApps", 3)
        if (!force && (!sp.getBoolean("missCycle", true) || missedApps < limit)) { next(); return }
        val vpnPkg = sp.getString("vpnPkg", "")!!
        val vpnUp = onVpn() && vpnPkg.isNotEmpty()
        if (!vpnUp && !onWifi()) { missedApps = 0; next(); return }
        missedApps = 0
        netCycling = true
        val resume = { netCycling = false; if (running) next() }
        val fail = { why: String ->
            netCycling = false
            if (chainOn) chainFail("$why — नेटवर्क सुधार पर रुका")
            else { toast("$why — नेटवर्क सुधार पर रुका"); stop() }
        }
        val label = "अगला ऐप"
        if (vpnUp) {
            if (vpnLines("vpnCountry").isNotEmpty()) changeVpnCountry(vpnPkg, resume, fail)
            else vpnCycle(label, vpnPkg, true, resume, fail)
        } else wifiCycle(label, resume, fail)
    }

    private fun finish() {
        numSeen.clear(); numPageRange = null; numScanComplete = false; rvPreDoneIdx = -1; rvFromTimeout = false
        reviewMissKey = -1; reviewCheckedIdx = -1
        forceReview = false
        numCommit()
        // (बदलाव) लगातार 3 क्रॉस पर अब काम बंद नहीं होता. लगातार 2 क्रॉस पर फोर्स स्टॉप + नया IP होता रहता है, और काम तब तक चलता है जब तक सारे नंबर पूरे (✅ या सफ़ेद) न हों
        if (numRepeat()) return
        numOnlyNG = -1; numOnlyKeyG = ""         // एक नंबर वाला रन यहीं खत्म
        numFinalCheck()
        val crossed = skippedThisApp          // इस ऐप में कमांड/कॉपी छूटी (❌) → अगले से पहले नया IP; यह ऐप अगले राउंड के लिए छूटेगा
        if (queue.isNotEmpty()) {
            if (!skippedThisApp) markDone(queue[qIndex])   // पूरा हुआ: अधूरी सूची से हटाओ
            if (skippedThisApp) missedApps++ else missedApps = 0
            skippedThisApp = false
        }
        if (qIndex + 1 < queue.size) {          // अगले ऐप पर वही कमांड
            val prev = queue[qIndex]
            qIndex++; index = 0; gateOkIdx = -1
            val closer: (() -> Unit) -> Unit = { g -> closeThen(prev, g) }
            closer {
                crossThen(crossRotate(crossed), false) {
                    armReview()
                    stepStart = System.currentTimeMillis() + 3000
                    launchApp(queue[qIndex])
                    updateBadge()
                    handler.removeCallbacks(tick); handler.postDelayed(tick, 3000)
                }
            }
            return
        }
        // गिनती वाला काम: नंबर अभी बाकी हैं तो आख़िरी ऐप के बाद रुकना नहीं — पहले ऐप से फिर चलाओ, जब तक पिछले दौर में कम से कम
        // एक नया नंबर ✅ हुआ हो (कुछ नया न हुआ तो ही रुकेगा, वरना बेकार घूमता रहे)
        if (running && numOnlyNG < 0 && queue.isNotEmpty() && steps.any { numOfStep(it) != null } && numHasRemaining()) {
            val nowDone = numDoneTotal()
            if (nowDone > numLoopBase) {
                numLoopBase = nowDone
                val prev = queue[qIndex]
                qIndex = 0; index = 0; gateOkIdx = -1
                numExhausted = false; numPassClicks = 0
                toast("🔢 अभी नंबर बाकी हैं ($nowDone ✅) — पहले ऐप से फिर चला रहे हैं")
                closeThen(prev) {
                    crossThen(crossRotate(crossed), false) {
                        armReview()
                        stepStart = System.currentTimeMillis() + 3000
                        launchApp(queue[qIndex])
                        updateBadge()
                        handler.removeCallbacks(tick); handler.postDelayed(tick, 3000)
                    }
                }
                return
            }
        }
        val left = failedList().distinct()
        // गिनती (नंबर) वाला काम हो तो राउंड 2/3 नहीं: क्रॉस वाले नंबर राउंड 1 में ही बार-बार (हर नंबर 3 बार तक) चेक होते हैं
        if (autoRetry && left.isNotEmpty() && steps.none { numOfStep(it) != null }) {
            // अधूरे ऐप अपने-आप फिर: कुल 5 राउंड तक (सब पूरे होते ही रुक जाएगा)
            noProgress = if (left.size < roundFailed) 0 else noProgress + 1
            val spR = getSharedPreferences("apps", MODE_PRIVATE)
            val maxRounds = spR.getInt("maxRounds", 5)
            // राउंड 3+ में जितने भी ऐप बचे हों (5, 10, कुछ भी): सफल होने तक बार-बार (डिफ़ॉल्ट 4 अतिरिक्त राउंड), फिर छोड़ो
            val extra = round >= 3
            if (extra) fewTries++
            if (round < maxRounds || (extra && fewTries <= spR.getInt("fewTries", 4))) {
                // सिर्फ़ 1-2 ऐप बचे हों तो "लगातार 3 ऐप" कभी पूरे नहीं होते: इसलिए हर राउंड से पहले नेटवर्क सुधार
                if (extra && left.size <= 2) missedApps = maxOf(missedApps, spR.getInt("missApps", 3))
                roundFailed = left.size
                round++
                val last = queue[qIndex]
                queue = left; qIndex = 0; index = 0; gateOkIdx = -1
                closeThen(last) {
                    crossThen(crossRotate(crossed), false) {
                        armReview()
                        stepStart = System.currentTimeMillis() + 3000
                        launchApp(queue[0])
                        updateBadge()
                        handler.removeCallbacks(tick); handler.postDelayed(tick, 3000)
                    }
                }
                return
            }
        }
        val msg0 = when {
            queue.isEmpty() -> "सारी कमांड पूरी ✔"
            left.isEmpty() -> "सारे ऐप पूरे ✔ (राउंड $round)"
            else -> "रुका: ${left.size} ऐप अधूरे रह गए"
        }
        val msg = msg0 + numRemainingText()
        val lastPkg = queue.getOrNull(qIndex)
        if (lastPkg != null) {
            // आख़िरी खुला ऐप भी बंद करो, फिर अपना ऐप भी बंद
            closeThen(lastPkg) {
                if (left.isEmpty() && runNextProject()) return@closeThen   // अगला प्रोजेक्ट
                toast(if (chainOn && left.isNotEmpty()) "$msg — अगला प्रोजेक्ट नहीं चलाया" else msg)
                chainOn = false
                stop()
                // अपना ऐप भी बंद करो और होम स्क्रीन पर आ जाओ (✔ अगली बार खोलने पर वहीं मिलेंगे)
                try { MainActivity.cur?.finishAndRemoveTask() } catch (e: Exception) {}
                Handler(Looper.getMainLooper()).postDelayed({
                    try { performGlobalAction(GLOBAL_ACTION_HOME) } catch (e: Exception) {}
                }, 500)
            }
            return
        }
        toast(msg)
        stop()
    }


    // स्क्रीन की पहचान: सारे टेक्स्ट का हैश (बदले तो मतलब स्क्रीन बदली)
    private fun screenSig(root: AccessibilityNodeInfo): Int {
        var h = 17
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            h = h * 31 + (n.text?.toString()?.hashCode() ?: 0)
            h = h * 31 + (n.contentDescription?.toString()?.hashCode() ?: 0)
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return h
    }

    // टेक्स्ट जहाँ-जहाँ दिखे सारी जगहें (पहले exact, फिर contains), ऊपर से नीचे क्रम में
    // ---------- गुणा (×) जैसा चित्र खोजना: बिना नाम/टेक्स्ट वाला क्रॉस बटन ----------
    private var crossLastShot = 0L

    private fun findAndTapCross(root: AccessibilityNodeInfo) {
        val now = System.currentTimeMillis()
        if (now - crossLastShot < 1500) return
        crossLastShot = now
        val my = index
        val dm = resources.displayMetrics
        val d = dm.density
        // पहले छोटे, लगभग चौकोर आइकन-जैसे नोड (बिना टेक्स्ट वाले)
        val cands = ArrayList<Rect>()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || cands.size >= 60) return
            if (n.isVisibleToUser && n.text.isNullOrEmpty()) {
                val r = Rect(); n.getBoundsInScreen(r)
                val w = r.width(); val h = r.height()
                if (w >= 12 * d && h >= 12 * d && w <= 80 * d && h <= 80 * d && w.toFloat() / h in 0.6f..1.7f &&
                    (n.isClickable || (n.className?.toString() ?: "").contains("Image") || n.contentDescription != null)) cands.add(r)
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        if (Build.VERSION.SDK_INT >= 30) {
            busy = true
            shotApi30 { bmp -> finishCross(bmp, cands, my) }
        } else {
            val cs = CaptureService.instance ?: return
            busy = true
            bg.execute { finishCross(cs.capture(), cands, my) }
        }
    }

    /** छोटे, लगभग चौकोर आइकन-जैसे नोड (बिना टेक्स्ट वाले) — क्रॉस की संभावित जगहें */
    private fun crossCands(root: AccessibilityNodeInfo): List<Rect> {
        val d = resources.displayMetrics.density
        val cands = ArrayList<Rect>()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || cands.size >= 60) return
            if (n.isVisibleToUser && n.text.isNullOrEmpty()) {
                val r = Rect(); n.getBoundsInScreen(r)
                val w = r.width(); val h = r.height()
                if (w >= 12 * d && h >= 12 * d && w <= 80 * d && h <= 80 * d && w.toFloat() / h in 0.6f..1.7f &&
                    (n.isClickable || (n.className?.toString() ?: "").contains("Image") || n.contentDescription != null)) cands.add(r)
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return cands
    }

    /** (bg थ्रेड पर) आधे आकार की स्क्रीन में × की आकृति खोजो; मिले तो उसके बीच की जगह (x, y) */
    private fun crossHit(bmp: Bitmap?, cands: List<Rect>): Pair<Float, Float>? {
        var hit: Pair<Float, Float>? = null
        if (bmp != null) try {
            val W = bmp.width / 2; val H = bmp.height / 2
            val lum = gray(Bitmap.createScaledBitmap(bmp, W, H, true), W, H)
            val d = resources.displayMetrics.density
            var best = 0.22f                      // इससे कम मिलान = × नहीं
            // 1) आइकन-जैसे नोड
            for (r in cands) {
                val sz = maxOf(r.width(), r.height()) / 2
                val sc = xScoreAt(lum, W, H, r.centerX() / 2 - sz / 2, r.centerY() / 2 - sz / 2, sz)
                if (sc > best) { best = sc; hit = Pair(r.exactCenterX(), r.exactCenterY()) }
            }
            // 2) नोड से न मिले (Unity/वेब आदि) तो पूरी स्क्रीन के हर हिस्से में खोजो
            if (hit == null) {
                // पहले कदम बड़ा था (s/4) और आकार कम (5): × की जगह ज़रा भी खिसकी हो तो चूक जाता था. अब बारीक कदम, ज़्यादा आकार, और तेज़ पहली छँटाई
                for (dp in intArrayOf(16, 19, 22, 26, 30, 35, 41, 48, 56, 66)) {
                    val s = (dp * d / 2).toInt()
                    if (s < 14) continue
                    val st = maxOf(3, s / 8)
                    var y = 0
                    while (y + s <= H) {
                        var x = 0
                        while (x + s <= W) {
                            var sc = if (xQuick(lum, W, H, x, y, s)) xScoreAt(lum, W, H, x, y, s) else 0f
                            if (sc > 0f && y < H * 0.4f) sc += 0.02f          // क्रॉस ज़्यादातर ऊपर की ओर होता है
                            if (sc > best) { best = sc; hit = Pair((x + s / 2f) * 2f, (y + s / 2f) * 2f) }
                            x += st
                        }
                        y += st
                    }
                }
            }
        } catch (e: Throwable) { }
        return hit
    }

    private fun finishCross(bmp: Bitmap?, cands: List<Rect>, my: Int) {
        val pos = crossHit(bmp, cands)
        handler.post {
            if (!running || index != my || pos == null) { busy = false; return@post }
            val path = Path().apply { moveTo(pos.first, pos.second) }
            runGesture(path, 60, my)
        }
    }

    /** तेज़ पहली छँटाई: विकर्ण के 4 बिंदु बाकी हिस्से के 4 बिंदुओं से साफ़ अलग हों (वरना × नहीं) */
    private fun xQuick(lum: IntArray, W: Int, H: Int, x0: Int, y0: Int, s: Int): Boolean {
        if (x0 < 0 || y0 < 0 || x0 + s > W || y0 + s > H) return false
        fun l(fx: Float, fy: Float): Int = lum[(y0 + fy * s).toInt().coerceIn(0, H - 1) * W + (x0 + fx * s).toInt().coerceIn(0, W - 1)]
        val off = intArrayOf(l(.5f, .18f), l(.5f, .82f), l(.18f, .5f), l(.82f, .5f))
        val mo = off.sum() / 4f
        for (o in off) if (abs(o - mo) > 30f) return false
        val on = intArrayOf(l(.3f, .3f), l(.7f, .7f), l(.3f, .7f), l(.7f, .3f))
        for (o in on) if (abs(o - mo) < 35f) return false
        return true
    }

    /** lum में (x0,y0) से s×s वर्ग क्या × जैसा है? दोनों विकर्ण एक-से रंग के और बाकी हिस्सा एक-सा, पर दोनों अलग. 0 = नहीं */
    private fun xScoreAt(lum: IntArray, W: Int, H: Int, x0: Int, y0: Int, s: Int): Float {
        val n = 13
        if (s < n || x0 < 0 || y0 < 0 || x0 + s > W || y0 + s > H) return 0f
        val c = IntArray(n * n)
        val inset = s * 0.08f; val span = s * 0.84f
        for (j in 0 until n) for (i in 0 until n) {
            val px = (x0 + inset + (i + 0.5f) * span / n).toInt().coerceIn(0, W - 1)
            val py = (y0 + inset + (j + 0.5f) * span / n).toInt().coerceIn(0, H - 1)
            c[j * n + i] = lum[py * W + px]
        }
        var sum = 0; var cnt = 0
        for (j in 0 until n) for (i in 0 until n) {
            if (abs(i - j) >= 3 && abs(i + j - (n - 1)) >= 3) { sum += c[j * n + i]; cnt++ }
        }
        if (cnt == 0) return 0f
        val mo = sum.toFloat() / cnt
        var v = 0f
        for (j in 0 until n) for (i in 0 until n) {
            if (abs(i - j) >= 3 && abs(i + j - (n - 1)) >= 3) { val e = c[j * n + i] - mo; v += e * e }
        }
        val so = Math.sqrt((v / cnt).toDouble()).toFloat()
        if (so > 28f) return 0f                         // बाकी हिस्सा एक-सा नहीं (जैसे + या अक्षर)
        var good = 0; var tot = 0; var pos = 0; var neg = 0; var cs = 0f
        for (k in 0 until n) for (dg in 0..1) {
            if (dg == 1 && k == n / 2) continue
            val i = k; val j = if (dg == 0) k else n - 1 - k
            var bestD = 0f
            for (o in -1..1) {
                val ii = i + o; val jj = if (dg == 0) j - o else j + o
                if (ii < 0 || ii >= n || jj < 0 || jj >= n) continue
                val dd = c[jj * n + ii] - mo
                if (abs(dd) > abs(bestD)) bestD = dd
            }
            tot++
            if (abs(bestD) >= 45f) { good++; cs += abs(bestD); if (bestD > 0) pos++ else neg++ }
        }
        if (tot == 0 || good == 0) return 0f
        val frac = good.toFloat() / tot
        val polar = maxOf(pos, neg).toFloat() / good
        if (frac < 0.85f || polar < 0.9f) return 0f
        return frac * (cs / good) / 255f - so / 255f
    }

    // ---------- आइकन / चित्र खोजना: टेक्स्ट न हो तो description, hint और ID (जैसे daily_check) से ----------
    private val hiEn = mapOf(
        "डेली" to listOf("daily", "day"), "चेकिंग" to listOf("check", "checkin"), "चेक" to listOf("check"),
        "चेकइन" to listOf("checkin", "check"), "साइन" to listOf("sign"), "लॉगिन" to listOf("login", "signin"),
        "अटेंडेंस" to listOf("attendance", "checkin"), "हाज़िरी" to listOf("attendance", "checkin"),
        "क्लेम" to listOf("claim", "collect", "receive"), "रिवॉर्ड" to listOf("reward", "gift", "bonus"),
        "गिफ्ट" to listOf("gift"), "बोनस" to listOf("bonus"), "मिशन" to listOf("mission", "task"), "टास्क" to listOf("task", "mission"),
        "बंद" to listOf("close", "dismiss", "cross"), "क्रॉस" to listOf("close", "cross", "dismiss"),
        "बैक" to listOf("back", "return"), "वापस" to listOf("back", "return"), "खोलो" to listOf("open"),
        "सेटिंग" to listOf("setting", "settings", "gear"), "सेटिंग्स" to listOf("setting", "settings", "gear"),
        "शेयर" to listOf("share"), "कॉपी" to listOf("copy"), "पेस्ट" to listOf("paste"), "सर्च" to listOf("search"),
        "खोजो" to listOf("search"), "प्ले" to listOf("play"), "पॉज़" to listOf("pause"), "ओके" to listOf("ok", "confirm"),
        "ठीक" to listOf("ok", "confirm"), "मेनू" to listOf("menu", "more"), "होम" to listOf("home"), "लाइक" to listOf("like", "heart"),
        "फॉलो" to listOf("follow"), "सेंड" to listOf("send"), "भेजो" to listOf("send"), "मैसेज" to listOf("message", "chat"),
        "चैट" to listOf("chat", "message"), "कैमरा" to listOf("camera"), "प्रोफाइल" to listOf("profile", "avatar"),
        "डाउनलोड" to listOf("download"), "अपलोड" to listOf("upload"), "डिलीट" to listOf("delete", "trash", "remove"),
        "जोड़ो" to listOf("add", "plus"), "प्लस" to listOf("add", "plus"), "नया" to listOf("new", "add"), "रिफ्रेश" to listOf("refresh", "reload"),
        "स्किप" to listOf("skip"), "आगे" to listOf("next", "forward"), "अगला" to listOf("next", "forward"), "पीछे" to listOf("back", "previous"),
        "इनाम" to listOf("reward", "gift", "prize"), "स्पिन" to listOf("spin", "lucky"), "वॉलेट" to listOf("wallet"),
        "नोटिफिकेशन" to listOf("notification", "bell"), "कमेंट" to listOf("comment"), "रूम" to listOf("room"), "पार्टी" to listOf("party")
    )
    private val hiSkip = setOf("में", "का", "की", "के", "को", "पर", "से", "वाला", "वाली", "वाले", "है", "the", "a", "of")

    /** टेक्स्ट वाला नोड न मिले तो चित्र/आइकन: description, hint, ID (जैसे daily_check_btn) में कमांड के शब्द (हिंदी के अंग्रेज़ी रूप भी) खोजो.
     *  सारे शब्द मिलें तभी; सबसे सटीक (छोटे नाम वाला) एक नोड. पूरी तरह बिना नाम का चित्र नहीं पहचाना जा सकता — उसके लिए 📷 स्क्रीनशॉट वाली कमांड */
    private fun findByHint(root: AccessibilityNodeInfo, target: String): List<AccessibilityNodeInfo> {
        val toks = target.trim().lowercase().split(Regex("[^\\p{L}\\p{M}\\p{N}]+"))
            .filter { it.length >= 2 && it !in hiSkip }
        if (toks.isEmpty()) return emptyList()
        val alts = toks.map { t -> listOf(t) + (hiEn[t] ?: emptyList()) }
        fun squash(x: String) = x.lowercase().replace(Regex("[^\\p{L}\\p{M}\\p{N}]"), "")
        var best: AccessibilityNodeInfo? = null; var bestLen = Int.MAX_VALUE
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            if (n.isVisibleToUser) {
                val parts = ArrayList<String>()
                n.text?.let { parts.add(it.toString()) }
                n.contentDescription?.let { parts.add(it.toString()) }
                if (Build.VERSION.SDK_INT >= 26) n.hintText?.let { parts.add(it.toString()) }
                n.viewIdResourceName?.let { parts.add(it.substringAfterLast('/')) }
                val hay = squash(parts.joinToString(" "))
                if (hay.isNotEmpty() && alts.all { a -> a.any { hay.contains(squash(it)) } }) {
                    if (hay.length < bestLen) { best = n; bestLen = hay.length }
                }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        val b = best
        return if (b != null) listOf(b) else emptyList()
    }

    private fun findNodes(root: AccessibilityNodeInfo, target: String): List<AccessibilityNodeInfo> {
        val t = target.trim().lowercase()
        val all = ArrayList<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            all.add(n)
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        fun txt(n: AccessibilityNodeInfo) =
            (n.text ?: n.contentDescription)?.toString()?.trim()?.lowercase()
        val exact = all.filter { txt(it) == t }
        val list = if (exact.isNotEmpty()) exact else all.filter { val x = txt(it); x != null && x.contains(t) }
        val seen = HashSet<String>()
        val out = ArrayList<Pair<Int, AccessibilityNodeInfo>>()
        for (n in list) {
            if (!n.isVisibleToUser) continue
            var x: AccessibilityNodeInfo? = n
            while (x != null && !x.isClickable) x = x.parent
            val c = x ?: n
            val r = Rect(); c.getBoundsInScreen(r)
            if (!seen.add(r.toShortString())) continue
            out.add(Pair(r.top * 10000 + r.left, n))
        }
        return out.sortedBy { it.first }.map { it.second }
    }

    // "<base> <नंबर>" जैसे सारे दिखते नोड (नंबर lo..hi में, और अभी हुआ न हो), छोटे नंबर पहले
    private fun findNumbered(root: AccessibilityNodeInfo, base: String, lo: Int, hi: Int, done: Set<Int>, failed: Map<Int, Int>): List<Pair<Int, AccessibilityNodeInfo>> {
        val re = Regex("^" + Regex.escape(base.trim()) + "\\s*(\\d+)\$", RegexOption.IGNORE_CASE)
        val out = ArrayList<Pair<Int, AccessibilityNodeInfo>>()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            val t = (n.text ?: n.contentDescription)?.toString()?.trim()
            if (t != null && n.isVisibleToUser) {
                val v = re.find(t)?.groupValues?.get(1)?.toIntOrNull()
                if (v != null && v in lo..hi && v !in done && (failed[v] ?: 0) < NUM_MAX_FAILS) out.add(Pair(v, n))
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        // पहले जो अभी हुए नहीं, फिर 🔴 वाले (दोबारा कोशिश); दोनों में छोटा नंबर पहले
        return out.sortedWith(compareBy({ if (failed.containsKey(it.first)) 1 else 0 }, { it.first }))
    }

    /** स्क्रीन पर रेंज वाला टैब/बटन (\"1-50\", \"51 से 100\", \"151 to 200\") जिसकी रेंज में target आता हो; सबसे छोटी रेंज पहले */
    private fun findRangeTab(root: AccessibilityNodeInfo, target: Int): AccessibilityNodeInfo? {
        val re = Regex("(\\d+)\\s*\\D{1,6}\\s*(\\d+)")        // दो संख्याओं के बीच कोई भी छोटा चिह्न/शब्द: 51–100, 51-100, 51 से 100, 51 to 100
        var best: AccessibilityNodeInfo? = null
        var bestSpan = Int.MAX_VALUE
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            val t = (n.text ?: n.contentDescription)?.toString()?.trim()
            if (t != null && t.length <= 60 && n.isVisibleToUser && generateSequence(n) { it.parent }.any { it.isClickable }) {   // सिर्फ़ क्लिक होने वाला टैब (डायलॉग का टाइटल \"Emma (1–50)\" टैब नहीं गिना जाएगा)
                val m = re.find(t)
                val a = m?.groupValues?.get(1)?.toIntOrNull()
                val b = m?.groupValues?.get(2)?.toIntOrNull()
                if (a != null && b != null && target in a..b && b - a < bestSpan) { bestSpan = b - a; best = n }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return best
    }

    /** नंबर वाली कमांड का नंबर समय में नहीं मिला: उस नंबर की कोशिश +1 (3 कोशिश के बाद वह नंबर छोड़ दिया जाता है) */
    private fun numMarkMiss(cmd: String, permanent: Boolean = false) {
        val p = numParse(cmd) ?: return
        val sp = getSharedPreferences("apps", MODE_PRIVATE)
        val done = numDone(sp, numKey(cmd))
        val failed = numFailed(sp, numFailKey(cmd))
        val t = (if (numCurTarget in p.first..p.second && numCurTarget !in done) numCurTarget else null)
            ?: (p.first..p.second).firstOrNull { it !in done && !failed.containsKey(it) }
            ?: (p.first..p.second).firstOrNull { it !in done && (failed[it] ?: 0) < NUM_MAX_FAILS } ?: return
        // "है ही नहीं" (सफ़ेद) तभी जब खुला पेज इसी नंबर की रेंज का हो और पूरा देखा जा चुका हो; वरना (गलत पेज/देर से खुला) सिर्फ़ एक कोशिश गिनो
        val covers = numPageRange?.contains(t) == true && numScanComplete && numSeen.isNotEmpty()
        val reallyMissing = permanent && covers
        failed[t] = if (reallyMissing) 99 else (failed[t] ?: 0) + 1     // 99 = कॉपी मौजूद ही नहीं, दोबारा कभी नहीं खोजना
        sp.edit().putString(numFailKey(cmd), failed.entries.sortedBy { it.key }.joinToString(",") { "${it.key}:${it.value}" }).apply()
        toast(if (reallyMissing) "${p.third} $t है ही नहीं → सफ़ेद, कमांड शुरू से" else "${p.third} $t नहीं मिल पाया (पेज पूरा नहीं देखा गया) → फिर कोशिश होगी")
    }

    /** आपका लिखा (पहला या दूसरा) टेक्स्ट अभी स्क्रीन पर दिख रहा है? */
    private fun closeTextVisible(root: AccessibilityNodeInfo, cmd: String): Boolean {
        val (t1, t2) = numExtras(cmd)
        return listOf(t1, t2).filter { it.isNotEmpty() }.any { t -> findNode(root, t) != null }
    }

    /** नंबर नहीं मिला: वह कॉपी हमेशा के लिए छोड़ो; स्क्रीन पर आपका लिखा पहला टेक्स्ट खोजकर क्लिक, ~1 सेकंड बाद दूसरा टेक्स्ट खोजकर क्लिक, फिर इसी ऐप की सारी कमांड शुरू से */
    private fun numNotFoundRestart(cmd: String) {
        if (numOnlyNotFound()) return
        numCloses++
        holdUntil = System.currentTimeMillis() + 20000; stepStart = holdUntil      // इस बीच कमांड का लूप रुका रहे
        // इस कमांड पर रिव्यू फोटो जुड़ी हो (नंबर 0 = हर कमांड) और स्क्रीन उसके जैसी हो → वह कॉपी हो चुकी मानो (✅ हरा); वरना "है ही नहीं" (सफ़ेद)
        val tpls = if (earlierMissInCounting()) emptyList() else reviewImgs().mapNotNull { line ->
            val n = line.substringBefore("|", "0").toIntOrNull() ?: 0
            if (n == 0 || n == index + 1) loadTemplate(line.substringAfter("|")) else null
        }
        val proceed = { found: Boolean ->
            if (found) numMarkDone(cmd) else numMarkMiss(cmd, true)
            numMarkMissingScan(cmd)
            numCloseAndRestart(cmd)
        }
        if (tpls.isEmpty()) { proceed(false); return }
        val check = { bmp: Bitmap? ->
            val strict = getSharedPreferences("apps", MODE_PRIVATE).getInt("reviewColor", 12).toDouble()
            val found = bmp != null && tpls.any { matchReview(bmp, it, strict) }
            handler.post { if (running) { toast(if (found) "✅ रिव्यू फोटो मिली" else "❌ रिव्यू फोटो नहीं मिली"); proceed(found) } }
        }
        val doCheck = {
            if (Build.VERSION.SDK_INT >= 30) shotApi30 { check(it) }
            else {
                val cs = CaptureService.instance
                if (cs == null) proceed(false) else bg.execute { check(cs.capture()) }
            }
        }
        // "रिव्यू से पहले" के टेक्स्ट/फोटो जुड़े हों तो पहले वे चलें, फिर रिव्यू फोटो की जाँच
        val pre = reviewPre(index + 1)
        if (pre.isEmpty()) doCheck() else runQuick(pre) { doCheck() }
    }

    /** स्क्रीन पर दिखे सारे "<base> <नंबर>" के नंबर (हो चुके हों या नहीं), रेंज के बाहर वाले भी */
    private fun seenNumbers(root: AccessibilityNodeInfo, base: String): Set<Int> {
        val re = Regex("^" + Regex.escape(base.trim()) + "\\s*(\\d+)$", RegexOption.IGNORE_CASE)
        val out = HashSet<Int>()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            val t = (n.text ?: n.contentDescription)?.toString()?.trim()
            if (t != null && n.isVisibleToUser) re.find(t)?.groupValues?.get(1)?.toIntOrNull()?.let { out.add(it) }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return out
    }

    /** खुले पेज का टाइटल (जैसे "Emma (1–50)") से उसकी रेंज */
    private fun pageRangeOf(root: AccessibilityNodeInfo): IntRange? {
        val re = Regex("(\\d+)\\s*(?:-|–|—|~|to|TO|To|से|तक)\\s*(\\d+)")
        var best: IntRange? = null
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || best != null) return
            val t = (n.text ?: n.contentDescription)?.toString()?.trim()
            if (t != null && t.length <= 40 && n.isVisibleToUser) {
                val m = re.find(t)
                val a = m?.groupValues?.get(1)?.toIntOrNull(); val b = m?.groupValues?.get(2)?.toIntOrNull()
                if (a != null && b != null && a <= b) best = a..b
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return best
    }

    /** पूरा पेज (जैसे 51–100) ऊपर से किनारे तक देख लिया: जो नंबर उसमें दिखे ही नहीं वे सारे एक साथ "है ही नहीं" (सफ़ेद), दोबारा खोले नहीं जाएँगे */
    private fun numMarkMissingScan(cmd: String) {
        val p = numParse(cmd) ?: return
        val pr = numPageRange
        if (!numScanComplete || pr == null || numSeen.isEmpty()) return
        val sp = getSharedPreferences("apps", MODE_PRIVATE)
        val done = numDone(sp, numKey(cmd))
        val failed = numFailed(sp, numFailKey(cmd))
        val miss = (maxOf(pr.first, p.first)..minOf(pr.last, p.second)).filter { it !in numSeen && it !in done && (failed[it] ?: 0) < 99 }
        if (miss.isEmpty()) return
        for (v in miss) failed[v] = 99
        sp.edit().putString(numFailKey(cmd), failed.entries.sortedBy { it.key }.joinToString(",") { "${it.key}:${it.value}" }).apply()
        toast("${pr.first}–${pr.last} में ${miss.size} कॉपी नहीं हैं → सफ़ेद, दोबारा नहीं खोलेंगे")
    }

    /** ग्रिड से हाथ से खोली गई कॉपी: ✅ हरी (हो चुकी), लाल/फेल-गिनती हटाओ */
    private fun numMarkManualDone(cmd: String, n: Int) {
        val sp = getSharedPreferences("apps", MODE_PRIVATE)
        val done = numDone(sp, numKey(cmd))
        val failed = numFailed(sp, numFailKey(cmd))
        done.add(n); failed.remove(n)
        sp.edit().putString(numKey(cmd), done.sorted().joinToString(","))
            .putString(numFailKey(cmd), failed.entries.sortedBy { it.key }.joinToString(",") { "${it.key}:${it.value}" }).apply()
    }

    /** रिव्यू फोटो मिली: इस नंबर की कॉपी ✅ हरी (हो चुकी) */
    private fun numMarkDone(cmd: String) {
        val p = numParse(cmd) ?: return
        val sp = getSharedPreferences("apps", MODE_PRIVATE)
        val done = numDone(sp, numKey(cmd))
        val failed = numFailed(sp, numFailKey(cmd))
        val t = (if (numCurTarget in p.first..p.second && numCurTarget !in done) numCurTarget else null)
            ?: (p.first..p.second).firstOrNull { it !in done && !failed.containsKey(it) }
            ?: (p.first..p.second).firstOrNull { it !in done && (failed[it] ?: 0) < NUM_MAX_FAILS } ?: return
        done.add(t); failed.remove(t)
        sp.edit().putString(numKey(cmd), done.sorted().joinToString(","))
            .putString(numFailKey(cmd), failed.entries.sortedBy { it.key }.joinToString(",") { "${it.key}:${it.value}" })
            .putInt("ipCount", sp.getInt("ipCount", 0) + 1).apply()
        toast("${p.third} $t ✅ (रिव्यू फोटो मिली)")
    }

    private fun numCloseAndRestart(cmd: String) {
        val (t1, t2) = numExtras(cmd)
        fun clickText(t: String, left: Int, done: () -> Unit) {
            if (!running) return
            if (t.isEmpty()) { done(); return }
            val r = rootInActiveWindow
            val nd = if (r != null) findNode(r, t) else null
            if (nd != null && clickNode(nd)) {
                toast("$t ✔")
                handler.postDelayed({ done() }, 1000)
            } else if (left > 0) handler.postDelayed({ clickText(t, left - 1, done) }, 500)
            else { toast("$t स्क्रीन पर नहीं दिखा"); done() }
        }
        clickText(t1, 5) {
            clickText(t2, 5) {
                if (running) {
                    index = 0; gateOkIdx = -1; multiTried = 0; clickPending = false
                    numScrolled = false; numFwd = true; numEdges = 0; numScrolls = 0
                    numRangeTapped.clear(); numSeen.clear(); numPageRange = null; numScanComplete = false
                    holdUntil = System.currentTimeMillis() + 600; stepStart = holdUntil
                    updateBadge()
                }
            }
        }
    }

    private fun clickNode(n: AccessibilityNodeInfo): Boolean {
        var x: AccessibilityNodeInfo? = n
        while (x != null && !x.isClickable) x = x.parent
        (x ?: n).let { v -> val r = Rect(); v.getBoundsInScreen(r); if (!r.isEmpty) ptr(r.exactCenterX(), r.exactCenterY()) }
        return x?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true
    }

    // पहले exact match, फिर contains (अंग्रेज़ी में बड़े-छोटे अक्षर का फ़र्क नहीं)
    private fun findNode(root: AccessibilityNodeInfo, target: String): AccessibilityNodeInfo? {
        val t = target.trim().lowercase()
        val all = ArrayList<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            all.add(n)
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        fun txt(n: AccessibilityNodeInfo) =
            (n.text ?: n.contentDescription)?.toString()?.trim()?.lowercase()
        return all.firstOrNull { txt(it) == t }
            ?: all.firstOrNull { val s = txt(it); s != null && s.contains(t) }
    }

    // छोटा बैज: कौन सी कमांड चल रही है; टैप करने पर रुक जाएगा
    // ---------- टच-ताला: कमांड चलते समय उंगली/भूतिया टच बेअसर (सिर्फ़ ऊपर का "रोकें" बैज चलता है) ----------
    private var blocker: View? = null
    private var passCount = 0

    private fun lockOn(): Boolean = getSharedPreferences("apps", MODE_PRIVATE).getBoolean("touchLock", true)

    private fun blockerParams(touchable: Boolean): WindowManager.LayoutParams {
        var f = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!touchable) f = f or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        return WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, f, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= 28) layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }

    /** पूरी स्क्रीन पर पारदर्शी परदा जो हर टच खा लेता है. बैज इसके ऊपर रहता है (बाद में जोड़ा जाता है) */
    private fun showBlocker() {
        if (blocker != null || !lockOn()) return
        try {
            val v = View(this).apply { setOnTouchListener { _, _ -> true } }
            (getSystemService(WINDOW_SERVICE) as WindowManager).addView(v, blockerParams(true))
            blocker = v; passCount = 0
        } catch (e: Throwable) { blocker = null }
    }

    private fun hideBlocker() {
        blocker?.let { try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } catch (e: Exception) {} }
        blocker = null; passCount = 0
    }

    private fun blockerPass(pass: Boolean) {
        teachPass(pass)
        val b = blocker ?: return
        try { (getSystemService(WINDOW_SERVICE) as WindowManager).updateViewLayout(b, blockerParams(!pass)) } catch (e: Exception) {}
    }

    /** dispatchGesture का रैपर: हमारा अपना टैप/स्वाइप जाते समय परदा पल भर के लिए टच-पारदर्शी हो जाता है */
    private fun dg(g: GestureDescription, cb: AccessibilityService.GestureResultCallback?, h: Handler?): Boolean {
        if (blocker == null && teachView == null) return dispatchGesture(g, cb, h)
        var dur = 0L
        for (i in 0 until g.strokeCount) { val st = g.getStroke(i); dur = maxOf(dur, st.startTime + st.duration) }
        passCount++; blockerPass(true)
        var released = false
        val rel = { if (!released) { released = true; passCount = maxOf(0, passCount - 1); if (passCount == 0) blockerPass(false) } }
        val wrapped = object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { handler.postDelayed({ rel() }, 80); cb?.onCompleted(d) }
            override fun onCancelled(d: GestureDescription?) { rel(); cb?.onCancelled(d) }
        }
        handler.postDelayed({
            val ok = dispatchGesture(g, wrapped, h)
            if (!ok) { rel(); cb?.onCancelled(null) } else handler.postDelayed({ rel() }, dur + 700)
        }, 70)                                      // परदा टच-पारदर्शी होने के लिए ज़रा समय
        return true
    }

    private fun showBadge() {
        showBlocker()
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        badge = TextView(this).apply {
            textSize = 14f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                cornerRadius = 40f; setColor(Color.parseColor("#CC C62828".replace(" ", "")))
            }
            setPadding(24, 12, 24, 12)
            setOnClickListener { toast("रोक दिया"); chainOn = false; stop() }
        }
        updateBadge()
        wm.addView(badge, WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; y = 120 })
    }

    /** ऊपर की पट्टी के लिए गिनती: ✅ हो चुकी - कुल (सफ़ेद "है ही नहीं" छोड़कर), और अभी चल रही कॉपी, जैसे "🔢 ✅45-100 · अभी 46" */
    private fun numProgress(): String {
        val sp = getSharedPreferences("apps", MODE_PRIVATE)
        for (st in steps) {
            val c = numOfStep(st) ?: continue
            val p = numParse(c) ?: continue
            val done = numDone(sp, numKey(c)); val failed = numFailed(sp, numFailKey(c))
            val white = failed.count { it.value >= 99 && it.key in p.first..p.second }
            val total = p.second - p.first + 1 - white
            val d = done.count { it in p.first..p.second }
            val cur = numCur[c] ?: numCurTarget.takeIf { it >= 0 }
            return "🔢 ✅$d-$total" + (cur?.let { " · अभी $it" } ?: "")
        }
        return ""
    }

    private fun updateBadge() {
        val r = if (autoRetry) "राउंड $round · " else ""
        val pr = if (chainOn) "प्रोजेक्ट ${chainIdx + 1}/${chainNames.size} · " else ""
        val app = pr + r + (if (queue.size > 1) "ऐप ${qIndex + 1}/${queue.size} · " else "")
        val prog = numProgress().let { if (it.isEmpty()) "" else "$it · " }
        badge?.text = "⏹ $prog$app" + "कमांड ${index + 1}/${steps.size}: ${prettyStep(steps[index])}"
    }

    private fun toast(m: String) { Toast.makeText(this, m, Toast.LENGTH_SHORT).show() }

    // ---------- स्क्रीन पर उँगली 👆 (जहाँ क्लिक/टैप/स्वाइप हो वहाँ चलकर लहर दिखाती है) ----------
    private var fxLayer: FrameLayout? = null
    private var fxFinger: TextView? = null
    private var fxRipple: View? = null
    private val fxHide = Runnable { fxFinger?.animate()?.alpha(0f)?.setDuration(300)?.start() }

    private fun fingerOn() = getSharedPreferences("apps", MODE_PRIVATE).getBoolean("showFinger", true)

    private fun fxLayer(): FrameLayout? {
        fxLayer?.let { return it }
        return try {
            val d = resources.displayMetrics.density
            val sz = (48 * d).toInt()
            val lay = FrameLayout(this)
            val rp = View(this).apply {
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setStroke((3 * d).toInt(), Color.parseColor("#FFEB3B")); setColor(Color.parseColor("#55FFEB3B")) }
                alpha = 0f
            }
            lay.addView(rp, FrameLayout.LayoutParams(sz, sz))
            val f = TextView(this).apply { text = "👆"; textSize = 30f; gravity = Gravity.CENTER; alpha = 0f }
            lay.addView(f, FrameLayout.LayoutParams(sz, sz))
            (getSystemService(WINDOW_SERVICE) as WindowManager).addView(lay, blockerParams(false))
            fxLayer = lay; fxFinger = f; fxRipple = rp
            lay
        } catch (e: Throwable) { fxLayer = null; null }
    }

    private fun fxRemove() {
        handler.removeCallbacks(fxHide)
        fxLayer?.let { try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } catch (e: Exception) {} }
        fxLayer = null; fxFinger = null; fxRipple = null
    }

    /** उँगली (x, y) तक चलकर टैप की लहर दिखाए; स्वाइप हो तो (x2, y2) तक खिंचे */
    private fun ptr(x: Float, y: Float, x2: Float = x, y2: Float = y) {
        if (!running || !fingerOn()) return
        handler.post {
            if (!running) return@post
            if (fxLayer() == null) return@post
            val f = fxFinger ?: return@post; val rp = fxRipple ?: return@post
            val d = resources.displayMetrics.density; val w = 48 * d
            fun fx(px: Float) = px - w / 2
            fun fy(py: Float) = py - 6 * d
            f.animate().cancel()
            if (f.alpha < 0.1f) { f.translationX = fx(x); f.translationY = fy(y) }
            f.alpha = 1f
            f.animate().translationX(fx(x)).translationY(fy(y)).setDuration(220).withEndAction {
                rp.translationX = x - w / 2; rp.translationY = y - w / 2; rp.scaleX = 0.3f; rp.scaleY = 0.3f; rp.alpha = 0.9f
                rp.animate().cancel(); rp.animate().scaleX(1.3f).scaleY(1.3f).alpha(0f).setDuration(450).start()
                if (x2 != x || y2 != y) f.animate().translationX(fx(x2)).translationY(fy(y2)).setDuration(350).start()
            }.start()
            handler.removeCallbacks(fxHide); handler.postDelayed(fxHide, 1800)
        }
    }

    /** गेस्चर का रास्ता: शुरू और अंत का बिंदु निकालकर उँगली दिखाओ, रास्ता वैसा ही लौटाओ */
    private fun pt(p: Path): Path {
        try {
            val pm = PathMeasure(p, false); val a = FloatArray(2); val b = FloatArray(2)
            pm.getPosTan(0f, a, null); pm.getPosTan(pm.length, b, null)
            ptr(a[0], a[1], b[0], b[1])
        } catch (e: Throwable) { }
        return p
    }


    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null) return
        // ऐड गार्ड: ऊपर की विंडो (Activity) का नाम याद रखो — AdActivity आदि से ऐड पहचानने में मदद
        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val c = e.className?.toString()?.lowercase() ?: ""
            if (c.contains('.') && !c.startsWith("android.")) { adWinClass = c; adWinPkg = e.packageName?.toString() ?: "" }
        }
        if (!failWatching && !failEventsOn) return
        try {
            val t = ((e.text?.joinToString(" ") ?: "") + " " + (e.contentDescription ?: "")).trim().lowercase()
            if (t.isNotEmpty()) synchronized(recentTexts) { val now = System.currentTimeMillis(); recentTexts.add(Pair(now, t)); recentTexts.removeAll { now - it.first > 10000 }; if (recentTexts.size > 80) recentTexts.removeAt(0) }
        } catch (x: Exception) {}
    }
    override fun onInterrupt() {}
    override fun onDestroy() { stop(); instance = null; super.onDestroy() }
}

/** कमांड को सूची/बैज में दिखाने लायक नाम */
fun prettyStep(s0: String): String {
    val lim = stepLimit(s0)
    val s = stripLimit(s0)
    val core = if (!s.contains("~~")) prettyBase(s) else {
        val d = s.substringAfterLast("~~").toIntOrNull() ?: 0
        val base = prettyBase(s.substringBeforeLast("~~"))
        if (d > 0) "$base  ⏱ $d सेकंड" else base
    }
    val tch = stepTeach(s0)
    val withLim = if (lim > 0) "$core  🔍 $lim सेकंड खोजेगा" else core
    val n = if (tch != null) teachPoints(tch).size else 0
    return when {
        tch == null -> withLim
        tch == "L" -> "$withLim  🧠 सिखाएगा"
        tch.startsWith("A:") -> "$withLim  🧠 $n बटन सीखे, और जोड़ेगा"
        else -> "$withLim  🧠 सिखाया हुआ ($n बटन)"
    }
}

/** कमांड के बिल्कुल आख़िर में सिखाने की निशानी:  "^^L" = अगली बार उँगली से सिखाओ (कितने भी बटन),
 *  "^^T:x1,y1;x2,y2;…" = सिखाए हुए बटन क्रम से (स्क्रीन का %),  "^^A:…" = इन्हें दोहराकर आगे और बटन जोड़ो.
 *  कमांड के साथ ही सेव होती है, इसलिए प्रोजेक्ट सेव करने पर सिखाई हुई जगह भी सेव रहती है */
private val teachRe = Regex("\\^\\^(L|[TA]:-?[0-9.]+,-?[0-9.]+(?:;-?[0-9.]+,-?[0-9.]+)*)$")
fun stepTeach(st: String): String? = teachRe.find(st)?.groupValues?.get(1)
fun stripTeach(st: String): String = teachRe.replace(st, "")
fun teachSuffix(st: String): String = teachRe.find(st)?.value ?: ""
/** "T:x1,y1;x2,y2;…" (सिखाए बटन, क्रम से) → [(x1,y1), (x2,y2), …] — स्क्रीन का % */
fun teachPoints(t: String): List<Pair<Float, Float>> =
    t.substringAfter(':', "").split(";").mapNotNull { p ->
        val q = p.split(",")
        val a = q.getOrNull(0)?.toFloatOrNull(); val b = q.getOrNull(1)?.toFloatOrNull()
        if (q.size == 2 && a != null && b != null) Pair(a, b) else null
    }

/** कमांड के आख़िर में "@@सेकंड" हो तो वह उस कमांड के खोजने का अपना समय है (जैसे ...~~5@@30) */
fun stepLimit(st0: String): Int {
    val st = stripTeach(st0)
    val t = st.substringAfterLast("@@", "")
    return if (st.contains("@@") && t.isNotEmpty() && t.all { it.isDigit() }) t.toIntOrNull() ?: 0 else 0
}
fun stripLimit(st0: String): String {
    val st = stripTeach(st0)
    val t = st.substringAfterLast("@@", "")
    return if (st.contains("@@") && t.isNotEmpty() && t.all { it.isDigit() }) st.substringBeforeLast("@@") else st
}

/** नंबर वाली कमांड:  NUM:<से>-<तक>:<टेक्स्ट>  → (से, तक, टेक्स्ट) */
/** ग्रिड में किसी 🔴 नंबर पर दबाकर "सिर्फ़ यही नंबर चलाओ": इस दौरान उस कमांड की रेंज सिर्फ़ वही एक नंबर मानी जाती है */
/** एक नंबर (कॉपी) को ❌ के बाद ज़्यादा से ज़्यादा कितनी बार आज़माया जाए; इतने पर भी न हो तो वह लाल रहकर छोड़ा जाता है. (काम तब पूरा जब सब नंबर ✅ या सफ़ेद हों) */
const val NUM_MAX_FAILS = 10

@Volatile var numOnlyPendKey: String = ""
@Volatile var numOnlyPendN: Int = -1
@Volatile var numOnlyKeyG: String = ""
@Volatile var numOnlyNG: Int = -1

fun numParse(cmd: String): Triple<Int, Int, String>? {
    if (!cmd.startsWith("NUM:")) return null
    val p = cmd.removePrefix("NUM:").split(":", limit = 2)
    if (p.size < 2) return null
    val r = p[0].split("-")
    val lo = r.getOrNull(0)?.toIntOrNull() ?: return null
    val hi = r.getOrNull(1)?.toIntOrNull() ?: return null
    val base = p[1].substringBefore("¦")
    if (numOnlyNG in lo..hi && numOnlyKeyG == "nd_" + cmd.removePrefix("NUM:").substringBefore("¦")) return Triple(numOnlyNG, numOnlyNG, base)
    return Triple(lo, hi, base)
}
/** नंबर न मिलने पर बंद करने वाले दो टेक्स्ट:  NUM:1-1000:कॉपी¦बंद करें¦पीछे  → (बंद करें, पीछे) */
fun numExtras(cmd: String): Pair<String, String> {
    val p = cmd.removePrefix("NUM:").split(":", limit = 2).getOrNull(1) ?: return Pair("", "")
    val e = p.split("¦")
    return Pair(e.getOrElse(1) { "" }.trim(), e.getOrElse(2) { "" }.trim())
}
/** गिनती की चाबी में बंद-टेक्स्ट शामिल न हों, ताकि उन्हें बदलने पर ✅/🔴 गिनती न मिटे */
/** नंबर न मिलने पर क्लिक करने के लिए कम से कम एक टेक्स्ट लिखा हो तभी वह सुविधा चालू */
fun numCloseOn(cmd: String): Boolean { val e = numExtras(cmd); return e.first.isNotEmpty() || e.second.isNotEmpty() }
private fun numCore(cmd: String): String = cmd.removePrefix("NUM:").substringBefore("¦")
/** कमांड (GATE:/~~ हटाकर) नंबर वाली हो तो उसका रूप NUM:... लौटाओ */
fun numOfStep(st: String): String? {
    val st0 = stripLimit(st)
    val raw = if (st0.contains("~~")) st0.substringBeforeLast("~~") else st0
    val cmd = if (raw.startsWith("GATE:")) raw.removePrefix("GATE:").substringAfter(":") else raw
    return if (numParse(cmd) != null) cmd else null
}
fun numFailKey(cmd: String): String = "nf_" + numCore(cmd)
/** 🔴 वाले नंबर: नंबर → कितनी बार कोशिश में सारी कमांड सफल नहीं हुईं */
fun numFailed(sp: android.content.SharedPreferences, key: String): MutableMap<Int, Int> {
    val out = HashMap<Int, Int>()
    for (e in sp.getString(key, "")!!.split(",")) {
        val p = e.split(":")
        val n = p.getOrNull(0)?.trim()?.toIntOrNull() ?: continue
        out[n] = p.getOrNull(1)?.trim()?.toIntOrNull() ?: 1
    }
    return out
}
fun numKey(cmd: String): String = "nd_" + numCore(cmd)
fun numDone(sp: android.content.SharedPreferences, key: String): MutableSet<Int> =
    sp.getString(key, "")!!.split(",").mapNotNull { it.trim().toIntOrNull() }.toMutableSet()

private fun prettyBase(s: String): String = when {
    s.contains("|ALT|") -> {
        val v = s.split("|ALT|")
        prettyBase(v[0]) + v.drop(1).joinToString("") {
            if (it.startsWith("↺")) "  ➜ न मिले तो: " + prettyBase(it.removePrefix("↺")) + " दबाओ, फिर पहली फिर खोजो"
            else "  ➜ न मिले तो: " + prettyBase(it)
        }
    }
    s.startsWith("NUM:") -> numParse(s)?.let { "🔢 \"${it.third}\" + नंबर (${it.first} से ${it.second})" } ?: s
    s.startsWith("SWIPE:") -> {
        val p = s.split(":", limit = 3)
        val d = when (p[1]) { "left" -> "⬅ बाएँ"; "right" -> "➡ दाएँ"; "up" -> "⬆ ऊपर"; else -> "⬇ नीचे" }
        val t = p.getOrElse(2) { "" }
        val where = when {
            t.isEmpty() -> "स्क्रीन के बीच से"
            t.startsWith("IMG:") -> "🖼 फोटो पर"
            else -> "\"$t\" पर"
        }
        "स्वाइप $d — $where"
    }
    s.startsWith("POS:") -> "📍 स्क्रीन पर " + s.removePrefix("POS:") + " % जगह टैप"
    s.startsWith("GATE:") -> "📸 स्क्रीन मिले तो → " + prettyBase(s.removePrefix("GATE:").substringAfter(":"))
    s.startsWith("IMG:opt:") -> "🖼 फोटो (वैकल्पिक)"
    s.startsWith("IMG:req:") -> "🖼 फोटो (ज़रूरी)"
    else -> s
}
