package com.example.appcontrol

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.content.Intent
import android.graphics.Color
import android.graphics.Path
import android.graphics.Rect
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.view.Display
import java.io.File
import java.util.concurrent.Executors
import kotlin.math.abs
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.TextView
import android.widget.Toast

class ControlService : AccessibilityService() {

    companion object { var instance: ControlService? = null }

    private val handler = Handler(Looper.getMainLooper())
    private var steps: List<String> = emptyList()
    private var index = 0
    private var running = false
    private var badge: TextView? = null
    private var stepStart = 0L
    private var queue: List<String> = emptyList()
    private var qIndex = 0
    private var skippedThisApp = false
    private var autoRetry = false
    private var round = 1
    private var roundFailed = 0
    private var noProgress = 0
    private val bg = Executors.newSingleThreadExecutor()
    private var busy = false
    private var recheck = false
    private var reviewPending = false
    private var reviewWaiting = false
    private var skipReviewOnce = false
    private val tplCache = HashMap<String, Bitmap?>()
    // पिछला ऐप बंद करने की स्थिति
    private var closePkg: String? = null
    private var closeStart = 0L
    private var closeClicked = false
    private var afterClose: (() -> Unit)? = null

    override fun onServiceConnected() { instance = this }

    // ---------- प्रोजेक्ट कतार: एक पूरा होते ही अगला (बीच में वाईफाई बंद-चालू) ----------
    private var chainOn = false
    private var chainNames: List<String> = emptyList()
    private var chainIdx = 0
    private var wifiOffByUs = false

    private fun projData(n: String): Pair<List<String>, List<String>> {
        val sp = getSharedPreferences("apps", MODE_PRIVATE)
        fun l(k: String) = sp.getString(k, "")!!.split("\n").filter { it.isNotBlank() }
        return l("a_$n").distinct() to l("p_$n")
    }

    private fun nextValidProject(from: Int): Int {
        var k = from
        while (k < chainNames.size) {
            val (a, st) = projData(chainNames[k])
            if (a.isNotEmpty() && st.isNotEmpty()) return k
            toast("\"${chainNames[k]}\" में ऐप/कमांड नहीं — छोड़ा")
            k++
        }
        return -1
    }

    fun startChain(names: List<String>) {
        stop()
        chainNames = names; chainOn = true
        val k = nextValidProject(0)
        if (k < 0) { chainOn = false; toast("कोई प्रोजेक्ट चलाने लायक नहीं"); return }
        launchProject(k, false)
    }

    private fun launchProject(k: Int, cycleWifi: Boolean) {
        chainIdx = k
        val n = chainNames[k]
        val (apps, st) = projData(n)
        val go = {
            getSharedPreferences("apps", MODE_PRIVATE).edit()
                .putString("cur", n).putString("steps", st.joinToString("\n"))
                .putString("pkgs", apps.joinToString("\n")).putString("failed", apps.joinToString("\n"))
                .putBoolean("ran", true).apply()
            startQueue(apps, st, true, false, true)
        }
        val sp = getSharedPreferences("apps", MODE_PRIVATE)
        val wantWifi = cycleWifi && sp.getBoolean("wifiCycle", true)
        val vpnPkg = sp.getString("vpnPkg", "")!!
        val wantVpn = cycleWifi && sp.getBoolean("vpnCycle", false) && vpnPkg.isNotEmpty()
        val vpnWasOn = onVpn()
        val fail = { why: String -> chainFail("$why — इसलिए प्रोजेक्ट रुका रह गया, अगला प्रोजेक्ट \"$n\" शुरू नहीं हुआ") }
        val afterWifi = { if (wantVpn) vpnCycle(n, vpnPkg, vpnWasOn, go, fail) else go() }
        if (wantWifi) wifiCycle(n, afterWifi, fail) else afterWifi()
    }

    /** वाईफाई की शर्त पूरी न हुई: कतार बंद, सब बंद, होम; ऐप खोलने पर कारण दिखेगा */
    private fun chainFail(msg: String) {
        getSharedPreferences("apps", MODE_PRIVATE).edit().putString("stopMsg", msg).apply()
        chainOn = false
        toast(msg)
        stop()
        try { MainActivity.cur?.finishAndRemoveTask() } catch (e: Exception) {}
        Handler(Looper.getMainLooper()).postDelayed({
            try { performGlobalAction(GLOBAL_ACTION_HOME) } catch (e: Exception) {}
        }, 500)
    }

    /** पूरे ऐप निपटने के बाद अगला प्रोजेक्ट; शुरू हुआ तो true */
    private fun runNextProject(): Boolean {
        if (!chainOn) return false
        val k = nextValidProject(chainIdx + 1)
        if (k < 0) { chainOn = false; return false }
        launchProject(k, true)
        return true
    }

    @Suppress("DEPRECATION")
    private fun onWifi(): Boolean {
        val cm = getSystemService(ConnectivityManager::class.java) ?: return false
        return cm.allNetworks.any { cm.getNetworkCapabilities(it)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true }
    }

    private fun wifiBadge(t: String) { badge?.text = "📶 $t" }

    @Suppress("DEPRECATION")
    private fun onVpn(): Boolean {
        val cm = getSystemService(ConnectivityManager::class.java) ?: return false
        return cm.allNetworks.any { cm.getNetworkCapabilities(it)?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true }
    }

    private fun vpnLines(key: String): List<String> =
        getSharedPreferences("apps", MODE_PRIVATE).getString(key, "")!!.split("\n").map { it.trim() }.filter { it.isNotEmpty() }

    /** वीपीएन ऐप खोलकर आपके लिखे स्टेप क्रम से टैप करो; कोई स्टेप 20 सेकंड में न मिले तो fail */
    private fun runVpnSteps(pkg: String, stepsL: List<String>, ok: () -> Unit, fail: (String) -> Unit) {
        val i = packageManager.getLaunchIntentForPackage(pkg)
        if (i == null) { fail("🔒 वीपीएन ऐप खुल नहीं पाया"); return }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
        var si = 0
        var tries = 0
        fun tap() {
            if (si >= stepsL.size) { ok(); return }
            val root = rootInActiveWindow
            val node = if (root != null && root.packageName == pkg) findNode(root, stepsL[si]) else null
            if (node != null && clickNode(node)) {
                badge?.text = "🔒 वीपीएन स्टेप ${si + 1}/${stepsL.size} ✔"
                si++; tries = 0
                handler.postDelayed({ tap() }, 1500)
                return
            }
            if (tries >= 20) { fail("🔒 वीपीएन में \"${stepsL[si]}\" नहीं मिला"); return }
            tries++; handler.postDelayed({ tap() }, 1000)
        }
        handler.postDelayed({ tap() }, 2500)
    }

    /** वीपीएन जुड़ा था तो: आपके 'बंद' स्टेप (खाली हो तो Force stop) → डिस्कनेक्ट का इंतज़ार → 'चालू' स्टेप → जुड़ने का इंतज़ार (120 सेकंड) */
    private fun vpnCycle(next: String, pkg: String, wasOn: Boolean, go: () -> Unit, fail: (String) -> Unit) {
        if (!wasOn) { go(); return }                          // वीपीएन जुड़ा ही नहीं था
        badge?.text = "🔒 वीपीएन बंद हो रहा… (अगला: $next)"
        var t = 0
        fun waitOn() {
            if (onVpn()) {
                badge?.text = "🔒 वीपीएन जुड़ गया ✔"
                handler.postDelayed({ if (onVpn()) go() else waitOn() }, 3000)   // जुड़े रहने की दोबारा जाँच
                return
            }
            if (t >= 240) { fail("🔒 वीपीएन कनेक्ट नहीं हुआ (120 सेकंड इंतज़ार किया)"); return }
            t++; handler.postDelayed({ waitOn() }, 500)
        }
        fun connect() {
            badge?.text = "🔒 वीपीएन चालू हो रहा…"
            val onSteps = vpnLines("vpnOn")
            if (onSteps.isEmpty()) {                          // बिना स्टेप: ऐप खुलते ही खुद जुड़ेगा
                val i = packageManager.getLaunchIntentForPackage(pkg)
                if (i == null) { fail("🔒 वीपीएन ऐप खुल नहीं पाया"); return }
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i)
                t = 0; handler.postDelayed({ waitOn() }, 1000)
            } else runVpnSteps(pkg, onSteps, { t = 0; waitOn() }, fail)
        }
        fun waitOff() {
            if (!onVpn() || t >= 60) { handler.postDelayed({ connect() }, 3000); return }   // 30 सेकंड तक डिस्कनेक्ट का इंतज़ार
            t++; handler.postDelayed({ waitOff() }, 500)
        }
        val offSteps = vpnLines("vpnOff")
        if (offSteps.isEmpty()) {
            val ok = Shell.best("am force-stop $pkg") { }
            if (!ok) { fail("🔒 वीपीएन बंद नहीं कर पाए (बंद के स्टेप नहीं लिखे और Shizuku/Root भी जुड़ा नहीं)"); return }
            handler.postDelayed({ waitOff() }, 1000)
        } else runVpnSteps(pkg, offSteps, { t = 0; handler.postDelayed({ waitOff() }, 1000) }, fail)
    }

    /** वाईफाई से जुड़ा हो तो: बंद → डिस्कनेक्ट होने तक रुको → चालू → दोबारा जुड़ने तक रुको → फिर go() */
    private fun wifiCycle(next: String, go: () -> Unit, fail: (String) -> Unit) {
        if (!onWifi()) { go(); return }                       // वाईफाई से जुड़ा ही नहीं था
        wifiBadge("वाईफाई बंद हो रहा… (अगला: $next)")
        val ok = Shell.best("svc wifi disable") { }
        if (!ok) { fail("📶 वाईफाई बंद नहीं कर पाए (Shizuku/Root जुड़ा नहीं)"); return }
        wifiOffByUs = true
        var t = 0
        fun waitBack() {
            if (onWifi()) {
                wifiBadge("वाईफाई जुड़ गया ✔")
                handler.postDelayed({ if (onWifi()) go() else waitBack() }, 3000)   // जुड़े रहने की दोबारा जाँच
                return
            }
            if (t >= 240) { fail("📶 वाईफाई कनेक्ट नहीं हुआ (120 सेकंड इंतज़ार किया)"); return }
            t++; handler.postDelayed({ waitBack() }, 500)
        }
        fun enable() {
            wifiBadge("वाईफाई चालू हो रहा…")
            Shell.best("svc wifi enable") { }
            wifiOffByUs = false
            t = 0; handler.postDelayed({ waitBack() }, 1000)
        }
        fun waitOff() {
            if (!onWifi() || t >= 40) {                         // 20 सेकंड तक डिस्कनेक्ट का इंतज़ार
                handler.postDelayed({ enable() }, 3000)         // बंद अवस्था में 3 सेकंड रुको
                return
            }
            t++; handler.postDelayed({ waitOff() }, 500)
        }
        handler.postDelayed({ waitOff() }, 500)
    }

    /** सभी ऐप में बारी-बारी वही कमांड चलाओ */
    fun startQueue(pkgs: List<String>, list: List<String>, auto: Boolean = false, isRecheck: Boolean = false, chain: Boolean = false) {
        stop()
        if (!chain) chainOn = false
        if (pkgs.isEmpty() || list.isEmpty()) { toast("ऐप या कमांड नहीं जोड़ी"); return }
        queue = pkgs; qIndex = 0; steps = list; index = 0; running = true
        autoRetry = auto; round = 1; noProgress = 0; recheck = isRecheck
        armReview()
        roundFailed = maxOf(failedList().size, pkgs.size)
        stepStart = System.currentTimeMillis() + 2500
        showBadge()
        launchApp(pkgs[0])
        handler.postDelayed(tick, 2500)
    }

    private fun reviewImgs(): List<String> =
        getSharedPreferences("apps", MODE_PRIVATE).getString("reviewImgs", "")!!
            .split("\n").filter { it.isNotBlank() }

    /** दोबारा चेक (राउंड 2+ या 'सिर्फ़ अधूरे') में हर ऐप पर पहले रिव्यू फोटो खोजो */
    private fun armReview() {
        reviewPending = (recheck || round >= 2) && reviewImgs().isNotEmpty()
        reviewWaiting = false; skipReviewOnce = false
    }

    /** दोबारा चेक में हर कमांड से पहले स्क्रीन पर रिव्यू फोटो देखो (किसी भी कमांड पर मिल सकती है) */
    private fun startReviewCheck() {
        val root = rootInActiveWindow
        if (root == null || root.packageName == packageName || System.currentTimeMillis() < stepStart - 1500) {
            skipReviewOnce = true; return        // ऐप अभी खुला नहीं: सामान्य कमांड-पास चलने दो
        }
        // सिर्फ़ इसी कमांड नंबर के लिए जोड़ी गई रिव्यू फोटो (नंबर 0 या बिना नंबर = हर कमांड पर)
        val tpls = reviewImgs().mapNotNull { line ->
            val n = line.substringBefore("|", "0").toIntOrNull() ?: 0
            if (n == 0 || n == index + 1) loadTemplate(line.substringAfter("|")) else null
        }
        if (tpls.isEmpty()) { skipReviewOnce = true; return }
        if (Build.VERSION.SDK_INT >= 30) {
            busy = true
            shotApi30 { bmp -> finishReview(bmp, tpls) }
        } else {
            val cs = CaptureService.instance
            if (cs == null) { skipReviewOnce = true; return }
            busy = true
            bg.execute { finishReview(cs.capture(), tpls) }
        }
        reviewWaiting = true
    }

    private fun finishReview(bmp: Bitmap?, tpls: List<Bitmap>) {
        val found = bmp != null && tpls.any { match(bmp, it, 0.68, true, 2) != null }
        handler.post {
            busy = false; reviewWaiting = false
            if (!running || !reviewPending) return@post
            if (found) {
                reviewPending = false             // रिव्यू फोटो मिली: सही मानो, ✔ लगाओ, आगे बढ़ो
                skippedThisApp = false
                index = 0
                finish()
            } else {
                skipReviewOnce = true             
                handler.removeCallbacks(tick); handler.post(tick)
            }
        }
    }

    private fun failedList(): List<String> =
        getSharedPreferences("apps", MODE_PRIVATE).getString("failed", "")!!
            .split("\n").filter { it.isNotBlank() }

    private fun markDone(pkg: String) {
        val l = failedList().filter { it != pkg }
        getSharedPreferences("apps", MODE_PRIVATE).edit()
            .putString("failed", l.joinToString("\n")).apply()
    }

    private fun launchApp(pkg: String) {
        val i = packageManager.getLaunchIntentForPackage(pkg) ?: return
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (getSharedPreferences("apps", MODE_PRIVATE).getBoolean("boostBefore", true))
            Shell.boost(this, setOf(pkg)) { startActivity(i) }
        else startActivity(i)
    }

    /** कमांड 1, 2, 3... क्रम से चलाना शुरू */
    fun startSequence(list: List<String>) {
        stop(); chainOn = false
        if (list.isEmpty()) { toast("कोई कमांड नहीं जोड़ी"); return }
        steps = list; index = 0; running = true
        stepStart = System.currentTimeMillis() + 1500
        showBadge()
        handler.postDelayed(tick, 1500) // ऐप खुलने का इंतज़ार
    }

    private fun stop() {
        if (wifiOffByUs) { wifiOffByUs = false; Shell.best("svc wifi enable") { } }   // रोकने पर वाईफाई बंद न रह जाए
        running = false
        missIdx = -1; missCnt = 0
        closePkg = null; afterClose = null; reviewPending = false; reviewWaiting = false; skipReviewOnce = false; recheck = false
        queue = emptyList(); qIndex = 0; skippedThisApp = false; autoRetry = false
        handler.removeCallbacksAndMessages(null)
        badge?.let { try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } catch (e: Exception) {} }
        badge = null
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            if (closePkg == "recents") { handler.postDelayed(this, 700); return }
            if (closePkg != null) { closeTick(); return }
            if (reviewPending) {
                if (reviewWaiting) { handler.postDelayed(this, 500); return }
                if (!busy) {
                    if (skipReviewOnce) skipReviewOnce = false
                    else { startReviewCheck(); if (reviewWaiting) return }
                }
            }
            val cmd = steps[index]
            // स्वाइप कमांड का रूप:  SWIPE:<left|right|up|down>:<टेक्स्ट या IMG:req:फाइल या खाली>
            val parts = cmd.split(":", limit = 3)
            val swipeDir: String? = if (cmd.startsWith("SWIPE:")) parts[1] else null
            val target = if (swipeDir != null) parts.getOrElse(2) { "" } else cmd
            val isImg = target.startsWith("IMG:")
            val optional = (swipeDir == null && isCross(cmd)) || target.startsWith("IMG:opt:")
            // वैकल्पिक कमांड ~4 सेकंड में न मिले तो आगे बढ़ जाओ
            val secs = getSharedPreferences("apps", MODE_PRIVATE).getInt("limit", 8)
            val limit = if (optional) minOf(secs, 4) * 1000 else secs * 1000
            if (!busy && System.currentTimeMillis() - stepStart > limit) {
                if (!optional) skippedThisApp = true
                if (!advance()) return
                handler.postDelayed(this, 600); return
            }
            val root = rootInActiveWindow
            // हमारे अपने ऐप की स्क्रीन पर नहीं खोजना
            if (root != null && root.packageName != packageName) {
                if (isImg) {
                    if (!busy) findAndTapImage(target, swipeDir)
                    handler.postDelayed(this, 1000); return
                }
                if (swipeDir != null) {
                    // टेक्स्ट मिल जाए तो उसी जगह से स्वाइप (क्लिक नहीं); खाली हो तो स्क्रीन के बीच से
                    if (!busy) {
                        if (target.isEmpty()) {
                            val dm = resources.displayMetrics
                            swipeAt(dm.widthPixels / 2, dm.heightPixels / 2, swipeDir, index)
                        } else {
                            val node = findNode(root, target)
                            if (node != null) {
                                val r = Rect(); node.getBoundsInScreen(r)
                                if (!r.isEmpty) swipeAt(r.centerX(), r.centerY(), swipeDir, index)
                            }
                        }
                    }
                    handler.postDelayed(this, 600); return
                }
                val node = if (isCross(cmd)) findCross(root) else findNode(root, cmd)
                if (node != null && clickNode(node)) {
                    if (!advance()) return
                    handler.postDelayed(this, 1200) // अगली स्क्रीन का इंतज़ार
                    return
                }
            }
            handler.postDelayed(this, 600) // मिला नहीं तो खोजते रहो
        }
    }

    // ---------- फोटो से खोजना ----------
    private fun loadTemplate(name: String): Bitmap? = tplCache.getOrPut(name) {
        BitmapFactory.decodeFile(File(filesDir, name).path)
    }

    private fun findAndTapImage(cmd: String, dir: String? = null) {
        val tpl = loadTemplate(cmd.substringAfterLast(":")) ?: return
        val my = index
        if (Build.VERSION.SDK_INT >= 30) {
            busy = true
            shotApi30 { bmp -> finishMatch(bmp, tpl, my, dir, cmd.substringAfterLast(":")) }
        } else {
            val cs = CaptureService.instance
            if (cs == null) {
                if (System.currentTimeMillis() % 5 == 0L) toast("मुख्य ऐप में 'स्क्रीन कैप्चर अनुमति' दें")
                return
            }
            busy = true
            bg.execute { finishMatch(cs.capture(), tpl, my, dir, cmd.substringAfterLast(":")) }
        }
    }

    @android.annotation.TargetApi(30)
    private fun shotApi30(done: (Bitmap?) -> Unit) {
        takeScreenshot(Display.DEFAULT_DISPLAY, bg, object : AccessibilityService.TakeScreenshotCallback {
            override fun onSuccess(r: AccessibilityService.ScreenshotResult) {
                val hb = r.hardwareBuffer
                val bmp = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)?.copy(Bitmap.Config.ARGB_8888, false)
                hb.close()
                done(bmp)
            }
            override fun onFailure(code: Int) { done(null) }
        })
    }

    /** (bg थ्रेड पर) मिलान करो, फिर मुख्य थ्रेड पर टैप (dir खाली) या स्वाइप */
    @Volatile private var missIdx = -1
    @Volatile private var missCnt = 0

    @Volatile private var matchInfo = ""
    @Volatile private var matchInfoIdx = -1
    private val tplText = HashMap<String, Pair<Int, String>?>()

    /** फोटो के अंदर लिखे अक्षर (एक बार पढ़कर याद रखता है): (भाषा, अक्षर) या null */
    private fun templateText(name: String, tpl: Bitmap): Pair<Int, String>? {
        if (tplText.containsKey(name)) return tplText[name]
        val k = if (tpl.height < 60) 3 else if (tpl.height < 120) 2 else 1
        val big = if (k == 1) tpl else Bitmap.createScaledBitmap(tpl, tpl.width * k, tpl.height * k, true)
        var res: Pair<Int, String>? = null
        for (kind in 0..1) {
            val t = TextFinder.read(big, kind).joinToString("") { it.text }
            if (t.length >= 2) { res = kind to t; break }
        }
        tplText[name] = res
        return res
    }

    private fun meanColor(b: Bitmap, x: Int, y: Int, w: Int, h: Int): IntArray {
        val xx = x.coerceIn(0, maxOf(0, b.width - 1)); val yy = y.coerceIn(0, maxOf(0, b.height - 1))
        val ww = minOf(w, b.width - xx).coerceAtLeast(1); val hh = minOf(h, b.height - yy).coerceAtLeast(1)
        val px = IntArray(ww * hh); b.getPixels(px, 0, ww, xx, yy, ww, hh)
        var r = 0L; var g = 0L; var bl = 0L
        for (c in px) { r += (c shr 16) and 255; g += (c shr 8) and 255; bl += c and 255 }
        val n = px.size
        return intArrayOf((r / n).toInt(), (g / n).toInt(), (bl / n).toInt())
    }

    private fun colorDist(a: IntArray, b: IntArray): Double {
        val dr = a[0] - b[0]; val dg = a[1] - b[1]; val db = a[2] - b[2]
        return Math.sqrt((dr * dr + dg * dg + db * db).toDouble())
    }

    /** पिक्सल से न मिले तो: फोटो के अंदर लिखे अक्षर स्क्रीन पर खोजो; कई मिलें तो रंग सबसे मिलता-जुलता चुनो */
    private fun textFallback(bmp: Bitmap, tpl: Bitmap, name: String): Pair<Int, Int>? {
        val tt = templateText(name, tpl) ?: return null
        val hits = TextFinder.read(bmp, tt.first).filter { TextFinder.sim(it.text, tt.second) >= 0.8 }
        if (hits.isEmpty()) return null
        val tc = meanColor(tpl, 0, 0, tpl.width, tpl.height)
        val best = hits.minByOrNull { h ->
            val x0 = (h.box.centerX() - tpl.width / 2).coerceIn(0, maxOf(0, bmp.width - tpl.width))
            val y0 = (h.box.centerY() - tpl.height / 2).coerceIn(0, maxOf(0, bmp.height - tpl.height))
            colorDist(meanColor(bmp, x0, y0, tpl.width, tpl.height), tc)
        } ?: return null
        return Pair(best.box.centerX(), best.box.centerY())
    }

    private fun finishMatch(bmp: Bitmap?, tpl: Bitmap, my: Int, dir: String?, name: String) {
        // नहीं मिलने पर हर कोशिश में थोड़ा "मिलता-जुलता" भी मान लो (0.85 → 0.60 तक), और आकार की छूट भी
        if (missIdx != my) { missIdx = my; missCnt = 0 }
        val thr = maxOf(0.55, 0.82 - 0.04 * missCnt)
        var pos = if (bmp != null) match(bmp, tpl, thr, missCnt >= 3, missCnt) else null
        var viaText = false
        val pixScore = lastMatchScore
        if (pos == null && bmp != null && missCnt >= 1) { pos = textFallback(bmp, tpl, name); viaText = pos != null }
        if (bmp != null) {
            matchInfoIdx = my
            matchInfo = (if (viaText) "🔤 अक्षरों से मिला" else if (pos != null) "🎯 मिला" else "🔍 नहीं मिला") +
                " (मिलान " + java.lang.String.format(java.util.Locale.US, "%.2f/%.2f", pixScore, thr) + ")"
            if (pos == null) missCnt++ else missCnt = 0
        }
        handler.post {
            if (!running || index != my || pos == null) { busy = false; return@post }
            if (dir == null) {
                val path = Path().apply { moveTo(pos.first.toFloat(), pos.second.toFloat()) }
                runGesture(path, 60, my)
            } else swipeAt(pos.first, pos.second, dir, my)
        }
    }

    /** (cx, cy) के आसपास उंगली से स्वाइप. left = उंगली दाएँ से बाएँ चलेगी */
    private fun swipeAt(cx: Int, cy: Int, dir: String, my: Int) {
        val dm = resources.displayMetrics
        val w = dm.widthPixels; val h = dm.heightPixels
        val hx = (w * 0.30f).toInt(); val hy = (h * 0.20f).toInt()
        fun cx_(v: Int) = v.coerceIn(20, w - 20)
        fun cy_(v: Int) = v.coerceIn(20, h - 20)
        val (sx, sy, ex, ey) = when (dir) {
            "left" -> listOf(cx + hx, cy, cx - hx, cy)
            "right" -> listOf(cx - hx, cy, cx + hx, cy)
            "up" -> listOf(cx, cy + hy, cx, cy - hy)
            else -> listOf(cx, cy - hy, cx, cy + hy)   // down
        }
        val path = Path().apply {
            moveTo(cx_(sx).toFloat(), cy_(sy).toFloat())
            lineTo(cx_(ex).toFloat(), cy_(ey).toFloat())
        }
        runGesture(path, 350, my)
    }

    private fun runGesture(path: Path, dur: Long, my: Int) {
        busy = true
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, dur)).build()
        val ok = dispatchGesture(g, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) {
                busy = false
                if (running && index == my && advance()) {
                    handler.removeCallbacks(tick); handler.postDelayed(tick, 1200)
                }
            }
            override fun onCancelled(d: GestureDescription?) { busy = false }
        }, null)
        if (!ok) busy = false
    }

    private fun gray(b: Bitmap, w: Int, h: Int): IntArray {
        val px = IntArray(w * h)
        b.getPixels(px, 0, w, 0, 0, w, h)
        for (i in px.indices) {
            val c = px[i]
            px[i] = (((c shr 16) and 255) * 3 + ((c shr 8) and 255) * 6 + (c and 255)) / 10
        }
        return px
    }

    // ---------- फोटो मिलान (NCC): रोशनी/कंट्रास्ट बदलने पर भी पहचानता है ----------
    /** f×f के डिब्बों का औसत लेकर छोटा gray ऐरे; (ऐरे, चौड़ाई, ऊँचाई) */
    private fun grayBox(b: Bitmap, f: Int): Triple<IntArray, Int, Int> {
        val w = b.width; val h = b.height
        val px = IntArray(w * h); b.getPixels(px, 0, w, 0, 0, w, h)
        val ow = w / f; val oh = h / f
        val out = IntArray(ow * oh)
        val div = f * f * 10
        for (y in 0 until oh) for (x in 0 until ow) {
            var sum = 0
            for (dy in 0 until f) {
                val row = (y * f + dy) * w + x * f
                for (dx in 0 until f) {
                    val c = px[row + dx]
                    sum += ((c shr 16) and 255) * 3 + ((c shr 8) and 255) * 6 + (c and 255)
                }
            }
            out[y * ow + x] = sum / div
        }
        return Triple(out, ow, oh)
    }

    private fun integral(a: IntArray, w: Int, h: Int, sq: Boolean): LongArray {
        val W = w + 1
        val I = LongArray(W * (h + 1))
        for (y in 0 until h) {
            var row = 0L
            for (x in 0 until w) {
                val v = a[y * w + x].toLong()
                row += if (sq) v * v else v
                I[(y + 1) * W + x + 1] = I[y * W + x + 1] + row
            }
        }
        return I
    }

    private fun winSum(I: LongArray, w: Int, x: Int, y: Int, tw: Int, th: Int): Long {
        val W = w + 1
        return I[(y + th) * W + x + tw] - I[y * W + x + tw] - I[(y + th) * W + x] + I[y * W + x]
    }

    private class Tpl(val t: FloatArray, val w: Int, val h: Int, val varSum: Double)

    private fun prepTpl(g: Triple<IntArray, Int, Int>): Tpl? {
        val (a, w, h) = g
        if (w < 3 || h < 3) return null
        var m = 0.0
        for (v in a) m += v
        m /= a.size
        val t = FloatArray(a.size)
        var vs = 0.0
        for (i in a.indices) { val d = (a[i] - m).toFloat(); t[i] = d; vs += d * d }
        if (vs / a.size < 4.0) return null          // फोटो लगभग एक रंग की है — पहचानने लायक नहीं
        return Tpl(t, w, h, vs)
    }

    /** स्क्रीन-ऐरे S में (x,y) पर NCC; सपाट हिस्से पर -1 */
    private fun nccAt(S: IntArray, sw: Int, x: Int, y: Int, T: Tpl): Double {
        val n = T.w * T.h
        var sum = 0L; var sum2 = 0L; var dot = 0.0
        for (ty in 0 until T.h) {
            val so = (y + ty) * sw + x; val to = ty * T.w
            for (tx in 0 until T.w) {
                val v = S[so + tx]
                sum += v; sum2 += v.toLong() * v
                dot += v * T.t[to + tx]
            }
        }
        val varS = sum2 - sum.toDouble() * sum / n
        if (varS / n < 2.0) return -1.0
        return dot / Math.sqrt(varS * T.varSum)
    }

    @Volatile private var lastMatchScore = 0.0

    /**
     * स्क्रीनशॉट में फोटो की सबसे मिलती जगह (केंद्र x, y) या null.
     * minScore: 0..1 (1 = हूबहू). wide = true हो तो थोड़ा छोटे/बड़े आकार में भी खोजता है.
     */
    private fun match(scr: Bitmap, tpl: Bitmap, minScore: Double = 0.78, wide: Boolean = false, level: Int = 0): Pair<Int, Int>? {
        // level (नाकाम कोशिशें): ज़्यादा हो तो ज़्यादा आकार आज़माओ, और फोटो का सिर्फ़ बीच का हिस्सा भी
        var res = matchOne(scr, tpl, minScore, wide, level)
        if (res == null && level >= 1) {
            val cw = (tpl.width * 0.7).toInt(); val ch = (tpl.height * 0.7).toInt()
            if (cw >= 24 && ch >= 24) {
                val core = Bitmap.createBitmap(tpl, (tpl.width - cw) / 2, (tpl.height - ch) / 2, cw, ch)
                val keep = lastMatchScore
                res = matchOne(scr, core, minScore + 0.05, wide, level)   // बीच का हिस्सा छोटा है, इसलिए थोड़ी सख़्ती
                if (res == null) lastMatchScore = maxOf(keep, lastMatchScore)
            }
        }
        return res
    }

    private fun matchOne(scr: Bitmap, tpl: Bitmap, minScore: Double, wide: Boolean, level: Int): Pair<Int, Int>? {
        val maxSide = maxOf(tpl.width, tpl.height)
        val f1 = maxOf(3, Math.ceil(maxSide / 24.0).toInt())     // मोटी खोज का छोटा आकार
        val f2 = maxOf(1, f1 / 2)                                 // बारीक खोज
        val (S1, sw, sh) = grayBox(scr, f1)
        val I1 = integral(S1, sw, sh, false); val I2 = integral(S1, sw, sh, true)
        val scales = when {
            level >= 3 || wide -> doubleArrayOf(1.0, 0.95, 1.05, 0.9, 1.1, 0.85, 1.15, 0.8, 1.2)
            level >= 1 -> doubleArrayOf(1.0, 0.95, 1.05, 0.9, 1.1)
            else -> doubleArrayOf(1.0, 0.95, 1.05)
        }
        var bestScore = -2.0; var bestPos: Pair<Int, Int>? = null

        for (sc in scales) {
            val tw0 = (tpl.width * sc).toInt(); val th0 = (tpl.height * sc).toInt()
            if (tw0 < f1 * 3 || th0 < f1 * 3 || tw0 > scr.width || th0 > scr.height) continue
            val tb = if (sc == 1.0) tpl else Bitmap.createScaledBitmap(tpl, tw0, th0, true)
            val T1 = prepTpl(grayBox(tb, f1)) ?: continue
            if (T1.w > sw || T1.h > sh) continue
            // मोटी खोज: हर जगह NCC; सबसे अच्छी 3 अलग-अलग जगहें रखो (सिर्फ़ एक पर भरोसा नहीं)
            val n = T1.w * T1.h
            val cand = ArrayList<Triple<Double, Int, Int>>()
            for (y in 0..(sh - T1.h)) for (x in 0..(sw - T1.w)) {
                val sum = winSum(I1, sw, x, y, T1.w, T1.h)
                val sum2 = winSum(I2, sw, x, y, T1.w, T1.h)
                if ((sum2 - sum.toDouble() * sum / n) / n < 2.0) continue   // सपाट जगह छोड़ो
                val v = nccAt(S1, sw, x, y, T1)
                if (v < minScore - 0.30) continue
                // पास की जगहों में से सिर्फ़ सबसे अच्छी रखो
                val near = cand.indexOfFirst { Math.abs(it.second - x) < T1.w / 2 && Math.abs(it.third - y) < T1.h / 2 }
                if (near >= 0) { if (v > cand[near].first) cand[near] = Triple(v, x, y) }
                else cand.add(Triple(v, x, y))
            }
            cand.sortByDescending { it.first }
            for (c in cand.take(3)) {
                // बारीक खोज: उसी जगह के आसपास
                val ox = c.second * f1; val oy = c.third * f1
                val rx = maxOf(0, ox - f1 * 2); val ry = maxOf(0, oy - f1 * 2)
                val rw = minOf(scr.width, ox + tw0 + f1 * 2) - rx; val rh = minOf(scr.height, oy + th0 + f1 * 2) - ry
                if (rw < f2 * 3 || rh < f2 * 3) continue
                val region = Bitmap.createBitmap(scr, rx, ry, rw, rh)
                val (S2, rw2, rh2) = grayBox(region, f2)
                val T2 = prepTpl(grayBox(tb, f2)) ?: continue
                if (T2.w > rw2 || T2.h > rh2) continue
                var fs = -2.0; var fx = 0; var fy = 0
                for (y in 0..(rh2 - T2.h)) for (x in 0..(rw2 - T2.w)) {
                    val v = nccAt(S2, rw2, x, y, T2)
                    if (v > fs) { fs = v; fx = x; fy = y }
                }
                // रंग भी देखो: आकार-रूप मिले पर रंग बहुत अलग हो तो स्कोर थोड़ा घटाओ (अधिकतम 0.12)
                val wx = (rx + fx * f2).coerceIn(0, maxOf(0, scr.width - tw0)); val wy = (ry + fy * f2).coerceIn(0, maxOf(0, scr.height - th0))
                val cd = colorDist(meanColor(scr, wx, wy, tw0, th0), meanColor(tb, 0, 0, tb.width, tb.height))
                val adj = fs - ((cd - 40.0) / 500.0).coerceIn(0.0, 0.12)
                if (adj > bestScore) {
                    bestScore = adj
                    bestPos = Pair(rx + (fx + T2.w / 2) * f2, ry + (fy + T2.h / 2) * f2)
                }
            }
            if (bestScore >= 0.93) break                         // लगभग हूबहू मिल गया — और आकार देखने की ज़रूरत नहीं
        }
        lastMatchScore = bestScore
        return if (bestScore >= minScore) bestPos else null
    }

    /** अगली कमांड पर जाओ; सब पूरी हों तो false */
    private fun advance(): Boolean {
        missIdx = -1; missCnt = 0     // नई कमांड/ऐप: फोटो मिलान फिर पूरी सख़्ती से शुरू
        index++
        if (index >= steps.size) { finish(); return false }
        stepStart = System.currentTimeMillis()
        updateBadge()
        return true
    }

    private fun isCross(cmd: String) = cmd.trim().lowercase() in
        setOf("क्रॉस", "cross", "x", "×", "close", "बंद")

    // क्रॉस/बंद का निशान: टेक्स्ट ×, ✕, X या description/ID में close, dismiss आदि
    private fun findCross(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val marks = setOf("×", "✕", "✖", "✗", "╳", "x")
        val words = listOf("close", "dismiss", "cross", "बंद", "क्रॉस")
        val all = ArrayList<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            all.add(n)
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return all.firstOrNull { n ->
            if (!n.isVisibleToUser) return@firstOrNull false
            val t = n.text?.toString()?.trim()?.lowercase()
            val d = n.contentDescription?.toString()?.trim()?.lowercase()
            val id = n.viewIdResourceName?.lowercase()
            (t != null && t in marks) || (d != null && d in marks) ||
            (d != null && words.any { d.contains(it) }) ||
            (id != null && words.any { id.contains(it) })
        }
    }


    // ---------- पिछला ऐप बंद करना (App info -> Force stop) ----------
    private val forceLabels = setOf("force stop", "force-stop", "force close", "जबरन रोकें",
        "जबरदस्ती रोकें", "फ़ोर्स स्टॉप", "फोर्स स्टॉप", "बलपूर्वक रोकें", "जबरन बंद करें")
    private val okLabels = setOf("ok", "ठीक है", "ओके", "yes", "हाँ")

    private fun closeThen(pkg: String, go: () -> Unit) {
        val mode = getSharedPreferences("apps", MODE_PRIVATE).getInt("closeMode", 1)
        if (mode == 0) { go(); return }
        if (mode == 1) { closeViaRecents(pkg, go); return }
        closePkg = pkg; afterClose = go; closeStart = System.currentTimeMillis(); closeClicked = false
        try {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) { endClose(); return }
        handler.removeCallbacks(tick); handler.postDelayed(tick, 1500)
    }


    // ---------- मिनिमाइज़ (Recents) में सिर्फ़ उसी ऐप का कार्ड ऊपर स्वाइप ----------
    private var rLabel = ""
    private var rAttempts = 0
    private var rNotFound = 0

    private fun appLabel(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) { pkg }

    /** Recents में उस ऐप के नाम वाला कार्ड खोजो; स्क्रीन पर दिखने वाला हिस्सा लौटाओ */
    private fun findRecentCard(label: String): Rect? {
        val roots = ArrayList<AccessibilityNodeInfo>()
        rootInActiveWindow?.let { roots.add(it) }
        try { windows.forEach { w -> w.root?.let { roots.add(it) } } } catch (e: Exception) {}
        val dm = resources.displayMetrics
        val screen = Rect(0, 0, dm.widthPixels, dm.heightPixels)
        val want = label.trim().lowercase()
        var exact: Rect? = null; var exactA = 0L
        var part: Rect? = null; var partA = 0L
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            val ts = listOf(n.text, n.contentDescription).mapNotNull { it?.toString()?.trim()?.lowercase() }
            val isExact = ts.any { it == want }
            val isPart = !isExact && ts.any { it.contains(want) }
            if (isExact || isPart) {
                val r = Rect(); n.getBoundsInScreen(r)
                if (r.intersect(screen) && !r.isEmpty) {
                    val area = r.width().toLong() * r.height()
                    if (isExact && area > exactA) { exact = r; exactA = area }
                    if (isPart && area > partA) { part = r; partA = area }
                }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        for (r in roots) if (r.packageName != packageName) walk(r)
        return exact ?: part
    }

    private fun closeViaRecents(pkg: String, go: () -> Unit) {
        closePkg = "recents"; afterClose = go
        rLabel = appLabel(pkg); rAttempts = 0; rNotFound = 0
        closeStart = System.currentTimeMillis()
        handler.removeCallbacks(tick)
        performGlobalAction(GLOBAL_ACTION_RECENTS)
        handler.postDelayed(recentsStep, 1300)
    }

    private val recentsStep = object : Runnable {
        override fun run() {
            if (!running || closePkg != "recents") return
            if (System.currentTimeMillis() - closeStart > 14000) { leaveRecents(); return }
            val card = findRecentCard(rLabel)
            if (card == null) {
                // पहली बार में न दिखे तो Recents खुलने का थोड़ा इंतज़ार; बाद में न दिखे = बंद हो चुका
                if (rAttempts == 0 && rNotFound < 4) { rNotFound++; handler.postDelayed(this, 700); return }
                leaveRecents(); return
            }
            if (rAttempts >= 3) { leaveRecents(); return }
            rAttempts++
            val dm = resources.displayMetrics
            val x = card.centerX().toFloat()
            val y0 = card.centerY().toFloat()
            val y1 = (y0 - dm.heightPixels * 0.45f).coerceAtLeast(20f)
            val path = Path().apply { moveTo(x, y0); lineTo(x, y1) }
            val g = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 220)).build()
            val again = { handler.postDelayed(this, 900) }
            val ok = dispatchGesture(g, object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(d: GestureDescription?) { again() }
                override fun onCancelled(d: GestureDescription?) { again() }
            }, null)
            if (!ok) again()
        }
    }

    private fun leaveRecents() {
        performGlobalAction(GLOBAL_ACTION_HOME)          // Recents से बाहर
        handler.postDelayed({ if (running && closePkg == "recents") endClose() }, 700)
    }

    private fun endClose() {
        closePkg = null
        val a = afterClose; afterClose = null
        handler.removeCallbacks(tick)
        a?.invoke()
    }

    private fun nodesByText(root: AccessibilityNodeInfo, labels: Set<String>): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            val t = (n.text ?: n.contentDescription)?.toString()?.trim()?.lowercase()
            if (t != null && t in labels) out.add(n)
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return out
    }

    private fun closeTick() {
        if (System.currentTimeMillis() - closeStart > 12000) { endClose(); return }   // न हो पाए तो आगे बढ़ो
        val root = rootInActiveWindow
        if (root != null && root.packageName != packageName) {
            if (!closeClicked) {
                val n = nodesByText(root, forceLabels).firstOrNull()
                if (n != null) {
                    if (!n.isEnabled) { endClose(); return }        // बटन बंद = ऐप पहले से रुका / सिस्टम ऐप
                    if (clickNode(n)) { closeClicked = true }
                }
            } else {
                val ok = nodesByText(root, okLabels + forceLabels).firstOrNull { it.isEnabled }
                if (ok != null && clickNode(ok)) {
                    handler.removeCallbacks(tick)
                    handler.postDelayed({ if (closePkg != null) endClose() }, 800)
                    return
                }
            }
        }
        handler.postDelayed(tick, 700)
    }

    private fun finish() {
        missIdx = -1; missCnt = 0
        if (queue.isNotEmpty()) {
            if (!skippedThisApp) markDone(queue[qIndex])   // पूरा हुआ: अधूरी सूची से हटाओ
            skippedThisApp = false
        }
        if (qIndex + 1 < queue.size) {          // अगले ऐप पर वही कमांड
            val prev = queue[qIndex]
            qIndex++; index = 0
            closeThen(prev) {
                armReview()
                stepStart = System.currentTimeMillis() + 3000
                launchApp(queue[qIndex])
                updateBadge()
                handler.removeCallbacks(tick); handler.postDelayed(tick, 3000)
            }
            return
        }
        val left = failedList().distinct()
        if (autoRetry && left.isNotEmpty()) {
            // अधूरे ऐप अपने-आप फिर: जब तक घटते रहें; लगातार 2 राउंड में कुछ न घटे तो रुको
            noProgress = if (left.size < roundFailed) 0 else noProgress + 1
            if (noProgress < 2) {
                roundFailed = left.size
                round++
                val last = queue[qIndex]
                queue = left; qIndex = 0; index = 0
                closeThen(last) {
                    armReview()
                    stepStart = System.currentTimeMillis() + 3000
                    launchApp(queue[0])
                    updateBadge()
                    handler.removeCallbacks(tick); handler.postDelayed(tick, 3000)
                }
                return
            }
        }
        val msg = when {
            queue.isEmpty() -> "सारी कमांड पूरी ✔"
            left.isEmpty() -> "सारे ऐप पूरे ✔ (राउंड $round)"
            else -> "रुका: ${left.size} ऐप अधूरे रह गए"
        }
        val lastPkg = queue.getOrNull(qIndex)
        if (lastPkg != null) {
            // आख़िरी खुला ऐप भी बंद करो, फिर अपना ऐप भी बंद
            closeThen(lastPkg) {
                if (left.isEmpty() && runNextProject()) return@closeThen   // अगला प्रोजेक्ट
                toast(if (chainOn && left.isNotEmpty()) "$msg — अगला प्रोजेक्ट नहीं चलाया" else msg)
                chainOn = false
                stop()
                // अपना ऐप भी बंद करो और होम स्क्रीन पर आ जाओ (✔ अगली बार खोलने पर वहीं मिलेंगे)
                try { MainActivity.cur?.finishAndRemoveTask() } catch (e: Exception) {}
                Handler(Looper.getMainLooper()).postDelayed({
                    try { performGlobalAction(GLOBAL_ACTION_HOME) } catch (e: Exception) {}
                }, 500)
            }
            return
        }
        toast(msg)
        stop()
    }

    private fun clickNode(n: AccessibilityNodeInfo): Boolean {
        var x: AccessibilityNodeInfo? = n
        while (x != null && !x.isClickable) x = x.parent
        return x?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true
    }

    // पहले exact match, फिर contains (अंग्रेज़ी में बड़े-छोटे अक्षर का फ़र्क नहीं)
    private fun findNode(root: AccessibilityNodeInfo, target: String): AccessibilityNodeInfo? {
        val t = target.trim().lowercase()
        val all = ArrayList<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            all.add(n)
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        fun txt(n: AccessibilityNodeInfo) =
            (n.text ?: n.contentDescription)?.toString()?.trim()?.lowercase()
        // सिर्फ़ वही जो स्क्रीन पर सच में दिख रहा हो (छिपे/पिछली स्क्रीन के नोड पर झूठा क्लिक न हो)
        val vis = all.filter { it.isVisibleToUser }
        return vis.firstOrNull { txt(it) == t }
            ?: vis.firstOrNull { val s = txt(it); s != null && s.contains(t) }
    }

    // छोटा बैज: कौन सी कमांड चल रही है; टैप करने पर रुक जाएगा
    private fun showBadge() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        badge = TextView(this).apply {
            textSize = 14f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                cornerRadius = 40f; setColor(Color.parseColor("#CC C62828".replace(" ", "")))
            }
            setPadding(24, 12, 24, 12)
            setOnClickListener { toast("रोक दिया"); chainOn = false; stop() }
        }
        updateBadge()
        wm.addView(badge, WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; y = 120 })
    }

    private fun updateBadge() {
        val r = if (autoRetry) "राउंड $round · " else ""
        val pr = if (chainOn) "प्रोजेक्ट ${chainIdx + 1}/${chainNames.size} · " else ""
        val app = pr + r + (if (queue.size > 1) "ऐप ${qIndex + 1}/${queue.size} · " else "")
        val mi = if (matchInfoIdx == index && matchInfo.isNotEmpty()) "\n$matchInfo" else ""
        badge?.text = "⏹ $app" + "कमांड ${index + 1}/${steps.size}: ${prettyStep(steps[index])}" + mi
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() { stop(); instance = null; super.onDestroy() }
}

/** कमांड को सूची/बैज में दिखाने लायक नाम */
fun prettyStep(s: String): String = when {
    s.startsWith("SWIPE:") -> {
        val p = s.split(":", limit = 3)
        val d = when (p[1]) { "left" -> "⬅ बाएँ"; "right" -> "➡ दाएँ"; "up" -> "⬆ ऊपर"; else -> "⬇ नीचे" }
        val t = p.getOrElse(2) { "" }
        val where = when {
            t.isEmpty() -> "स्क्रीन के बीच से"
            t.startsWith("IMG:") -> "🖼 फोटो पर"
            else -> "\"$t\" पर"
        }
        "स्वाइप $d — $where"
    }
    s.startsWith("IMG:opt:") -> "🖼 फोटो (वैकल्पिक)"
    s.startsWith("IMG:req:") -> "🖼 फोटो (ज़रूरी)"
    else -> s
}
