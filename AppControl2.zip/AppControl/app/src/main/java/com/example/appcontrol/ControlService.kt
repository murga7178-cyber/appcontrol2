package com.example.appcontrol

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.content.Intent
import android.graphics.Color
import android.graphics.Path
import android.graphics.Rect
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.view.Display
import java.io.File
import java.util.concurrent.Executors
import kotlin.math.abs
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.TextView
import android.widget.Toast

class ControlService : AccessibilityService() {

    companion object { var instance: ControlService? = null }

    private val handler = Handler(Looper.getMainLooper())
    private var steps: List<String> = emptyList()
    private var index = 0
    private var gateOkIdx = -1   // जिस कमांड का स्क्रीनशॉट-मिलान पास हो चुका
    private var running = false
    private var badge: TextView? = null
    private var stepStart = 0L
    private var queue: List<String> = emptyList()
    private var qIndex = 0
    private var skippedThisApp = false
    // नंबर वाली कमांड: स्क्रॉल खोज और बार-बार चलाने की स्थिति
    private var numScrolled = false
    private var numFwd = true
    private var numEdges = 0
    private var numScrolls = 0
    private var numPrevSig = 0
    private var numLastScroll = 0L
    private var numCloseStage = 0     // 0 = बंद नहीं कर रहे; 1 = पहला बंद-टेक्स्ट; 2 = दूसरा बंद-टेक्स्ट
    private var numCloses = 0
    private var numCloseAt = 0L
    private val numRangeTapped = HashSet<String>()   // जिन रेंज-टैब (जैसे 51-100) पर इस कमांड में क्लिक हो चुका
    private var numPassClicks = 0
    private var numExhausted = false
    private var numAllowRed = false          // बिना कोशिश वाले नंबर नहीं मिले तो अब 🔴 वालों को लो
    private var altRot = 0            // एक कमांड की दूसरी (वैकल्पिक) कमांडों में अभी किसकी बारी
    private var altKeyCur = -1
    private var numLastNums: List<Int> = emptyList()   // पिछले राउंड में जो नंबर चले (Recents से हटाने के लिए)
    private val numCur = HashMap<String, Int>()     // इस राउंड में जिस नंबर पर क्लिक हुआ (राउंड पूरा होने पर ✅/🔴 तय होगा)
    private var autoRetry = false
    private var round = 1
    private var roundFailed = 0
    private var noProgress = 0
    private val bg = Executors.newSingleThreadExecutor()
    private var busy = false
    private var recheck = false
    private var reviewPending = false
    private var reviewWaiting = false
    private var skipReviewOnce = false
    private val tplCache = HashMap<String, Bitmap?>()
    // पिछला ऐप बंद करने की स्थिति
    private var closePkg: String? = null
    private var closeStart = 0L
    private var closeClicked = false
    private var afterClose: (() -> Unit)? = null
    // ऐप खुलने का इंतज़ार: पूरी तरह खुलने (स्क्रीन ठहरने) के बाद ही कमांड शुरू होंगी
    private var openPkg: String? = null
    private var openStart = 0L
    private var openSig = 0
    private var openStable = 0
    // एक ही टेक्स्ट कई जगह दिखे तो बारी-बारी क्लिक
    private var multiTried = 0
    private var holdUntil = 0L   // कमांड पर लगा टाइमर: इस समय तक रुको
    private var clickPending = false
    private var sigBefore = 0

    override fun onServiceConnected() { instance = this }

    // ---------- प्रोजेक्ट कतार: एक पूरा होते ही अगला (बीच में वाईफाई बंद-चालू) ----------
    private var chainOn = false
    private var chainNames: List<String> = emptyList()
    private var chainIdx = 0
    private var wifiOffByUs = false
    // कमांड छूटने पर नेटवर्क सुधार: हर कमांड पर सिर्फ़ एक बार (VPN हो तो VPN, वरना वाईफाई)
    private var netCycling = false
    private var netRetryKey = -1
    private var netStage = 0
    private var forceReview = false     // ऐप दोबारा खुला (सुधार के बाद): रिव्यू फोटो ज़रूर जाँचो
    private var reviewMissKey = -1
    private var reviewCheckedIdx = -1   // इस कमांड पर रिव्यू फोटो एक बार जाँची जा चुकी
    private var fewTries = 0           // राउंड 3+ में 1-2 ऐप बचने पर अतिरिक्त कोशिशें
    private var missedApps = 0          // लगातार कितने ऐप में कमांड छूटी


    private fun projData(n: String): Pair<List<String>, List<String>> {
        val sp = getSharedPreferences("apps", MODE_PRIVATE)
        fun l(k: String) = sp.getString(k, "")!!.split("\n").filter { it.isNotBlank() }
        return l("a_$n").distinct() to l("p_$n")
    }

    private fun nextValidProject(from: Int): Int {
        var k = from
        while (k < chainNames.size) {
            val (a, st) = projData(chainNames[k])
            if (a.isNotEmpty() && st.isNotEmpty()) return k
            toast("\"${chainNames[k]}\" में ऐप/कमांड नहीं — छोड़ा")
            k++
        }
        return -1
    }

    fun startChain(names: List<String>) {
        stop()
        chainNames = names; chainOn = true
        val k = nextValidProject(0)
        if (k < 0) { chainOn = false; toast("कोई प्रोजेक्ट चलाने लायक नहीं"); return }
        launchProject(k, false)
    }

    private fun launchProject(k: Int, cycleWifi: Boolean) {
        chainIdx = k
        val n = chainNames[k]
        ProjSettings.apply(getSharedPreferences("apps", MODE_PRIVATE), n)   // इस प्रोजेक्ट की अपनी सेटिंग (वीपीएन आदि)
        val (apps, st) = projData(n)
        val go = {
            getSharedPreferences("apps", MODE_PRIVATE).edit()
                .putString("cur", n).putString("steps", st.joinToString("\n"))
                .putString("pkgs", apps.joinToString("\n")).putString("failed", apps.joinToString("\n"))
                .putBoolean("ran", true).apply()
            startQueue(apps, st, true, false, true)
        }
        val sp = getSharedPreferences("apps", MODE_PRIVATE)
        val wantWifi = cycleWifi && sp.getBoolean("wifiCycle", true)
        val vpnPkg = sp.getString("vpnPkg", "")!!
        val wantVpn = cycleWifi && sp.getBoolean("vpnCycle", false) && vpnPkg.isNotEmpty()
        val vpnWasOn = onVpn()
        val fail = { why: String -> chainFail("$why — इसलिए प्रोजेक्ट रुका रह गया, अगला प्रोजेक्ट \"$n\" शुरू नहीं हुआ") }
        val afterWifi = { if (wantVpn) vpnCycle(n, vpnPkg, vpnWasOn, go, fail) else go() }
        if (wantWifi) wifiCycle(n, afterWifi, fail) else afterWifi()
    }

    /** वाईफाई की शर्त पूरी न हुई: कतार बंद, सब बंद, होम; ऐप खोलने पर कारण दिखेगा */
    private fun chainFail(msg: String) {
        getSharedPreferences("apps", MODE_PRIVATE).edit().putString("stopMsg", msg).apply()
        chainOn = false
        toast(msg)
        stop()
        try { MainActivity.cur?.finishAndRemoveTask() } catch (e: Exception) {}
        Handler(Looper.getMainLooper()).postDelayed({
            try { performGlobalAction(GLOBAL_ACTION_HOME) } catch (e: Exception) {}
        }, 500)
    }

    /** पूरे ऐप निपटने के बाद अगला प्रोजेक्ट; शुरू हुआ तो true */
    private fun runNextProject(): Boolean {
        if (!chainOn) return false
        val k = nextValidProject(chainIdx + 1)
        if (k < 0) { chainOn = false; return false }
        launchProject(k, true)
        return true
    }

    @Suppress("DEPRECATION")
    private fun onWifi(): Boolean {
        val cm = getSystemService(ConnectivityManager::class.java) ?: return false
        return cm.allNetworks.any { cm.getNetworkCapabilities(it)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true }
    }

    private fun wifiBadge(t: String) { badge?.text = "📶 $t" }

    @Suppress("DEPRECATION")
    private fun onVpn(): Boolean {
        val cm = getSystemService(ConnectivityManager::class.java) ?: return false
        return cm.allNetworks.any { cm.getNetworkCapabilities(it)?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true }
    }

    private fun vpnLines(key: String): List<String> =
        getSharedPreferences("apps", MODE_PRIVATE).getString(key, "")!!.split("\n").map { it.trim() }.filter { it.isNotEmpty() }

    /** वीपीएन ऐप खोलकर आपके लिखे स्टेप क्रम से टैप करो; कोई स्टेप 20 सेकंड में न मिले तो fail */
    private fun runVpnSteps(pkg: String, stepsL: List<String>, ok: () -> Unit, fail: (String) -> Unit) {
        val i = packageManager.getLaunchIntentForPackage(pkg)
        if (i == null) { fail("🔒 वीपीएन ऐप खुल नहीं पाया"); return }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
        var si = 0
        var tries = 0
        fun tap() {
            if (si >= stepsL.size) { ok(); return }
            val root = rootInActiveWindow
            // "IMG:फाइल" वाला स्टेप: स्क्रीनशॉट में फोटो खोजकर उसी जगह टैप करो
            if (stepsL[si].startsWith("IMG:")) {
                val tpl = loadTemplate(stepsL[si].removePrefix("IMG:").trim())
                if (tpl == null) { fail("🔒 वीपीएन की फोटो फाइल नहीं मिली"); return }
                val retry = {
                    if (tries >= 20) fail("🔒 वीपीएन में फोटो वाला बटन नहीं मिला (स्टेप ${si + 1})")
                    else { tries++; handler.postDelayed({ tap() }, 1000) }
                }
                if (root == null || root.packageName != pkg) { retry(); return }
                val onShot = { bmp: Bitmap? ->
                    val pos = if (bmp != null) match(bmp, tpl) else null
                    handler.post {
                        if (pos == null) retry()
                        else {
                            val path = Path().apply { moveTo(pos.first.toFloat(), pos.second.toFloat()) }
                            val g = GestureDescription.Builder()
                                .addStroke(GestureDescription.StrokeDescription(path, 0, 60)).build()
                            val sent = dispatchGesture(g, object : AccessibilityService.GestureResultCallback() {
                                override fun onCompleted(d: GestureDescription?) {
                                    badge?.text = "🔒 वीपीएन स्टेप ${si + 1}/${stepsL.size} ✔"
                                    si++; tries = 0
                                    handler.postDelayed({ tap() }, 1500)
                                }
                                override fun onCancelled(d: GestureDescription?) { retry() }
                            }, null)
                            if (!sent) retry()
                        }
                    }
                }
                if (Build.VERSION.SDK_INT >= 30) shotApi30 { onShot(it) }
                else {
                    val cs = CaptureService.instance
                    if (cs == null) { fail("🔒 मुख्य ऐप में 'स्क्रीन कैप्चर अनुमति' दें"); return }
                    bg.execute { onShot(cs.capture()) }
                }
                return
            }
            val node = if (root != null && root.packageName == pkg) findNode(root, stepsL[si]) else null
            if (node != null && clickNode(node)) {
                badge?.text = "🔒 वीपीएन स्टेप ${si + 1}/${stepsL.size} ✔"
                si++; tries = 0
                handler.postDelayed({ tap() }, 1500)
                return
            }
            if (tries >= 20) { fail("🔒 वीपीएन में \"${stepsL[si]}\" नहीं मिला"); return }
            tries++; handler.postDelayed({ tap() }, 1000)
        }
        handler.postDelayed({ tap() }, 2500)
    }

    /** वीपीएन जुड़ा था तो: आपके 'बंद' स्टेप (खाली हो तो Force stop) → डिस्कनेक्ट का इंतज़ार → 'चालू' स्टेप → जुड़ने का इंतज़ार (120 सेकंड) */
    private fun vpnCycle(next: String, pkg: String, wasOn: Boolean, go: () -> Unit, fail: (String) -> Unit) {
        if (!wasOn) { go(); return }                          // वीपीएन जुड़ा ही नहीं था
        badge?.text = "🔒 वीपीएन बंद हो रहा… (अगला: $next)"
        var t = 0
        fun waitOn() {
            if (onVpn()) {
                badge?.text = "🔒 वीपीएन जुड़ गया ✔"
                handler.postDelayed({ if (onVpn()) go() else waitOn() }, 3000)   // जुड़े रहने की दोबारा जाँच
                return
            }
            if (t >= 240) { fail("🔒 वीपीएन कनेक्ट नहीं हुआ (120 सेकंड इंतज़ार किया)"); return }
            t++; handler.postDelayed({ waitOn() }, 500)
        }
        fun connect() {
            badge?.text = "🔒 वीपीएन चालू हो रहा…"
            val onSteps = vpnLines("vpnOn")
            if (onSteps.isEmpty()) {                          // बिना स्टेप: ऐप खुलते ही खुद जुड़ेगा
                val i = packageManager.getLaunchIntentForPackage(pkg)
                if (i == null) { fail("🔒 वीपीएन ऐप खुल नहीं पाया"); return }
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i)
                t = 0; handler.postDelayed({ waitOn() }, 1000)
            } else runVpnSteps(pkg, onSteps, { t = 0; waitOn() }, fail)
        }
        fun waitOff() {
            if (!onVpn() || t >= 60) { handler.postDelayed({ connect() }, 3000); return }   // 30 सेकंड तक डिस्कनेक्ट का इंतज़ार
            t++; handler.postDelayed({ waitOff() }, 500)
        }
        val offSteps = vpnLines("vpnOff")
        if (offSteps.isEmpty()) {
            val ok = Shell.best("am force-stop $pkg") { }
            if (!ok) { fail("🔒 वीपीएन बंद नहीं कर पाए (बंद के स्टेप नहीं लिखे और Shizuku/Root भी जुड़ा नहीं)"); return }
            handler.postDelayed({ waitOff() }, 1000)
        } else runVpnSteps(pkg, offSteps, { t = 0; handler.postDelayed({ waitOff() }, 1000) }, fail)
    }

    /** वाईफाई से जुड़ा हो तो: बंद → डिस्कनेक्ट होने तक रुको → चालू → दोबारा जुड़ने तक रुको → फिर go() */
    private fun wifiCycle(next: String, go: () -> Unit, fail: (String) -> Unit) {
        if (!onWifi()) { go(); return }                       // वाईफाई से जुड़ा ही नहीं था
        wifiBadge("वाईफाई बंद हो रहा… (अगला: $next)")
        val ok = Shell.best("svc wifi disable") { }
        if (!ok) { fail("📶 वाईफाई बंद नहीं कर पाए (Shizuku/Root जुड़ा नहीं)"); return }
        wifiOffByUs = true
        var t = 0
        fun waitBack() {
            if (onWifi()) {
                wifiBadge("वाईफाई जुड़ गया ✔")
                handler.postDelayed({ if (onWifi()) go() else waitBack() }, 3000)   // जुड़े रहने की दोबारा जाँच
                return
            }
            if (t >= 240) { fail("📶 वाईफाई कनेक्ट नहीं हुआ (120 सेकंड इंतज़ार किया)"); return }
            t++; handler.postDelayed({ waitBack() }, 500)
        }
        fun enable() {
            wifiBadge("वाईफाई चालू हो रहा…")
            Shell.best("svc wifi enable") { }
            wifiOffByUs = false
            t = 0; handler.postDelayed({ waitBack() }, 1000)
        }
        fun waitOff() {
            if (!onWifi() || t >= 40) {                         // 20 सेकंड तक डिस्कनेक्ट का इंतज़ार
                handler.postDelayed({ enable() }, 3000)         // बंद अवस्था में 3 सेकंड रुको
                return
            }
            t++; handler.postDelayed({ waitOff() }, 500)
        }
        handler.postDelayed({ waitOff() }, 500)
    }

    /** वीपीएन जुड़ा होने पर भी कमांड फिर छूटी: वीपीएन बंद करो → नीचे वाले देश पर टैप (आपके स्टेप) → सूची थोड़ी खिसकाकर
     *  कोई दूसरा देश चुनो (क्लिक हुआ या नहीं, जाँचकर) → तभी वीपीएन चालू → जुड़ जाए तो आगे */
    private fun changeVpnCountry(pkg: String, resume: () -> Unit, fail: (String) -> Unit) {
        val sp = getSharedPreferences("apps", MODE_PRIVATE)
        val tapSteps = vpnLines("vpnCountry")
        val rnd = java.util.Random()
        badge?.text = "🌍 देश बदलने के लिए वीपीएन बंद हो रहा…"
        var curFail: (String) -> Unit = fail       // दोबारा चुनने के दौरान फेल हुआ तो प्रोजेक्ट नहीं रुकेगा, इंतज़ार चलता रहेगा
        var reselect: () -> Unit = {}
        var startFallbackFn: () -> Unit = {}
        var fallbackMode = false                    // नया देश नहीं जुड़ा: सूची से बाहर आकर सीधे 'कनेक्ट' (जो देश चुना हो उसी पर)
        var waitStart = 0L
        val maxWaitMs = 150_000L                    // कुल इंतज़ार (नए देश के लिए)
        val reselectEvery = 60                      // 60 पोल × 0.5 सेकंड = हर 30 सेकंड पर नया देश

        // ---- नया देश चुनने के बाद: वीपीएन चालू और जुड़ने का इंतज़ार ----
        fun afterPick() {
            if (waitStart == 0L) waitStart = System.currentTimeMillis()
            var el = 0
            var okRun = 0
            var stepsTried = false
            fun poll() {
                if (!running) return
                el++
                if (onVpn()) okRun++ else okRun = 0
                if (okRun >= 6 && el >= 8) {            // 3 सेकंड लगातार जुड़ा
                    badge?.text = "🔒 वीपीएन जुड़ गया ✔"
                    resume(); return
                }
                badge?.text = "🔒 नया देश जुड़ने का इंतज़ार… ${el / 2} सेकंड"
                if (el >= 12 && !stepsTried && !onVpn()) {      // 6 सेकंड में खुद न जुड़ा तो आपके 'चालू' स्टेप
                    stepsTried = true
                    val onSteps = vpnLines("vpnOn")
                    if (onSteps.isNotEmpty()) {
                        badge?.text = "🔒 वीपीएन चालू हो रहा…"
                        runVpnSteps(pkg, onSteps, { handler.postDelayed({ poll() }, 500) }, { _ -> handler.postDelayed({ poll() }, 500) })
                        return
                    }
                }
                if (System.currentTimeMillis() - waitStart >= maxWaitMs && !onVpn()) {
                    if (!fallbackMode && vpnLines("vpnOn").isNotEmpty()) { startFallbackFn(); return }   // नया देश नहीं जुड़ा: बाहर आकर कनेक्ट
                    fail("🔒 देश बदलने के बाद वीपीएन कनेक्ट नहीं हुआ (${maxWaitMs / 1000} सेकंड इंतज़ार किया)"); return
                }
                if (!fallbackMode && el >= reselectEvery && !onVpn()) {        // 30 सेकंड में नहीं जुड़ा: दोबारा नया देश चुनो
                    badge?.text = "🌍 30 सेकंड में नहीं जुड़ा — दूसरा देश चुन रहे हैं…"
                    reselect(); return
                }
                handler.postDelayed({ poll() }, 500)
            }
            handler.postDelayed({ poll() }, 500)
        }

        var tries = 0
        var scrollsLeft = -1
        var nameScrolls = 0; var nameSig = 0          // आपके लिखे देश के नाम खोजते समय सूची की स्क्रॉल (−1 = हार मानी, पुराना तरीका)
        var pickFn: () -> Unit = {}
        val junk = Regex("^[\\d.,%\\s]*(ms|mbps|kbps|gb|mb)?$", RegexOption.IGNORE_CASE)

        fun tapRect(r: Rect): Boolean {
            val path = Path().apply { moveTo(r.centerX().toFloat(), r.centerY().toFloat()) }
            val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 60)).build()
            return dispatchGesture(g, null, null)
        }
        // सूची को ऊपर की ओर स्वाइप (नीचे के देश दिखें); पूरा होने/न होने पर भी आगे बढ़ो
        fun swipeUp(done: () -> Unit) {
            val dm = resources.displayMetrics
            val x = dm.widthPixels / 2f
            val path = Path().apply { moveTo(x, dm.heightPixels * 0.72f); lineTo(x, dm.heightPixels * 0.38f) }
            val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 350)).build()
            val next = { handler.postDelayed({ done() }, 900); Unit }
            val ok = dispatchGesture(g, object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(d: GestureDescription?) { next() }
                override fun onCancelled(d: GestureDescription?) { next() }
            }, null)
            if (!ok) next()
        }

        // क्लिक करो, 1.5 सेकंड बाद जाँचो कि स्क्रीन बदली या नहीं; न बदली तो सीधा टैप; फिर भी न बदली तो अगला देश
        fun tryClick(order: List<Triple<Int, String, AccessibilityNodeInfo>>, idx: Int, tried: MutableList<String>) {
            if (!running) return
            if (idx >= order.size || idx >= 5) {
                if (++tries >= 4) curFail("🌍 दूसरे देश पर क्लिक नहीं हो पाया")
                else { scrollsLeft = -1; handler.postDelayed({ pickFn() }, 1000) }
                return
            }
            val c = order[idx]
            val rootNow = rootInActiveWindow
            val sigBefore = if (rootNow != null) screenSig(rootNow) else 0
            val r = Rect(); c.third.getBoundsInScreen(r)
            badge?.text = "🌍 चुन रहे हैं: ${c.second}"
            clickNode(c.third)
            fun moved(): Boolean {
                val rr = rootInActiveWindow
                return rr == null || rr.packageName != pkg || screenSig(rr) != sigBefore
            }
            fun chosen() {
                tried.add(c.second)
                sp.edit().putString("vpnTried", tried.takeLast(40).joinToString("\n")).apply()
                badge?.text = "🌍 नया देश: ${c.second}"
                afterPick()
            }
            handler.postDelayed({
                if (!running) return@postDelayed
                if (moved()) { chosen(); return@postDelayed }
                if (!r.isEmpty) tapRect(r)                       // क्लिक नहीं लगा: उसी जगह सीधा टैप
                handler.postDelayed({
                    if (!running) return@postDelayed
                    if (moved()) chosen() else tryClick(order, idx + 1, tried)
                }, 1500)
            }, 1500)
        }

        fun pick() {
            val root = rootInActiveWindow
            if (root == null || root.packageName != pkg) {
                if (++tries >= 15) curFail("🌍 देशों की सूची खुली नहीं") else handler.postDelayed({ pickFn() }, 1000)
                return
            }
            // ---- आपके लिखे देश के नाम (हू-ब-हू वही नाम): सूची में दिखे तो वही चुनो, न दिखे तो नीचे स्क्रॉल करके खोजो ----
            val wanted = vpnLines("vpnCountryNames").map { it.lowercase() }.toSet()
            if (wanted.isNotEmpty() && nameScrolls >= 0) {
                val ms = ArrayList<Triple<Int, String, AccessibilityNodeInfo>>()
                fun walkW(n: AccessibilityNodeInfo?) {
                    if (n == null) return
                    val txt = (n.text ?: n.contentDescription)?.toString()?.trim()
                    if (!txt.isNullOrEmpty() && n.isVisibleToUser && txt.lowercase() in wanted) {
                        val canClick = generateSequence(n) { it.parent }.any { it.isClickable }
                        val r = Rect(); n.getBoundsInScreen(r)
                        if (canClick && !r.isEmpty && ms.none { it.second == txt }) ms.add(Triple(r.top, txt, n))
                    }
                    for (k in 0 until n.childCount) walkW(n.getChild(k))
                }
                walkW(root)
                if (ms.isNotEmpty()) {
                    val tr = sp.getString("vpnTried", "")!!.split("\n").filter { it.isNotBlank() }
                    val fresh = ms.filter { it.second !in tr }
                    val pool = if (fresh.isNotEmpty()) fresh
                               else ms.filter { it.second != tr.lastOrNull() }.ifEmpty { ms }
                    val first = pool[rnd.nextInt(pool.size)]
                    tryClick(listOf(first) + ms.filter { it !== first }, 0, tr.toMutableList())
                    return
                }
                val sg = screenSig(root)
                if (nameScrolls in 1..20 && sg == nameSig) nameScrolls = -1          // सूची का अंत: आपके नाम नहीं मिले → पुराना (अपने-आप) तरीका
                else if (nameScrolls > 20) nameScrolls = -1
                else { nameSig = sg; nameScrolls++; badge?.text = "🌍 आपके लिखे देश खोज रहे हैं…"; swipeUp { pickFn() }; return }
            }
            // सूची को 0-3 बार स्क्रॉल (स्वाइप) करो, ताकि हर बार अलग देश सामने आएँ
            if (scrollsLeft < 0) scrollsLeft = rnd.nextInt(4)
            if (scrollsLeft > 0) {
                scrollsLeft--
                badge?.text = "🌍 सूची स्क्रॉल हो रही है…"
                swipeUp { pickFn() }
                return
            }
            val skipWords = setOf("back", "search", "connect", "disconnect", "cancel", "ok", "yes", "no")
            fun clickableOf(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
                var cur: AccessibilityNodeInfo? = n
                while (true) {
                    val c = cur ?: return null
                    if (c.isClickable) return c
                    cur = c.parent
                }
            }
            val cands = ArrayList<Triple<Int, String, AccessibilityNodeInfo>>()
            val seen = HashSet<String>()

            fun walk(n: AccessibilityNodeInfo?) {
                if (n == null) return
                val txt = (n.text ?: n.contentDescription)?.toString()?.trim()
                if (!txt.isNullOrEmpty() && txt.length in 3..40 && txt.lowercase() !in skipWords
                    && !junk.matches(txt) && !n.isEditable && seen.add(txt)) {
                    val c = clickableOf(n)
                    if (c != null && !n.isSelected && !n.isChecked && !c.isSelected && !c.isChecked) {
                        val r = Rect(); n.getBoundsInScreen(r)
                        if (!r.isEmpty) cands.add(Triple(r.top, txt, n))
                    }
                }
                for (k in 0 until n.childCount) walk(n.getChild(k))
            }
            walk(root)
            cands.sortBy { it.first }
            val tried = sp.getString("vpnTried", "")!!.split("\n").filter { it.isNotBlank() }.toMutableList()
            var list = cands.filter { it.second !in tried }
            if (list.isEmpty()) {                                       // सब आज़मा लिए: चक्कर फिर शुरू, पर आख़िरी चुना वाला नहीं
                val last = tried.lastOrNull()
                tried.clear(); if (last != null) tried.add(last)
                list = cands.filter { it.second != last }
            }
            if (list.isEmpty()) {
                if (++tries >= 15) curFail("🌍 सूची में कोई दूसरा देश नहीं मिला") else handler.postDelayed({ pickFn() }, 1000)
                return
            }
            val pool = if (list.size > 3) list.drop(1) else list        // सबसे ऊपर वाला अक्सर अभी का/सुझाया देश
            val first = pool[rnd.nextInt(pool.size)]
            tryClick(listOf(first) + pool.filter { it !== first }, 0, tried)
        }
        pickFn = { pick() }

        // ---- 1) वीपीएन बंद; 2) देश वाला स्टेप; 3) दूसरा देश चुनना ----
        var t = 0
        fun selectStage() {
            badge?.text = "🌍 नीचे वाले देश पर टैप…"
            runVpnSteps(pkg, tapSteps, { handler.postDelayed({ pickFn() }, 1500) }, { w -> curFail(w) })
        }
        fun waitOff() {
            if (!onVpn() || t >= 60) { handler.postDelayed({ selectStage() }, 2000); return }   // 30 सेकंड तक डिस्कनेक्ट का इंतज़ार
            t++; handler.postDelayed({ waitOff() }, 500)
        }
        fun beginOff() {
            val offSteps = vpnLines("vpnOff")
            if (offSteps.isEmpty()) {
                val ok = Shell.best("am force-stop $pkg") { }
                if (!ok) { curFail("🔒 वीपीएन बंद नहीं कर पाए (बंद के स्टेप नहीं लिखे और Shizuku/Root भी जुड़ा नहीं)"); return }
                handler.postDelayed({ waitOff() }, 1000)
            } else runVpnSteps(pkg, offSteps, { t = 0; handler.postDelayed({ waitOff() }, 1000) }, { w -> curFail(w) })
        }
        reselect = {
            // अभी वाला देश नहीं जुड़ा: VPN बंद → देश की सूची → दूसरा देश; फेल हुआ तो इंतज़ार चलता रहे
            t = 0; tries = 0; scrollsLeft = -1; nameScrolls = 0
            curFail = { _ -> handler.postDelayed({ if (running) afterPick() }, 500) }
            beginOff()
        }
        startFallbackFn = {
            fallbackMode = true; waitStart = 0L
            badge?.text = "🔙 नया देश नहीं जुड़ा — सूची से बाहर आकर सीधे कनेक्ट कर रहे हैं…"
            curFail = { w -> fail(w) }                  // अब असली फेल
            val onSteps = vpnLines("vpnOn")
            // सूची/स्क्रीन से बाहर: Back दो बार (हो सके तो ऐप भी बंद), फिर आपके 'चालू' स्टेप (कनेक्ट पर क्लिक)
            Shell.best("am force-stop $pkg") { }
            performGlobalAction(GLOBAL_ACTION_BACK)
            handler.postDelayed({
                performGlobalAction(GLOBAL_ACTION_BACK)
                handler.postDelayed({
                    if (!running) return@postDelayed
                    runVpnSteps(pkg, onSteps, { afterPick() }, { w -> fail(w) })
                }, 1000)
            }, 700)
        }
        beginOff()
    }

    /** ऐप पूरी तरह बंद: पहले Force stop (Shizuku/Root हो तो); न हो पाए तो Recents में ऊपर स्वाइप; फिर then() */
    private fun closeAppThen(pkg: String, then: () -> Unit) {
        if (pkg.startsWith("home:")) {                          // शॉर्टकट का पैकेज पता नहीं: बंद करना छोड़ो
            if (numRange() != null) closeNumCardsThen(false, then) else handler.postDelayed({ then() }, 500)
            return
        }
        val mode = getSharedPreferences("apps", MODE_PRIVATE).getInt("closeMode", 1)
        if (pkg in protectedPkgs()) {                           // सुरक्षित ऐप: कभी बंद नहीं
            if (numRange() != null) closeNumCardsThen(false, then) else handler.postDelayed({ then() }, 300)
            return
        }
        if (mode == 2) {                                        // Force stop: पहले चुपचाप (Shizuku/Root), न हो तो App info वाले रास्ते से
            val doIt = {
                badge?.text = "⛔ ऐप बंद हो रहा है…"
                if (Shell.best("am force-stop $pkg") { }) handler.postDelayed({ then() }, 1200)
                else closeViaSettings(pkg, then)
            }
            if (numRange() != null) closeNumCardsThen(false) { doIt() } else doIt()
            return
        }
        closeThen(pkg, then)                                    // 0 = बंद न करें, 1 = मिनिमाइज़ करके स्वाइप
    }

    /** कमांड नहीं मिली (वैकल्पिक नहीं): रिव्यू फोटो जाँच के बाद —
     *  1) ऐप Force stop (बंद) → 2) वीपीएन में जाओ: जुड़ा हो तो वीपीएन बंद + देश बदलकर फिर चालू (देश के स्टेप न हों तो बस बंद-चालू),
     *     सिर्फ़ वाईफाई हो तो वाईफाई बंद-चालू → 3) ऐप नए सिरे से खोलो, कमांड 1 से।
     *  हर कमांड पर वीपीएन वाला सुधार 2 बार तक, वाईफाई वाला 1 बार; उसके बाद पहले की तरह छोड़कर आगे। शुरू हुआ तो true */
    private fun recoverNetwork(): Boolean {
        val sp = getSharedPreferences("apps", MODE_PRIVATE)
        if (!sp.getBoolean("missCycle", true)) return false
        val key = qIndex * 1000 + index
        if (netRetryKey != key) { netRetryKey = key; netStage = 0 }
        val vpnPkg = sp.getString("vpnPkg", "")!!
        val vpnUp = onVpn() && vpnPkg.isNotEmpty()
        val label = "कमांड ${index + 1} दोबारा"
        val resume = {
            netCycling = false
            if (running) {
                val pkg = queue.getOrNull(qIndex)
                if (pkg != null) {
                    // ऐप पहले ही बंद है: नए सिरे से खोलो, कमांड 1 से चलेंगी
                    index = 0; gateOkIdx = -1; multiTried = 0; clickPending = false; holdUntil = 0L
                    forceReview = true            // ऐप दोबारा खुला: रिव्यू फोटो की जाँच
                    armReview()
                    stepStart = System.currentTimeMillis() + 3000
                    launchApp(pkg, false)
                    updateBadge()
                    handler.removeCallbacks(tick); handler.postDelayed(tick, 3000)
                } else {
                    stepStart = System.currentTimeMillis() + 2500
                    handler.removeCallbacks(tick); handler.postDelayed(tick, 2500)
                }
            }
        }
        val fail = { why: String ->
            netCycling = false
            if (chainOn) chainFail("$why — कमांड ${index + 1} पर रुका")
            else { toast("$why — कमांड ${index + 1} पर रुका"); stop() }
        }
        if (netStage >= 2) return false
        if (!vpnUp && !onWifi()) return false          // न VPN, न वाईफाई: कुछ करने को नहीं
        if (netStage == 1 && !vpnUp) return false      // वाईफाई वाला सुधार एक ही बार
        netStage++
        netCycling = true
        val flow = {
            if (vpnUp) {
                if (vpnLines("vpnCountry").isNotEmpty()) changeVpnCountry(vpnPkg, resume, fail)
                else vpnCycle(label, vpnPkg, true, resume, fail)
            } else wifiCycle(label, resume, fail)
        }
        val pkgNow = queue.getOrNull(qIndex)
        if (pkgNow != null) closeAppThen(pkgNow) { flow() } else flow()
        return true
    }

    /** सभी ऐप में बारी-बारी वही कमांड चलाओ */
    fun startQueue(pkgs: List<String>, list: List<String>, auto: Boolean = false, isRecheck: Boolean = false, chain: Boolean = false) {
        stop()
        if (!chain) chainOn = false
        if (pkgs.isEmpty() || list.isEmpty()) { toast("ऐप या कमांड नहीं जोड़ी"); return }
        queue = pkgs; qIndex = 0; steps = list; index = 0; gateOkIdx = -1; running = true
        autoRetry = auto; round = 1; noProgress = 0; fewTries = 0; recheck = isRecheck
        armReview()
        roundFailed = maxOf(failedList().size, pkgs.size)
        stepStart = System.currentTimeMillis() + 2500
        showBadge()
        launchApp(pkgs[0])
        handler.postDelayed(tick, 2500)
    }

    private fun reviewImgs(): List<String> =
        getSharedPreferences("apps", MODE_PRIVATE).getString("reviewImgs", "")!!
            .split("\n").filter { it.isNotBlank() }

    /** दोबारा चेक (राउंड 2+ या 'सिर्फ़ अधूरे') में हर ऐप पर पहले रिव्यू फोटो खोजो */
    private fun armReview() {
        reviewPending = (recheck || round >= 2 || forceReview) && reviewImgs().isNotEmpty()
        reviewWaiting = false; skipReviewOnce = false; reviewCheckedIdx = -1
    }

    /** दोबारा चेक में हर कमांड से पहले स्क्रीन पर रिव्यू फोटो देखो (किसी भी कमांड पर मिल सकती है) */
    private fun startReviewCheck() {
        val root = rootInActiveWindow
        if (root == null || root.packageName == packageName || System.currentTimeMillis() < stepStart - 1500) {
            skipReviewOnce = true; return        // ऐप अभी खुला नहीं: सामान्य कमांड-पास चलने दो
        }
        // सिर्फ़ इसी कमांड नंबर के लिए जोड़ी गई रिव्यू फोटो (नंबर 0 या बिना नंबर = हर कमांड पर)
        val tpls = reviewImgs().mapNotNull { line ->
            val n = line.substringBefore("|", "0").toIntOrNull() ?: 0
            if (n == 0 || n == index + 1) loadTemplate(line.substringAfter("|")) else null
        }
        reviewCheckedIdx = index                   // इस कमांड पर सिर्फ़ एक बार जाँच
        if (tpls.isEmpty()) { skipReviewOnce = true; return }
        if (Build.VERSION.SDK_INT >= 30) {
            busy = true
            shotApi30 { bmp -> finishReview(bmp, tpls) }
        } else {
            val cs = CaptureService.instance
            if (cs == null) { skipReviewOnce = true; return }
            busy = true
            bg.execute { finishReview(cs.capture(), tpls) }
        }
        reviewWaiting = true
    }

    private fun finishReview(bmp: Bitmap?, tpls: List<Bitmap>) {
        // रिव्यू फोटो हूबहू मिले तभी सफल (सख़्त मिलान; आम फोटो-कमांड से ज़्यादा सख़्त)
        val strict = getSharedPreferences("apps", MODE_PRIVATE).getInt("reviewColor", 12).toDouble()
        val found = bmp != null && tpls.any { matchReview(bmp, it, strict) }
        handler.post {
            busy = false; reviewWaiting = false
            if (!running || !reviewPending) return@post
            if (found) {
                reviewPending = false             // रिव्यू फोटो मिली: सही मानो, ✔ लगाओ, आगे बढ़ो
                skippedThisApp = false
                index = 0; gateOkIdx = -1
                finish()
            } else {
                skipReviewOnce = true             
                handler.removeCallbacks(tick); handler.post(tick)
            }
        }
    }

    private fun failedList(): List<String> =
        getSharedPreferences("apps", MODE_PRIVATE).getString("failed", "")!!
            .split("\n").filter { it.isNotBlank() }

    private fun markDone(pkg: String) {
        val l = failedList().filter { it != pkg }
        getSharedPreferences("apps", MODE_PRIVATE).edit()
            .putString("failed", l.joinToString("\n")).apply()
    }

    private fun launchApp(pkg: String, fresh: Boolean = true) {
        if (fresh) { numExhausted = false; numPassClicks = 0; numAllowRed = false }
        if (pkg.startsWith("home:")) {              // होम स्क्रीन का शॉर्टकट: होम पर जाकर उसी नाम के आइकन पर टैप
            if (fresh) { netRetryKey = -1; reviewMissKey = -1 }
            openPkg = pkg; openStart = System.currentTimeMillis(); openSig = 0; openStable = 0; holdUntil = 0L
            multiTried = 0; clickPending = false
            launchHome(pkg.removePrefix("home:"))
            return
        }
        val i = packageManager.getLaunchIntentForPackage(pkg) ?: return
        if (fresh) { netRetryKey = -1; reviewMissKey = -1 }
        openPkg = pkg; openStart = System.currentTimeMillis(); openSig = 0; openStable = 0; holdUntil = 0L
        multiTried = 0; clickPending = false
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val spB = getSharedPreferences("apps", MODE_PRIVATE)
        if (spB.getBoolean("boostBefore", true)) {
            // "बंद न करें" मोड: + से जुड़े सारे ऐप बूस्ट (force-stop) से भी बचे रहेंगे
            val keepSet = HashSet<String>().apply { add(pkg) }
            if (spB.getInt("closeMode", 1) == 0) queue.filter { !it.startsWith("home:") }.forEach { keepSet.add(it) }
            Shell.boost(this, keepSet) { startActivity(i) }
        } else startActivity(i)
    }


    // ---------- होम स्क्रीन के आइकन / शॉर्टकट (क्रोम शॉर्टकट, क्लोन आदि) ----------
    private fun homeSwipe(done: () -> Unit) {
        val dm = resources.displayMetrics
        val y = dm.heightPixels * 0.40f
        val path = Path().apply { moveTo(dm.widthPixels * 0.88f, y); lineTo(dm.widthPixels * 0.12f, y) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 300)).build()
        val next = { handler.postDelayed({ done() }, 800); Unit }
        val ok = dispatchGesture(g, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { next() }
            override fun onCancelled(d: GestureDescription?) { next() }
        }, null)
        if (!ok) next()
    }

    /** होम स्क्रीन के सारे पेज देखकर आइकन के नाम लौटाओ */
    fun scanHome(cb: (List<String>) -> Unit) {
        val found = LinkedHashSet<String>()
        val dm = resources.displayMetrics
        var page = 0
        var lastSig = 0
        fun collect(r: AccessibilityNodeInfo) {
            fun walk(n: AccessibilityNodeInfo?) {
                if (n == null) return
                val t = (n.text ?: n.contentDescription)?.toString()?.trim()
                if (!t.isNullOrEmpty() && t.length <= 40 && n.isVisibleToUser) {
                    var x: AccessibilityNodeInfo? = n
                    while (x != null && !x.isClickable && !x.isLongClickable) x = x.parent
                    if (x != null) {
                        val b = Rect(); x.getBoundsInScreen(b)
                        if (b.width() < dm.widthPixels * 0.5 && b.height() < dm.heightPixels * 0.25) found.add(t)
                    }
                }
                for (i in 0 until n.childCount) walk(n.getChild(i))
            }
            walk(r)
        }
        fun finish() {
            performGlobalAction(GLOBAL_ACTION_HOME)
            handler.postDelayed({
                try {
                    startActivity(Intent(this, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP))
                } catch (e: Exception) { }
                handler.postDelayed({ cb(found.toList().sortedBy { it.lowercase() }) }, 900)
            }, 700)
        }
        fun step() {
            val r = rootInActiveWindow
            if (r == null || r.packageName == packageName) { finish(); return }
            collect(r)
            val sg = screenSig(r)
            if (page > 0 && sg == lastSig) { finish(); return }
            lastSig = sg
            if (++page >= 8) { finish(); return }
            homeSwipe { step() }
        }
        performGlobalAction(GLOBAL_ACTION_HOME)
        handler.postDelayed({ performGlobalAction(GLOBAL_ACTION_HOME); handler.postDelayed({ step() }, 900) }, 900)
    }

    /** होम स्क्रीन पर उसी नाम का आइकन खोजकर टैप (ज़रूरत हो तो पेज स्वाइप करके) */
    fun launchHome(name: String) {
        var page = 0
        fun attempt() {
            val r = rootInActiveWindow
            if (r != null && r.packageName != packageName) {
                val n = findNodes(r, name).firstOrNull()
                if (n != null && clickNode(n)) return
            }
            if (++page > 8) { toast("होम स्क्रीन पर \"$name\" नहीं मिला"); return }
            homeSwipe { attempt() }
        }
        performGlobalAction(GLOBAL_ACTION_HOME)
        handler.postDelayed({ performGlobalAction(GLOBAL_ACTION_HOME); handler.postDelayed({ attempt() }, 900) }, 900)
    }

    /** कमांड 1, 2, 3... क्रम से चलाना शुरू */
    fun startSequence(list: List<String>) {
        stop(); chainOn = false
        if (list.isEmpty()) { toast("कोई कमांड नहीं जोड़ी"); return }
        steps = list; index = 0; gateOkIdx = -1; running = true
        numExhausted = false; numPassClicks = 0
        stepStart = System.currentTimeMillis() + 1500
        showBadge()
        handler.postDelayed(tick, 1500) // ऐप खुलने का इंतज़ार
    }

    private fun stop() {
        if (wifiOffByUs) { wifiOffByUs = false; Shell.best("svc wifi enable") { } }   // रोकने पर वाईफाई बंद न रह जाए
        running = false; holdUntil = 0L; netCycling = false; forceReview = false
        closePkg = null; afterClose = null; reviewPending = false; reviewWaiting = false; skipReviewOnce = false; recheck = false
        numCur.clear(); queue = emptyList(); qIndex = 0; skippedThisApp = false; autoRetry = false; missedApps = 0
        handler.removeCallbacksAndMessages(null)
        badge?.let { try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } catch (e: Exception) {} }
        badge = null
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            if (netCycling) { handler.postDelayed(this, 500); return }
            if (closePkg == "recents") { handler.postDelayed(this, 700); return }
            if (closePkg != null) { closeTick(); return }
            // नया ऐप खोला है तो पहले अच्छे से खुलने दो (कम से कम 3 सेकंड, स्क्रीन ठहरने तक, अधिकतम 15 सेकंड)
            val op = openPkg
            if (op != null) {
                val el = System.currentTimeMillis() - openStart
                val r = rootInActiveWindow
                val inApp = r != null && (r.packageName == op || (el > 6000 && r.packageName != packageName))
                if (inApp) {
                    val sg = screenSig(r!!)
                    if (sg == openSig) openStable++ else { openStable = 0; openSig = sg }
                }
                if (el < 15000 && !(inApp && el >= 2500 && openStable >= 2)) {
                    handler.postDelayed(this, 250); return
                }
                openPkg = null
                stepStart = System.currentTimeMillis()
            }
            // पिछली कमांड पर टाइमर लगा था तो उतनी देर रुको
            if (System.currentTimeMillis() < holdUntil) { handler.postDelayed(this, 200); return }
            if (reviewPending) {
                if (reviewWaiting) { handler.postDelayed(this, 500); return }
                if (!busy) {
                    if (skipReviewOnce) skipReviewOnce = false
                    else if (reviewCheckedIdx != index) { startReviewCheck(); if (reviewWaiting) return }
                }
            }
            val rawFull = stripLimit(steps[index])
            val perLim = stepLimit(steps[index])        // इस कमांड का अपना खोजने का समय (सेकंड); 0 = सामान्य सेटिंग
            val raw = if (rawFull.contains("~~")) rawFull.substringBeforeLast("~~") else rawFull
            // स्क्रीनशॉट वाली कमांड का रूप:  GATE:<फाइल>:<असली कमांड>  (स्क्रीन मिले तभी असली कमांड चलेगी)
            val gateFile: String? = if (raw.startsWith("GATE:")) raw.removePrefix("GATE:").substringBefore(":") else null
            val cmdFull = if (gateFile != null) raw.removePrefix("GATE:").substringAfter(":") else raw
            // एक कमांड में दूसरी (वैकल्पिक) कमांड:  पहली|ALT|दूसरी|ALT|तीसरी — पहली न मिले तो बारी-बारी से दूसरी भी खोजो
            val altKey = qIndex * 1000 + index
            if (altKey != altKeyCur) { altKeyCur = altKey; altRot = 0 }
            val variants = cmdFull.split("|ALT|")
            val mainCmd = variants[0]
            val cmd = variants[Math.floorMod(altRot, variants.size)]
            // स्वाइप कमांड का रूप:  SWIPE:<left|right|up|down>:<टेक्स्ट या IMG:req:फाइल या खाली>
            val parts = cmd.split(":", limit = 3)
            val swipeDir: String? = if (cmd.startsWith("SWIPE:")) parts[1] else null
            val target = if (swipeDir != null) parts.getOrElse(2) { "" } else cmd
            val isImg = target.startsWith("IMG:")
            val mainSwipe = mainCmd.startsWith("SWIPE:")
            val mainTarget = if (mainSwipe) mainCmd.split(":", limit = 3).getOrElse(2) { "" } else mainCmd
            val optional = (!mainSwipe && isCross(mainCmd)) || mainTarget.startsWith("IMG:opt:")
            // वैकल्पिक कमांड ~4 सेकंड में न मिले तो आगे बढ़ जाओ
            val secs = getSharedPreferences("apps", MODE_PRIVATE).getInt("limit", 8)
            val limit = if (perLim > 0) perLim * 1000 else if (optional) minOf(secs, 4) * 1000 else secs * 1000
            if (!busy && System.currentTimeMillis() - stepStart > limit) {
                // नंबर वाली कमांड में नंबर समय में नहीं मिला: छोड़ो + दो बार बैक + कमांड शुरू से (सीधे अगली कमांड/मिनिमाइज़ नहीं)
                if (numParse(cmd) != null && numCloseOn(cmd) && numCloses < 5) {
                    numNotFoundRestart(cmd)
                    handler.postDelayed(this, 800); return
                }
                // कमांड छूटी: नेटवर्क सुधार से पहले एक बार रिव्यू फोटो जाँचो (मिल गई = काम हो चुका)
                val rk = qIndex * 1000 + index
                val hasReviewHere = reviewImgs().any { line ->
                    val n = line.substringBefore("|", "0").toIntOrNull() ?: 0
                    n == 0 || n == index + 1
                }
                if (!optional && hasReviewHere && reviewMissKey != rk) {
                    reviewMissKey = rk
                    forceReview = true; reviewPending = true; reviewWaiting = false; skipReviewOnce = false
                    reviewCheckedIdx = -1
                    badge?.text = "✅ रिव्यू फोटो जाँच रहे हैं…"
                    stepStart = System.currentTimeMillis() - limit + 3000
                    handler.postDelayed(this, 250); return
                }
                // (बदलाव) कमांड छूटने पर अब हर बार वाईफाई/VPN नहीं बदलता: सिर्फ़ छोड़कर आगे बढ़ता है।
                // वाईफाई/VPN सुधार तब होगा जब लगातार ~3 ऐप में कमांड छूटें (देखो netFixThen)
                if (!optional) skippedThisApp = true
                numMarkMiss(cmd)        // नंबर वाली कमांड में नंबर नहीं मिला = उसकी कोशिश गिनो (3 बार में छोड़ दिया जाएगा), फिर अगली कमांड
                if (!advance(false)) return
                handler.postDelayed(this, 250); return
            }
            // स्क्रीनशॉट से मिलान: जब तक खुली स्क्रीन स्क्रीनशॉट जैसी न हो, कमांड नहीं चलेगी
            if (gateFile != null && gateOkIdx != index) {
                val r0 = rootInActiveWindow
                if (!busy && r0 != null && r0.packageName != packageName) checkGate(gateFile, index)
                handler.postDelayed(this, 350); return
            }
            val root = rootInActiveWindow
            // हमारे अपने ऐप की स्क्रीन पर नहीं खोजना
            if (root != null && root.packageName != packageName) {
                if (isImg) {
                    if (!busy) findAndTapImage(target, swipeDir)
                    handler.postDelayed(this, 500); return
                }
                if (swipeDir != null) {
                    // टेक्स्ट मिल जाए तो उसी जगह से स्वाइप (क्लिक नहीं); खाली हो तो स्क्रीन के बीच से
                    if (!busy) {
                        if (target.isEmpty()) {
                            val dm = resources.displayMetrics
                            swipeAt(dm.widthPixels / 2, dm.heightPixels / 2, swipeDir, index)
                        } else {
                            val node = findNode(root, target)
                            if (node != null) {
                                val r = Rect(); node.getBoundsInScreen(r)
                                if (!r.isEmpty) swipeAt(r.centerX(), r.centerY(), swipeDir, index)
                            }
                        }
                    }
                    handler.postDelayed(this, 250); return
                }
                if (isCross(cmd)) {
                    val node = findCross(root)
                    if (node != null && clickNode(node)) {
                        if (!advance()) return
                        handler.postDelayed(this, 450) // अगली स्क्रीन का इंतज़ार
                        return
                    }
                    if (!busy) findAndTapCross(root)     // नाम वाला क्रॉस न मिले तो स्क्रीन पर गुणा (×) जैसा चित्र खोजकर टैप
                } else if (numParse(cmd) != null) {
                    // नंबर वाली कमांड: स्क्रीन पर दिखे "टेक्स्ट <नंबर>" में से सबसे छोटा नंबर जो अभी हुआ नहीं, उसी पर क्लिक;
                    // कोई न दिखे तो सूची स्क्रॉल करके खोजो (ऊपर-नीचे दोनों ओर)
                    val (lo, hi, base) = numParse(cmd)!!
                    val sp = getSharedPreferences("apps", MODE_PRIVATE)
                    val key = numKey(cmd)
                    val done = numDone(sp, key)
                    val failed = numFailed(sp, numFailKey(cmd))
                    val total = hi - lo + 1
                    val exh = failed.count { it.value >= 3 && it.key !in done }
                    if (done.count { it in lo..hi } + exh >= total) {   // सारे नंबर पूरे (या 3 बार कोशिश के बाद छोड़े)
                        if (numGiveUp(true)) handler.postDelayed(this, 450)
                        return
                    }
                    val untried = total - done.count { it in lo..hi } - failed.count { it.key !in done && it.key in lo..hi }
                    val wantRed = untried <= 0 || numAllowRed          // पहले राउंड में सारे नंबर; 🔴 वाले दूसरे राउंड में
                    val candAll = findNumbered(root, base, lo, hi, done, failed)
                    val cand = if (wantRed) candAll else candAll.filter { !failed.containsKey(it.first) }
                    if (!busy) {
                        if (cand.isNotEmpty()) {
                            val (num, node) = cand[0]
                            if (clickNode(node)) {
                                numCur[cmd] = num; numPassClicks++; numCloses = 0
                                toast("$base $num …")
                                if (!advance()) return
                                handler.postDelayed(this, 450); return
                            }
                        } else {
                            val now = System.currentTimeMillis()
                            val backOn = numCloseOn(cmd)     // नंबर न मिलने पर आपके लिखे टेक्स्ट पर क्लिक (खाली = बंद)
                            // स्क्रॉल से पहले: जो नंबर चाहिए (सबसे छोटा बचा हुआ) उसकी रेंज वाला टैब (जैसे \"51-100\") सीधे खोजकर क्लिक
                            val target = (lo..hi).firstOrNull { it !in done && !failed.containsKey(it) }
                                ?: (lo..hi).firstOrNull { it !in done && (failed[it] ?: 0) < 3 }
                            if (target != null && now - numLastScroll >= 900) {
                                val tab = findRangeTab(root, target)
                                if (tab != null) {
                                    val tabKey = "$target|" + (tab.text ?: tab.contentDescription)?.toString()?.trim()
                                    if (numRangeTapped.add(tabKey) && clickNode(tab)) {
                                        toast("रेंज टैब → $base $target")
                                        numLastScroll = now + 600     // टैब की सूची खुलने का इंतज़ार, फिर ही स्क्रॉल
                                        stepStart = now
                                        handler.postDelayed(this, 700); return
                                    }
                                }
                            }
                            if (now - numLastScroll >= 1100) {
                                val sg = screenSig(root)
                                if (numScrolled && sg == numPrevSig) {        // स्क्रॉल से कुछ बदला नहीं = सूची का किनारा
                                    // खुली सूची पूरी देख ली, नंबर नहीं मिला और उसकी रेंज का टैब भी नहीं दिख रहा → यह कॉपी है ही नहीं:
                                    // हमेशा के लिए छोड़ो, दो बार बैक दबाओ, और इसी ऐप की सारी कमांड शुरू से चलाओ (अगली कॉपी से)
                                    if (backOn && numCloses < 5 && (target == null || findRangeTab(root, target) == null)) {
                                        numNotFoundRestart(cmd)
                                        handler.postDelayed(this, 800); return
                                    }
                                    numEdges++
                                    if (numEdges >= 2 || numScrolls > 60) {
                                        if (!wantRed && failed.any { it.value < 3 && it.key !in done }) {
                                            // बिना कोशिश वाले नंबर कहीं नहीं मिले → अब 🔴 वालों को दोबारा
                                            numAllowRed = true; numEdges = 0; numScrolled = false; numScrolls = 0; numFwd = true
                                            handler.postDelayed(this, 250); return
                                        }
                                        if (numGiveUp(done.isNotEmpty() || numPassClicks > 0)) handler.postDelayed(this, 450)
                                        return
                                    }
                                    numFwd = !numFwd
                                }
                                numPrevSig = sg; numScrolled = true; numLastScroll = now; numScrolls++
                                numScroll(root, numFwd)
                                // (बदलाव) यहाँ stepStart नहीं बदलता: नंबर न मिले तो कमांड का समय खत्म होते ही अगली कमांड पर चले जाओ
                            }
                        }
                    }
                } else {
                    // पिछले क्लिक के बाद स्क्रीन बदल गई = काम हो गया, अगली कमांड पर चलो
                    if (clickPending) {
                        clickPending = false
                        if (screenSig(root) != sigBefore) {
                            if (!advance()) return
                            handler.postDelayed(this, 450); return
                        }
                    }
                    val nodes = findNodes(root, cmd).ifEmpty { findByHint(root, cmd) }   // टेक्स्ट न मिले तो आइकन/चित्र के नाम (description / ID) से
                    if (nodes.isNotEmpty()) {
                        if (nodes.size == 1 && multiTried == 0) {
                            if (clickNode(nodes[0])) {
                                if (!advance()) return
                                handler.postDelayed(this, 450); return
                            }
                        } else {
                            if (multiTried >= nodes.size) {   // सब जगह क्लिक हो चुका
                                if (!advance()) return
                                handler.postDelayed(this, 450); return
                            }
                            val n = nodes[multiTried]; multiTried++
                            sigBefore = screenSig(root)
                            if (clickNode(n)) { clickPending = true; handler.postDelayed(this, 800); return }
                        }
                    }
                }
            }
            if (variants.size > 1 && !busy) altRot++      // यह कमांड नहीं मिली: अगली बार दूसरी कमांड आज़माओ
            handler.postDelayed(this, 250) // मिला नहीं तो खोजते रहो
        }
    }

    // ---------- स्क्रीनशॉट से स्क्रीन का मिलान ----------
    private fun checkGate(file: String, my: Int) {
        val ref = loadTemplate(file)
        if (ref == null) { toast("स्क्रीनशॉट फाइल नहीं मिली"); return }
        if (Build.VERSION.SDK_INT >= 30) {
            busy = true
            shotApi30 { bmp -> finishGate(bmp, ref, my) }
        } else {
            val cs = CaptureService.instance
            if (cs == null) {
                if (System.currentTimeMillis() % 5 == 0L) toast("मुख्य ऐप में 'स्क्रीन कैप्चर अनुमति' दें")
                return
            }
            busy = true
            bg.execute { finishGate(cs.capture(), ref, my) }
        }
    }

    private fun finishGate(bmp: Bitmap?, ref: Bitmap, my: Int) {
        val ok = bmp != null && sameScreen(bmp, ref)
        handler.post {
            busy = false
            if (running && index == my && ok) gateOkIdx = my
        }
    }

    /** पूरी स्क्रीन की तुलना (स्टेटस बार/नेव बार छोड़कर). थोड़ा फ़र्क चलता है; मिलान % सेटिंग में बदल सकते हैं */
    private fun sameScreen(scr: Bitmap, ref: Bitmap): Boolean {
        val w = 54; val h = 96
        val a = gray(Bitmap.createScaledBitmap(scr, w, h, true), w, h)
        val b = gray(Bitmap.createScaledBitmap(ref, w, h, true), w, h)
        val y0 = (h * 0.06).toInt(); val y1 = h - (h * 0.06).toInt()
        var same = 0; var tot = 0
        for (y in y0 until y1) for (x in 0 until w) {
            tot++
            if (abs(a[y * w + x] - b[y * w + x]) <= 28) same++
        }
        val need = getSharedPreferences("apps", MODE_PRIVATE).getInt("gatePct", 90)
        return tot > 0 && same * 100 >= need * tot
    }

    // ---------- फोटो से खोजना ----------
    private fun loadTemplate(name: String): Bitmap? = tplCache.getOrPut(name) {
        BitmapFactory.decodeFile(File(filesDir, name).path)
    }

    private fun findAndTapImage(cmd: String, dir: String? = null) {
        val tpl = loadTemplate(cmd.substringAfterLast(":")) ?: return
        val my = index
        if (Build.VERSION.SDK_INT >= 30) {
            busy = true
            shotApi30 { bmp -> finishMatch(bmp, tpl, my, dir) }
        } else {
            val cs = CaptureService.instance
            if (cs == null) {
                if (System.currentTimeMillis() % 5 == 0L) toast("मुख्य ऐप में 'स्क्रीन कैप्चर अनुमति' दें")
                return
            }
            busy = true
            bg.execute { finishMatch(cs.capture(), tpl, my, dir) }
        }
    }

    @android.annotation.TargetApi(30)
    private fun shotApi30(done: (Bitmap?) -> Unit) {
        takeScreenshot(Display.DEFAULT_DISPLAY, bg, object : AccessibilityService.TakeScreenshotCallback {
            override fun onSuccess(r: AccessibilityService.ScreenshotResult) {
                val hb = r.hardwareBuffer
                val bmp = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)?.copy(Bitmap.Config.ARGB_8888, false)
                hb.close()
                done(bmp)
            }
            override fun onFailure(code: Int) { done(null) }
        })
    }

    /** (bg थ्रेड पर) मिलान करो, फिर मुख्य थ्रेड पर टैप (dir खाली) या स्वाइप */
    private fun finishMatch(bmp: Bitmap?, tpl: Bitmap, my: Int, dir: String?) {
        val pos = if (bmp != null) match(bmp, tpl) else null
        handler.post {
            if (!running || index != my || pos == null) {
                busy = false
                if (running && index == my && pos == null) altRot++      // फोटो नहीं मिली: दूसरी कमांड की बारी
                return@post
            }
            if (dir == null) {
                val path = Path().apply { moveTo(pos.first.toFloat(), pos.second.toFloat()) }
                runGesture(path, 60, my)
            } else swipeAt(pos.first, pos.second, dir, my)
        }
    }

    /** (cx, cy) के आसपास उंगली से स्वाइप. left = उंगली दाएँ से बाएँ चलेगी */
    private fun swipeAt(cx: Int, cy: Int, dir: String, my: Int) {
        val dm = resources.displayMetrics
        val w = dm.widthPixels; val h = dm.heightPixels
        val hx = (w * 0.30f).toInt(); val hy = (h * 0.20f).toInt()
        fun cx_(v: Int) = v.coerceIn(20, w - 20)
        fun cy_(v: Int) = v.coerceIn(20, h - 20)
        val (sx, sy, ex, ey) = when (dir) {
            "left" -> listOf(cx + hx, cy, cx - hx, cy)
            "right" -> listOf(cx - hx, cy, cx + hx, cy)
            "up" -> listOf(cx, cy + hy, cx, cy - hy)
            else -> listOf(cx, cy - hy, cx, cy + hy)   // down
        }
        val path = Path().apply {
            moveTo(cx_(sx).toFloat(), cy_(sy).toFloat())
            lineTo(cx_(ex).toFloat(), cy_(ey).toFloat())
        }
        runGesture(path, 350, my)
    }

    private fun runGesture(path: Path, dur: Long, my: Int) {
        busy = true
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, dur)).build()
        val ok = dispatchGesture(g, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) {
                busy = false
                if (running && index == my && advance()) {
                    handler.removeCallbacks(tick); handler.postDelayed(tick, 450)
                }
            }
            override fun onCancelled(d: GestureDescription?) { busy = false }
        }, null)
        if (!ok) busy = false
    }

    private fun gray(b: Bitmap, w: Int, h: Int): IntArray {
        val px = IntArray(w * h)
        b.getPixels(px, 0, w, 0, 0, w, h)
        for (i in px.indices) {
            val c = px[i]
            px[i] = (((c shr 16) and 255) * 3 + ((c shr 8) and 255) * 6 + (c and 255)) / 10
        }
        return px
    }

    /** रिव्यू फोटो का रंग समेत मिलान: पहले जगह ढूँढो (ग्रे, ढीला), फिर उसी जगह का रंग (R,G,B) हूबहू देखो.
     *  हल्का लाल बनाम बिना रंग वाला (एक ही लिखावट) अलग माना जाएगा */
    private fun matchReview(scr: Bitmap, tpl: Bitmap, maxDiff: Double): Boolean {
        if (tpl.width > scr.width || tpl.height > scr.height) return false
        val pos = match(scr, tpl, 45.0) ?: return false
        val x0 = (pos.first - tpl.width / 2).coerceIn(0, scr.width - tpl.width)
        val y0 = (pos.second - tpl.height / 2).coerceIn(0, scr.height - tpl.height)
        val crop = Bitmap.createBitmap(scr, x0, y0, tpl.width, tpl.height)
        val w = 48
        val h = (48f * tpl.height / tpl.width).toInt().coerceIn(8, 96)
        val a = Bitmap.createScaledBitmap(crop, w, h, true)
        val b = Bitmap.createScaledBitmap(tpl, w, h, true)
        var sum = 0L
        for (y in 0 until h) for (x in 0 until w) {
            val pa = a.getPixel(x, y); val pb = b.getPixel(x, y)
            sum += abs(((pa shr 16) and 0xFF) - ((pb shr 16) and 0xFF)) +
                   abs(((pa shr 8) and 0xFF) - ((pb shr 8) and 0xFF)) +
                   abs((pa and 0xFF) - (pb and 0xFF))
        }
        return sum / (w * h * 3.0) < maxDiff
    }

    /** स्क्रीनशॉट में फोटो की सबसे मिलती जगह (केंद्र x, y) या null */
    private fun match(scr: Bitmap, tpl: Bitmap, maxAvg: Double = 15.0): Pair<Int, Int>? {
        val f = 2                       // तेज़ी के लिए आधा आकार
        val sw = scr.width / f; val sh = scr.height / f
        val tw = tpl.width / f; val th = tpl.height / f
        if (tw < 4 || th < 4 || tw > sw || th > sh) return null
        val S = gray(Bitmap.createScaledBitmap(scr, sw, sh, true), sw, sh)
        val T = gray(Bitmap.createScaledBitmap(tpl, tw, th, true), tw, th)
        var best = Long.MAX_VALUE; var bx = -1; var by = -1
        var y = 0
        while (y <= sh - th) {
            var x = 0
            while (x <= sw - tw) {
                var sum = 0L
                for (ty in 0 until th) {
                    val so = (y + ty) * sw + x; val to = ty * tw
                    for (tx in 0 until tw) sum += abs(S[so + tx] - T[to + tx])
                    if (sum >= best) break
                }
                if (sum < best) { best = sum; bx = x; by = y }
                x += 2
            }
            y += 2
        }
        val avg = best.toDouble() / (tw * th)
        return if (avg < maxAvg) Pair((bx + tw / 2) * f, (by + th / 2) * f) else null
    }

    /** अगली कमांड पर जाओ; सब पूरी हों तो false */
    private fun stepDelay(st: String): Int =
        stripLimit(st).let { t -> if (t.contains("~~")) t.substringAfterLast("~~").toIntOrNull() ?: 0 else 0 }

    /** applyDelay=false: कमांड छूटी (नहीं मिली) तो उसका टाइमर नहीं लगेगा */
    private fun advance(applyDelay: Boolean = true): Boolean {
        val d = if (applyDelay && index < steps.size) stepDelay(steps[index]) else 0
        index++; gateOkIdx = -1; multiTried = 0; clickPending = false
        numScrolled = false; numFwd = true; numEdges = 0; numScrolls = 0; numRangeTapped.clear(); numCloseStage = 0; numCloses = 0
        if (index >= steps.size) {
            if (d > 0) handler.postDelayed({ if (running) finish() }, d * 1000L) else finish()
            return false
        }
        holdUntil = System.currentTimeMillis() + d * 1000L
        stepStart = holdUntil
        updateBadge()
        return true
    }

    /** सूची को स्क्रॉल (आगे/पीछे). सबसे बड़ी स्क्रॉल होने वाली जगह पर; न मिले तो स्वाइप */
    private fun numScroll(root: AccessibilityNodeInfo, fwd: Boolean) {
        var best: AccessibilityNodeInfo? = null
        var bestArea = 0
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            if (n.isScrollable && n.isVisibleToUser) {
                val r = Rect(); n.getBoundsInScreen(r)
                val a = r.width() * r.height()
                if (a > bestArea) { bestArea = a; best = n }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        val act = if (fwd) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        val b = best
        if (b != null && b.performAction(act)) return
        val dm = resources.displayMetrics
        val x = dm.widthPixels / 2f
        val y1 = dm.heightPixels * (if (fwd) 0.70f else 0.35f)
        val y2 = dm.heightPixels * (if (fwd) 0.35f else 0.70f)
        val path = Path().apply { moveTo(x, y1); lineTo(x, y2) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 350)).build()
        dispatchGesture(g, null, null)
    }

    /** नंबर वाली कमांड में अब और नंबर नहीं मिले: complete=true तो ऐप पूरा माना जाए (✅), वरना कमांड छूटी */
    private fun numGiveUp(complete: Boolean): Boolean {
        numExhausted = true
        if (complete) index = steps.size - 1 else skippedThisApp = true
        return advance(false)
    }

    /** राउंड पूरा: जिस नंबर पर क्लिक हुआ था वह सारी कमांड सफल रहीं तो ✅ (हरा), वरना 🔴 (लाल, दोबारा कोशिश होगी) */
    private fun numCommit() {
        numAllowRed = false
        if (numCur.isEmpty()) return
        numLastNums = numCur.values.toList()
        val sp = getSharedPreferences("apps", MODE_PRIVATE)
        for ((cmd, n) in numCur) {
            val p = numParse(cmd) ?: continue
            val done = numDone(sp, numKey(cmd))
            val failed = numFailed(sp, numFailKey(cmd))
            if (!skippedThisApp) { done.add(n); failed.remove(n); toast("${p.third} $n ✅"); sp.edit().putInt("ipCount", sp.getInt("ipCount", 0) + 1).apply() }
            else { failed[n] = (failed[n] ?: 0) + 1; toast("${p.third} $n 🔴 (फिर कोशिश होगी)") }
            sp.edit().putString(numKey(cmd), done.sorted().joinToString(","))
                .putString(numFailKey(cmd), failed.entries.sortedBy { it.key }.joinToString(",") { "${it.key}:${it.value}" }).apply()
        }
        numCur.clear()
    }

    /** आख़िर में भी कोई नंबर 🔴 बचा हो तो ऐप ⚠ (पूरा नहीं) दिखे */
    private fun numFinalCheck() {
        val sp = getSharedPreferences("apps", MODE_PRIVATE)
        for (st in steps) {
            val c = numOfStep(st) ?: continue
            val done = numDone(sp, numKey(c))
            if (numFailed(sp, numFailKey(c)).any { it.key !in done && it.value < 99 }) skippedThisApp = true
        }
    }

    /** सारी नंबर वाली कमांड की सीमा मिलाकर (सबसे छोटा..सबसे बड़ा); कोई नहीं तो null */
    private fun numRange(): IntRange? {
        var lo = Int.MAX_VALUE; var hi = Int.MIN_VALUE
        for (st in steps) {
            val p = numOfStep(st)?.let { numParse(it) } ?: continue
            lo = minOf(lo, p.first); hi = maxOf(hi, p.second)
        }
        return if (lo <= hi) lo..hi else null
    }

    /** Recents खोलकर उन सारे कार्ड को ऊपर स्वाइप करो जिनके नाम में नंबर (जैसे 37, 37B, D37) सीमा के अंदर हो — पहले अभी वाला नंबर */
    private fun closeNumCardsThen(queueToo: Boolean = false, go: () -> Unit) {
        val r = numRange()
        if (r == null) { go(); return }
        closePkg = "recents"; afterClose = go
        rNumRange = r; rNumCur = numLastNums + numCur.values
        val sp = getSharedPreferences("apps", MODE_PRIVATE)
        val prot = HashSet<String>()
        prot.addAll(labelsOfPkg(packageName))
        val vpn = sp.getString("vpnPkg", "") ?: ""
        if (vpn.isNotEmpty()) prot.addAll(labelsOfPkg(vpn))
        // जुड़े ऐप: "मिनिमाइज़ करके बंद" मोड में इसी चक्कर में हटेंगे (queueToo); बाकी मोड में कभी नहीं छूने
        val qs = HashSet<String>()
        for (q in queue) qs.addAll(labelsOfPkg(q))
        if (queueToo) rQueue = qs else { rQueue = emptySet(); prot.addAll(qs) }
        val pl = protectedLabels()
        prot.addAll(pl); rQueue = rQueue - pl
        rProtect = prot
        rClearAll = sp.getBoolean("numClearAll", false)
        rLabels = installedLabels()
        rTries.clear(); rLog.clear(); rSeen.clear()
        rLabel = ""; rAttempts = 0; rNotFound = 0
        closeStart = System.currentTimeMillis()
        handler.removeCallbacks(tick)
        performGlobalAction(GLOBAL_ACTION_RECENTS)
        handler.postDelayed(recentsStep, 1300)
    }

    // ---------- सुरक्षित ऐप: चुने हुए ऐप Recents से कभी नहीं हटेंगे, बंद भी नहीं होंगे ----------
    private fun protectedPkgs(): Set<String> =
        getSharedPreferences("apps", MODE_PRIVATE).getString("protectPkgs", "")!!
            .split("\n").map { it.trim() }.filter { it.isNotEmpty() }.toSet()

    private fun protectedLabels(): Set<String> {
        val out = HashSet<String>()
        protectedPkgs().forEach { out.addAll(labelsOfPkg(it)) }
        getSharedPreferences("apps", MODE_PRIVATE).getString("protectNames", "")!!
            .split("\n").map { it.trim().lowercase() }.filter { it.isNotEmpty() }.forEach { out.add(it) }
        return out
    }

    /** ऐप के सारे नाम: ऐप का नाम + लॉन्चर वाली गतिविधियों के नाम (Recents में कार्ड पर इनमें से कोई दिख सकता है). होम शॉर्टकट हो तो उसका नाम */
    private fun labelsOfPkg(pkg: String): Set<String> {
        val out = HashSet<String>()
        if (pkg.startsWith("home:")) { out.add(pkg.removePrefix("home:").trim().lowercase()); return out }
        try { out.add(packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString().trim().lowercase()) } catch (e: Exception) {}
        try {
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setPackage(pkg)
            packageManager.queryIntentActivities(i, 0).forEach { out.add(it.loadLabel(packageManager).toString().trim().lowercase()) }
        } catch (e: Exception) {}
        out.remove("")
        return out
    }

    private fun isProtectedLabel(tl: String): Boolean = rProtect.any { p ->
        tl == p || (p.length >= 4 && (tl.contains(p) || (tl.length >= 4 && p.contains(tl))))
    }

    private val numRe = Regex("(?<!\\d)(\\d{1,9})(?!\\d)")
    private fun numsIn(t: String): List<Int> =
        if (t.length > 40 || t.contains(':') || t.contains('%')) emptyList()
        else numRe.findAll(t).mapNotNull { it.groupValues[1].toIntOrNull() }.toList()

    private fun installedLabels(): Set<String> = try {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        packageManager.queryIntentActivities(i, 0)
            .map { it.loadLabel(packageManager).toString().trim().lowercase() }
            .filter { it.isNotEmpty() }.toSet()
    } catch (e: Exception) { emptySet() }

    /** Recents में हटाने लायक कार्ड, तीन दर्जे: (1) नाम में अभी वाला नंबर, (2) नाम में सीमा का कोई और नंबर, (3) फ़ोन का कोई और ऐप.
     *  नंबर वाले कार्ड हमेशा पहले; VPN, अपना ऐप और सुरक्षित ऐप के नाम वाले कार्ड कभी नहीं (पर नंबर वाला कार्ड सुरक्षित नहीं माना जाता
     *  जब तक उसका पूरा नाम ही सुरक्षित नाम न हो). (कार्ड का इलाका, पहचान) */
    private fun findRecentNumCard(range: IntRange, cur: List<Int>): Pair<Rect, String>? {
        val roots = ArrayList<AccessibilityNodeInfo>()
        rootInActiveWindow?.let { roots.add(it) }
        try { windows.forEach { w -> w.root?.let { roots.add(it) } } } catch (e: Exception) {}
        val dm = resources.displayMetrics
        val screen = Rect(0, 0, dm.widthPixels, dm.heightPixels)
        val screenArea = dm.widthPixels.toLong() * dm.heightPixels
        val best = arrayOfNulls<Pair<Rect, String>>(4)
        val bestA = LongArray(4)
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            val ts = listOf(n.text, n.contentDescription).mapNotNull { it?.toString()?.trim() }
                .filter { it.isNotEmpty() && it.length <= 60 }
            for (t in ts) {
                val tl = t.lowercase()
                if (t.length <= 40 && rSeen.size < 40) rSeen.add(t)
                val nums = numsIn(t)
                val numMatch = nums.any { it in range }
                val tier: Int
                val isQueue = rQueue.any { p -> tl == p || (p.length >= 4 && (tl.contains(p) || (tl.length >= 4 && p.contains(tl)))) }
                if (isQueue) {
                    tier = 2                                   // जुड़ा ऐप (सिर्फ़ मिनिमाइज़ मोड में), नंबर वाले कार्ड के बाद
                } else if (numMatch) {
                    if (isProtectedLabel(tl)) continue      // VPN/App Control का कार्ड नंबर वाला नहीं माना जाएगा
                    tier = if (nums.any { it in cur }) 0 else 1
                } else {
                    if (!rClearAll || isProtectedLabel(tl) || tl !in rLabels) continue
                    tier = 3
                }
                if ((rTries[tl] ?: 0) >= 4) continue
                val r = Rect(); n.getBoundsInScreen(r)
                if (!r.intersect(screen) || r.isEmpty) continue
                val area = r.width().toLong() * r.height()
                if (area > screenArea * 0.6) continue
                if (area > bestA[tier]) { best[tier] = Pair(r, tl); bestA[tier] = area }
                break
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        for (r in roots) if (r.packageName != packageName) walk(r)
        return best[0] ?: best[1] ?: best[2] ?: best[3]
    }

    /** ऐप को मिनिमाइज़ करके Recents में उसका कार्ड ऊपर स्वाइप (बैकग्राउंड से हटाना); शॉर्टकट वाली एंट्री में बंद करना छोड़ो */
    private fun closeRecentsThen(pkg: String, go: () -> Unit) {
        if (pkg.startsWith("home:")) closeThen(pkg, go) else closeViaRecents(pkg, go)
    }

    /** पूरी कमांड-सूची एक बार चल चुकी; बाकी (या 🔴) नंबर हैं और इस बार किसी नंबर पर काम हुआ तो उसी ऐप में फिर से शुरू */
    private fun numRepeat(): Boolean {
        if (!running || numExhausted || numPassClicks <= 0) return false
        val sp = getSharedPreferences("apps", MODE_PRIVATE)
        val remaining = steps.any { st ->
            val c = numOfStep(st)
            val p = if (c != null) numParse(c) else null
            if (c == null || p == null) false
            else {
                val done = numDone(sp, numKey(c))
                val exh = numFailed(sp, numFailKey(c)).count { it.value >= 3 && it.key !in done }
                done.count { it in p.first..p.second } + exh < (p.second - p.first + 1)
            }
        }
        if (!remaining) return false
        val failedPass = skippedThisApp          // इस राउंड में कोई कमांड फेल हुई थी → अगले राउंड से पहले VPN दोबारा/दूसरा देश
        numPassClicks = 0
        skippedThisApp = false
        index = 0; gateOkIdx = -1; multiTried = 0; clickPending = false
        val pkg = queue.getOrNull(qIndex)
        val closer: (() -> Unit) -> Unit = { g -> if (pkg != null) closeThen(pkg, g) else closeNumCardsThen(false, g) }
        closer {                                     // नंबर वाले कार्ड हटाओ + जुड़े ऐप पर ऊपर की सेटिंग लगाओ
            if (pkg != null) {
                val go = {
                    armReview()
                    stepStart = System.currentTimeMillis() + 3000
                    launchApp(pkg, false)
                    updateBadge()
                    handler.removeCallbacks(tick); handler.postDelayed(tick, 3000)
                }
                val go2 = { ipThen { go() } }
                if (failedPass) netFixThen(true) { go2() } else go2()
            } else {
                val go = {
                    stepStart = System.currentTimeMillis() + 1500
                    updateBadge()
                    handler.removeCallbacks(tick); handler.postDelayed(tick, 1500)
                }
                val go2 = { ipThen { go() } }
                if (failedPass) netFixThen(true) { go2() } else go2()
            }
        }
        return true
    }

    private fun isCross(cmd: String) = cmd.trim().lowercase() in
        setOf("क्रॉस", "cross", "x", "×", "close", "बंद")

    // क्रॉस/बंद का निशान: टेक्स्ट ×, ✕, X या description/ID में close, dismiss आदि
    private fun findCross(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val marks = setOf("×", "✕", "✖", "✗", "╳", "x")
        val words = listOf("close", "dismiss", "cross", "बंद", "क्रॉस")
        val all = ArrayList<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            all.add(n)
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return all.firstOrNull { n ->
            val t = n.text?.toString()?.trim()?.lowercase()
            val d = n.contentDescription?.toString()?.trim()?.lowercase()
            val id = n.viewIdResourceName?.lowercase()
            (t != null && t in marks) || (d != null && d in marks) ||
            (d != null && words.any { d.contains(it) }) ||
            (id != null && words.any { id.contains(it) })
        }
    }


    // ---------- पिछला ऐप बंद करना (App info -> Force stop) ----------
    private val forceLabels = setOf("force stop", "force-stop", "force close", "जबरन रोकें",
        "जबरदस्ती रोकें", "फ़ोर्स स्टॉप", "फोर्स स्टॉप", "बलपूर्वक रोकें", "जबरन बंद करें")
    private val okLabels = setOf("ok", "ठीक है", "ओके", "yes", "हाँ")

    /** अगले ऐप/राउंड पर जाने से पहले: ऊपर के तीन बटन के हिसाब से जुड़ा ऐप — 0 बंद न करें, 1 मिनिमाइज़+स्वाइप, 2 Force stop.
     *  नंबर वाली कमांड हो तो उसके नंबर वाले कार्ड Recents से अलग से हटते हैं (मोड 1 में जुड़ा ऐप उसी चक्कर में) */
    private fun closeThen(pkg: String, go: () -> Unit) {
        val mode = getSharedPreferences("apps", MODE_PRIVATE).getInt("closeMode", 1)
        val isProt = pkg in protectedPkgs()
        if (numRange() != null) {
            closeNumCardsThen(mode == 1 && !pkg.startsWith("home:") && !isProt) {
                if (mode == 2 && !pkg.startsWith("home:") && !isProt) closeViaSettings(pkg, go) else go()
            }
            return
        }
        if (pkg.startsWith("home:") || mode == 0 || isProt) { go(); return }
        if (mode == 1) { closeViaRecents(pkg, go); return }
        closeViaSettings(pkg, go)
    }

    /** App info खोलकर Force stop दबाना */
    private fun closeViaSettings(pkg: String, go: () -> Unit) {
        closePkg = pkg; afterClose = go; closeStart = System.currentTimeMillis(); closeClicked = false
        try {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) { endClose(); return }
        handler.removeCallbacks(tick); handler.postDelayed(tick, 1500)
    }


    // ---------- मिनिमाइज़ (Recents) में सिर्फ़ उसी ऐप का कार्ड ऊपर स्वाइप ----------
    private var rLabel = ""
    private var rNumRange: IntRange? = null          // नंबर वाला मोड: Recents में इन नंबरों वाले सारे कार्ड हटाओ
    private var rNumCur: List<Int> = emptyList()
    private var rQueue: Set<String> = emptySet()       // मिनिमाइज़ मोड में हटने वाले जुड़े ऐप के नाम
    private var rClearAll = false                      // नंबर वाले कार्ड के साथ बाकी ऐप के कार्ड भी हटाओ (सेटिंग, डिफ़ॉल्ट बंद)
    private var rProtect: Set<String> = emptySet()   // Recents में जो कार्ड नहीं हटाने (VPN, अपना ऐप, और "बंद न करें" हो तो जुड़े ऐप)
    private var rLabels: Set<String> = emptySet()    // फ़ोन के सारे ऐप के नाम (कार्ड पहचानने के लिए)
    private val rTries = HashMap<String, Int>()
    private val rLog = ArrayList<String>()                // इस बार Recents से जो कार्ड हटाए
    private val rSeen = LinkedHashSet<String>()           // Recents में जो नाम दिखे (जाँच के लिए)
    private var rAttempts = 0
    private var rNotFound = 0

    private fun appLabel(pkg: String): String = if (pkg.startsWith("home:")) pkg.removePrefix("home:") else try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) { pkg }

    /** Recents में उस ऐप के नाम वाला कार्ड खोजो; स्क्रीन पर दिखने वाला हिस्सा लौटाओ */
    private fun findRecentCard(label: String): Rect? {
        val roots = ArrayList<AccessibilityNodeInfo>()
        rootInActiveWindow?.let { roots.add(it) }
        try { windows.forEach { w -> w.root?.let { roots.add(it) } } } catch (e: Exception) {}
        val dm = resources.displayMetrics
        val screen = Rect(0, 0, dm.widthPixels, dm.heightPixels)
        val want = label.trim().lowercase()
        var exact: Rect? = null; var exactA = 0L
        var part: Rect? = null; var partA = 0L
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            val ts = listOf(n.text, n.contentDescription).mapNotNull { it?.toString()?.trim()?.lowercase() }
            val isExact = ts.any { it == want }
            val isPart = !isExact && ts.any { it.contains(want) }
            if (isExact || isPart) {
                val r = Rect(); n.getBoundsInScreen(r)
                if (r.intersect(screen) && !r.isEmpty) {
                    val area = r.width().toLong() * r.height()
                    if (isExact && area > exactA) { exact = r; exactA = area }
                    if (isPart && area > partA) { part = r; partA = area }
                }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        for (r in roots) if (r.packageName != packageName) walk(r)
        return exact ?: part
    }

    private fun closeViaRecents(pkg: String, go: () -> Unit) {
        closePkg = "recents"; afterClose = go
        rNumRange = null
        rLabel = appLabel(pkg); rAttempts = 0; rNotFound = 0
        closeStart = System.currentTimeMillis()
        handler.removeCallbacks(tick)
        performGlobalAction(GLOBAL_ACTION_RECENTS)
        handler.postDelayed(recentsStep, 1300)
    }

    private val recentsStep = object : Runnable {
        override fun run() {
            if (!running || closePkg != "recents") return
            val numMode = rNumRange != null
            if (System.currentTimeMillis() - closeStart > (if (numMode) 60000 else 14000)) { leaveRecents(); return }
            val hit = if (numMode) findRecentNumCard(rNumRange!!, rNumCur) else null
            val card = if (numMode) hit?.first else findRecentCard(rLabel)
            if (hit != null) { rTries[hit.second] = (rTries[hit.second] ?: 0) + 1; rLog.add(hit.second) }
            if (card == null) {
                // पहली बार में न दिखे तो Recents खुलने का थोड़ा इंतज़ार; बाद में न दिखे = बंद हो चुका
                if (rAttempts == 0 && rNotFound < (if (numMode) 9 else 4)) { rNotFound++; handler.postDelayed(this, 700); return }
                leaveRecents(); return
            }
            if (rAttempts >= (if (numMode) 40 else 3)) { leaveRecents(); return }
            rAttempts++
            val dm = resources.displayMetrics
            val x = card.centerX().toFloat()
            val y0 = card.centerY().toFloat()
            val y1 = (y0 - dm.heightPixels * 0.45f).coerceAtLeast(20f)
            val path = Path().apply { moveTo(x, y0); lineTo(x, y1) }
            val g = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 220)).build()
            val again = { handler.postDelayed(this, 900) }
            val ok = dispatchGesture(g, object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(d: GestureDescription?) { again() }
                override fun onCancelled(d: GestureDescription?) { again() }
            }, null)
            if (!ok) again()
        }
    }

    private fun leaveRecents() {
        if (rNumRange != null) {
            val msg = if (rLog.isNotEmpty()) "🧹 Recents से हटाए: " + rLog.joinToString(", ")
                      else "Recents में कोई कार्ड नहीं हटा. दिखे नाम: " + rSeen.take(12).joinToString(" | ")
            Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
        }
        performGlobalAction(GLOBAL_ACTION_HOME)          // Recents से बाहर
        handler.postDelayed({ if (running && closePkg == "recents") endClose() }, 700)
    }

    private fun endClose() {
        closePkg = null; rNumRange = null
        val a = afterClose; afterClose = null
        handler.removeCallbacks(tick)
        a?.invoke()
    }

    private fun nodesByText(root: AccessibilityNodeInfo, labels: Set<String>): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            val t = (n.text ?: n.contentDescription)?.toString()?.trim()?.lowercase()
            if (t != null && t in labels) out.add(n)
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return out
    }

    private fun closeTick() {
        if (System.currentTimeMillis() - closeStart > 12000) { endClose(); return }   // न हो पाए तो आगे बढ़ो
        val root = rootInActiveWindow
        if (root != null && root.packageName != packageName) {
            if (!closeClicked) {
                val n = nodesByText(root, forceLabels).firstOrNull()
                if (n != null) {
                    if (!n.isEnabled) { endClose(); return }        // बटन बंद = ऐप पहले से रुका / सिस्टम ऐप
                    if (clickNode(n)) { closeClicked = true }
                }
            } else {
                val ok = nodesByText(root, okLabels + forceLabels).firstOrNull { it.isEnabled }
                if (ok != null && clickNode(ok)) {
                    handler.removeCallbacks(tick)
                    handler.postDelayed({ if (closePkg != null) endClose() }, 800)
                    return
                }
            }
        }
        handler.postDelayed(tick, 700)
    }

    // ---------- नया IP: VPN ऐप में नीचे वाला IP (ऊपर वाला असली IP नहीं) ----------
    private val ipRe = Regex("""\b(?:\d{1,3}\.){3}\d{1,3}\b""")

    private fun ipNodeText(n: AccessibilityNodeInfo): String? =
        listOfNotNull(n.text?.toString(), n.contentDescription?.toString()).joinToString(" ").ifBlank { null }

    /** VPN ऐप की स्क्रीन पर दिखे IP में से सबसे नीचे वाला. (word लिखा हो तो उस शब्द, जैसे from, के पास वाला IP). दो अलग IP न दिखें तो null */
    private fun pickVpnIp(root: AccessibilityNodeInfo, word: String): String? {
        val found = LinkedHashMap<String, Pair<Int, Boolean>>()   // IP -> (ऊँचाई, शब्द पास में)
        val w = word.trim().lowercase()
        fun valid(x: String) = x.split(".").all { (it.toIntOrNull() ?: 999) <= 255 }
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            val t = ipNodeText(n)
            if (t != null && n.isVisibleToUser) {
                val ips = ipRe.findAll(t).map { it.value }.filter { valid(it) }.toList()
                if (ips.isNotEmpty()) {
                    val r = Rect(); n.getBoundsInScreen(r)
                    var near = false
                    if (w.isNotEmpty()) {
                        near = t.lowercase().contains(w)
                        if (!near) {
                            val par = n.parent
                            if (par != null) for (i in 0 until par.childCount) {
                                val ct = par.getChild(i)?.let { ipNodeText(it) }
                                if (ct != null && ct.lowercase().contains(w)) near = true
                            }
                        }
                    }
                    for (ip in ips) {
                        val old = found[ip]
                        if (old == null || r.top > old.first) found[ip] = Pair(r.top, near || (old?.second == true))
                    }
                }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        if (found.size < 2) return null
        val withWord = found.filter { it.value.second }
        val pool = if (withWord.isNotEmpty()) withWord else found
        return pool.maxByOrNull { it.value.first }?.key
    }

    /** VPN ऐप खोलकर नीचे वाला IP पढ़ो (दो बार लगातार वही दिखे तब पक्का). 25 सेकंड में न मिले तो आख़िरी दिखा हुआ या null */
    private fun readVpnIp(pkg: String, word: String, cb: (String?) -> Unit) {
        val i = packageManager.getLaunchIntentForPackage(pkg)
        if (i == null) { cb(null); return }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i)
        var tries = 0; var last: String? = null; var same = 0
        fun poll() {
            if (!running) return
            val root = rootInActiveWindow
            val ip = if (root != null && root.packageName == pkg) pickVpnIp(root, word) else null
            if (ip != null) { if (ip == last) same++ else { last = ip; same = 1 } } else { same = 0 }
            badge?.text = "🌐 IP पढ़ रहे हैं…" + (ip?.let { " $it" } ?: "")
            if (same >= 2) { cb(ip); return }
            tries++
            if (tries >= 16) { cb(last); return }
            handler.postDelayed({ poll() }, 1500)
        }
        handler.postDelayed({ poll() }, 3000)
    }

    /** अभी वाला IP लिखो → VPN बंद-चालू करके नया IP पढ़ो; 24 घंटे में चल चुका हो तो फिर बंद-चालू (हर 3री कोशिश पर देश बदलो) → नया मिले तो फाइल में लिखो */
    private fun ipRotate(pkg: String, word: String, resume: () -> Unit, fail: (String) -> Unit) {
        val sp = getSharedPreferences("apps", MODE_PRIVATE)
        var attempt = 0
        var tryNext: () -> Unit = {}
        fun onIp(ip: String?) {
            if (!running) return
            if (ip == null) { fail("🌐 VPN ऐप में नीचे वाला IP स्क्रीन पर नहीं दिखा"); return }
            if (IpLog.isUsed(this, ip)) { toast("🌐 IP $ip 24 घंटे में चल चुका — फिर बदल रहे हैं"); tryNext(); return }
            IpLog.record(this, ip)
            sp.edit().putInt("ipCount", 0).apply()
            toast("🌐 नया IP $ip ✔")
            resume()
        }
        tryNext = {
            attempt++
            if (attempt > 12) fail("🌐 24 घंटे में न चला हुआ नया IP नहीं मिला (12 कोशिश)")
            else {
                val goRead = { readVpnIp(pkg, word) { ip -> onIp(ip) } }
                if (attempt % 3 == 0 && vpnLines("vpnCountry").isNotEmpty()) changeVpnCountry(pkg, goRead, fail)
                else vpnCycle("नया IP", pkg, true, goRead, fail)
            }
        }
        // पहले अभी चल रहा IP फाइल में लिखो (वह 24 घंटे दोबारा नहीं आएगा), फिर बदलो
        readVpnIp(pkg, word) { cur ->
            if (cur != null) IpLog.record(this, cur)
            tryNext()
        }
    }

    /** नंबर वाली कितनी कॉपी हो चुकीं (ipCount) ≥ सेटिंग (डिफ़ॉल्ट 20) हो तो पहले नया IP लो, फिर next() */
    private fun ipThen(next: () -> Unit) {
        val sp = getSharedPreferences("apps", MODE_PRIVATE)
        val pkg = sp.getString("vpnPkg", "")!!
        val every = maxOf(1, sp.getInt("ipEvery", 20))
        if (!sp.getBoolean("ipOn", false) || pkg.isEmpty() || sp.getInt("ipCount", 0) < every || !onVpn()) { next(); return }
        netCycling = true
        val resume = { netCycling = false; if (running) next() }
        val fail = { why: String ->
            netCycling = false
            if (chainOn) chainFail("$why — नया IP लेते समय रुका")
            else { toast("$why — नया IP लेते समय रुका"); stop() }
        }
        ipRotate(pkg, sp.getString("ipWord", "")!!, resume, fail)
    }

    /** लगातार "missApps" (डिफ़ॉल्ट 3) ऐप में कमांड छूटी हों तो अगला ऐप खोलने से पहले वाईफाई/VPN बंद-चालू (VPN हो तो देश बदलकर);
     *  वरना सीधे next() */
    private fun netFixThen(force: Boolean = false, next: () -> Unit) {
        val sp = getSharedPreferences("apps", MODE_PRIVATE)
        val limit = sp.getInt("missApps", 3)
        if (!force && (!sp.getBoolean("missCycle", true) || missedApps < limit)) { next(); return }
        val vpnPkg = sp.getString("vpnPkg", "")!!
        val vpnUp = onVpn() && vpnPkg.isNotEmpty()
        if (!vpnUp && !onWifi()) { missedApps = 0; next(); return }
        missedApps = 0
        netCycling = true
        val resume = { netCycling = false; if (running) next() }
        val fail = { why: String ->
            netCycling = false
            if (chainOn) chainFail("$why — नेटवर्क सुधार पर रुका")
            else { toast("$why — नेटवर्क सुधार पर रुका"); stop() }
        }
        val label = "अगला ऐप"
        if (vpnUp) {
            if (vpnLines("vpnCountry").isNotEmpty()) changeVpnCountry(vpnPkg, resume, fail)
            else vpnCycle(label, vpnPkg, true, resume, fail)
        } else wifiCycle(label, resume, fail)
    }

    private fun finish() {
        forceReview = false
        numCommit()
        if (numRepeat()) return
        numFinalCheck()
        if (queue.isNotEmpty()) {
            if (!skippedThisApp) markDone(queue[qIndex])   // पूरा हुआ: अधूरी सूची से हटाओ
            if (skippedThisApp) missedApps++ else missedApps = 0
            skippedThisApp = false
        }
        if (qIndex + 1 < queue.size) {          // अगले ऐप पर वही कमांड
            val prev = queue[qIndex]
            qIndex++; index = 0; gateOkIdx = -1
            val closer: (() -> Unit) -> Unit = { g -> closeThen(prev, g) }
            closer {
                netFixThen { ipThen {
                    armReview()
                    stepStart = System.currentTimeMillis() + 3000
                    launchApp(queue[qIndex])
                    updateBadge()
                    handler.removeCallbacks(tick); handler.postDelayed(tick, 3000)
                } }
            }
            return
        }
        val left = failedList().distinct()
        if (autoRetry && left.isNotEmpty()) {
            // अधूरे ऐप अपने-आप फिर: कुल 5 राउंड तक (सब पूरे होते ही रुक जाएगा)
            noProgress = if (left.size < roundFailed) 0 else noProgress + 1
            val spR = getSharedPreferences("apps", MODE_PRIVATE)
            val maxRounds = spR.getInt("maxRounds", 5)
            // राउंड 3+ में जितने भी ऐप बचे हों (5, 10, कुछ भी): सफल होने तक बार-बार (डिफ़ॉल्ट 4 अतिरिक्त राउंड), फिर छोड़ो
            val extra = round >= 3
            if (extra) fewTries++
            if (round < maxRounds || (extra && fewTries <= spR.getInt("fewTries", 4))) {
                // सिर्फ़ 1-2 ऐप बचे हों तो "लगातार 3 ऐप" कभी पूरे नहीं होते: इसलिए हर राउंड से पहले नेटवर्क सुधार
                if (extra && left.size <= 2) missedApps = maxOf(missedApps, spR.getInt("missApps", 3))
                roundFailed = left.size
                round++
                val last = queue[qIndex]
                queue = left; qIndex = 0; index = 0; gateOkIdx = -1
                closeThen(last) {
                    netFixThen {
                        armReview()
                        stepStart = System.currentTimeMillis() + 3000
                        launchApp(queue[0])
                        updateBadge()
                        handler.removeCallbacks(tick); handler.postDelayed(tick, 3000)
                    }
                }
                return
            }
        }
        val msg = when {
            queue.isEmpty() -> "सारी कमांड पूरी ✔"
            left.isEmpty() -> "सारे ऐप पूरे ✔ (राउंड $round)"
            else -> "रुका: ${left.size} ऐप अधूरे रह गए"
        }
        val lastPkg = queue.getOrNull(qIndex)
        if (lastPkg != null) {
            // आख़िरी खुला ऐप भी बंद करो, फिर अपना ऐप भी बंद
            closeThen(lastPkg) {
                if (left.isEmpty() && runNextProject()) return@closeThen   // अगला प्रोजेक्ट
                toast(if (chainOn && left.isNotEmpty()) "$msg — अगला प्रोजेक्ट नहीं चलाया" else msg)
                chainOn = false
                stop()
                // अपना ऐप भी बंद करो और होम स्क्रीन पर आ जाओ (✔ अगली बार खोलने पर वहीं मिलेंगे)
                try { MainActivity.cur?.finishAndRemoveTask() } catch (e: Exception) {}
                Handler(Looper.getMainLooper()).postDelayed({
                    try { performGlobalAction(GLOBAL_ACTION_HOME) } catch (e: Exception) {}
                }, 500)
            }
            return
        }
        toast(msg)
        stop()
    }


    // स्क्रीन की पहचान: सारे टेक्स्ट का हैश (बदले तो मतलब स्क्रीन बदली)
    private fun screenSig(root: AccessibilityNodeInfo): Int {
        var h = 17
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            h = h * 31 + (n.text?.toString()?.hashCode() ?: 0)
            h = h * 31 + (n.contentDescription?.toString()?.hashCode() ?: 0)
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return h
    }

    // टेक्स्ट जहाँ-जहाँ दिखे सारी जगहें (पहले exact, फिर contains), ऊपर से नीचे क्रम में
    // ---------- गुणा (×) जैसा चित्र खोजना: बिना नाम/टेक्स्ट वाला क्रॉस बटन ----------
    private var crossLastShot = 0L

    private fun findAndTapCross(root: AccessibilityNodeInfo) {
        val now = System.currentTimeMillis()
        if (now - crossLastShot < 1500) return
        crossLastShot = now
        val my = index
        val dm = resources.displayMetrics
        val d = dm.density
        // पहले छोटे, लगभग चौकोर आइकन-जैसे नोड (बिना टेक्स्ट वाले)
        val cands = ArrayList<Rect>()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || cands.size >= 60) return
            if (n.isVisibleToUser && n.text.isNullOrEmpty()) {
                val r = Rect(); n.getBoundsInScreen(r)
                val w = r.width(); val h = r.height()
                if (w >= 12 * d && h >= 12 * d && w <= 80 * d && h <= 80 * d && w.toFloat() / h in 0.6f..1.7f &&
                    (n.isClickable || (n.className?.toString() ?: "").contains("Image") || n.contentDescription != null)) cands.add(r)
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        if (Build.VERSION.SDK_INT >= 30) {
            busy = true
            shotApi30 { bmp -> finishCross(bmp, cands, my) }
        } else {
            val cs = CaptureService.instance ?: return
            busy = true
            bg.execute { finishCross(cs.capture(), cands, my) }
        }
    }

    /** (bg थ्रेड पर) आधे आकार की स्क्रीन में × की आकृति खोजो; मिले तो मुख्य थ्रेड पर उसके बीच में टैप */
    private fun finishCross(bmp: Bitmap?, cands: List<Rect>, my: Int) {
        var hit: Pair<Float, Float>? = null
        if (bmp != null) try {
            val W = bmp.width / 2; val H = bmp.height / 2
            val lum = gray(Bitmap.createScaledBitmap(bmp, W, H, true), W, H)
            val d = resources.displayMetrics.density
            var best = 0.22f                      // इससे कम मिलान = × नहीं
            // 1) आइकन-जैसे नोड
            for (r in cands) {
                val sz = maxOf(r.width(), r.height()) / 2
                val sc = xScoreAt(lum, W, H, r.centerX() / 2 - sz / 2, r.centerY() / 2 - sz / 2, sz)
                if (sc > best) { best = sc; hit = Pair(r.exactCenterX(), r.exactCenterY()) }
            }
            // 2) नोड से न मिले (Unity/वेब आदि) तो पूरी स्क्रीन के हर हिस्से में खोजो
            if (hit == null) {
                for (dp in intArrayOf(20, 28, 36, 48, 64)) {
                    val s = (dp * d / 2).toInt()
                    if (s < 14) continue
                    val st = maxOf(2, s / 4)
                    var y = 0
                    while (y + s <= H) {
                        var x = 0
                        while (x + s <= W) {
                            var sc = xScoreAt(lum, W, H, x, y, s)
                            if (sc > 0f && y < H * 0.4f) sc += 0.02f          // क्रॉस ज़्यादातर ऊपर की ओर होता है
                            if (sc > best) { best = sc; hit = Pair((x + s / 2f) * 2f, (y + s / 2f) * 2f) }
                            x += st
                        }
                        y += st
                    }
                }
            }
        } catch (e: Throwable) { }
        val pos = hit
        handler.post {
            if (!running || index != my || pos == null) { busy = false; return@post }
            val path = Path().apply { moveTo(pos.first, pos.second) }
            runGesture(path, 60, my)
        }
    }

    /** lum में (x0,y0) से s×s वर्ग क्या × जैसा है? दोनों विकर्ण एक-से रंग के और बाकी हिस्सा एक-सा, पर दोनों अलग. 0 = नहीं */
    private fun xScoreAt(lum: IntArray, W: Int, H: Int, x0: Int, y0: Int, s: Int): Float {
        val n = 13
        if (s < n || x0 < 0 || y0 < 0 || x0 + s > W || y0 + s > H) return 0f
        val c = IntArray(n * n)
        val inset = s * 0.08f; val span = s * 0.84f
        for (j in 0 until n) for (i in 0 until n) {
            val px = (x0 + inset + (i + 0.5f) * span / n).toInt().coerceIn(0, W - 1)
            val py = (y0 + inset + (j + 0.5f) * span / n).toInt().coerceIn(0, H - 1)
            c[j * n + i] = lum[py * W + px]
        }
        var sum = 0; var cnt = 0
        for (j in 0 until n) for (i in 0 until n) {
            if (abs(i - j) >= 3 && abs(i + j - (n - 1)) >= 3) { sum += c[j * n + i]; cnt++ }
        }
        if (cnt == 0) return 0f
        val mo = sum.toFloat() / cnt
        var v = 0f
        for (j in 0 until n) for (i in 0 until n) {
            if (abs(i - j) >= 3 && abs(i + j - (n - 1)) >= 3) { val e = c[j * n + i] - mo; v += e * e }
        }
        val so = Math.sqrt((v / cnt).toDouble()).toFloat()
        if (so > 28f) return 0f                         // बाकी हिस्सा एक-सा नहीं (जैसे + या अक्षर)
        var good = 0; var tot = 0; var pos = 0; var neg = 0; var cs = 0f
        for (k in 0 until n) for (dg in 0..1) {
            if (dg == 1 && k == n / 2) continue
            val i = k; val j = if (dg == 0) k else n - 1 - k
            var bestD = 0f
            for (o in -1..1) {
                val ii = i + o; val jj = if (dg == 0) j - o else j + o
                if (ii < 0 || ii >= n || jj < 0 || jj >= n) continue
                val dd = c[jj * n + ii] - mo
                if (abs(dd) > abs(bestD)) bestD = dd
            }
            tot++
            if (abs(bestD) >= 45f) { good++; cs += abs(bestD); if (bestD > 0) pos++ else neg++ }
        }
        if (tot == 0 || good == 0) return 0f
        val frac = good.toFloat() / tot
        val polar = maxOf(pos, neg).toFloat() / good
        if (frac < 0.85f || polar < 0.9f) return 0f
        return frac * (cs / good) / 255f - so / 255f
    }

    // ---------- आइकन / चित्र खोजना: टेक्स्ट न हो तो description, hint और ID (जैसे daily_check) से ----------
    private val hiEn = mapOf(
        "डेली" to listOf("daily", "day"), "चेकिंग" to listOf("check", "checkin"), "चेक" to listOf("check"),
        "चेकइन" to listOf("checkin", "check"), "साइन" to listOf("sign"), "लॉगिन" to listOf("login", "signin"),
        "अटेंडेंस" to listOf("attendance", "checkin"), "हाज़िरी" to listOf("attendance", "checkin"),
        "क्लेम" to listOf("claim", "collect", "receive"), "रिवॉर्ड" to listOf("reward", "gift", "bonus"),
        "गिफ्ट" to listOf("gift"), "बोनस" to listOf("bonus"), "मिशन" to listOf("mission", "task"), "टास्क" to listOf("task", "mission"),
        "बंद" to listOf("close", "dismiss", "cross"), "क्रॉस" to listOf("close", "cross", "dismiss"),
        "बैक" to listOf("back", "return"), "वापस" to listOf("back", "return"), "खोलो" to listOf("open"),
        "सेटिंग" to listOf("setting", "settings", "gear"), "सेटिंग्स" to listOf("setting", "settings", "gear"),
        "शेयर" to listOf("share"), "कॉपी" to listOf("copy"), "पेस्ट" to listOf("paste"), "सर्च" to listOf("search"),
        "खोजो" to listOf("search"), "प्ले" to listOf("play"), "पॉज़" to listOf("pause"), "ओके" to listOf("ok", "confirm"),
        "ठीक" to listOf("ok", "confirm"), "मेनू" to listOf("menu", "more"), "होम" to listOf("home"), "लाइक" to listOf("like", "heart"),
        "फॉलो" to listOf("follow"), "सेंड" to listOf("send"), "भेजो" to listOf("send"), "मैसेज" to listOf("message", "chat"),
        "चैट" to listOf("chat", "message"), "कैमरा" to listOf("camera"), "प्रोफाइल" to listOf("profile", "avatar"),
        "डाउनलोड" to listOf("download"), "अपलोड" to listOf("upload"), "डिलीट" to listOf("delete", "trash", "remove"),
        "जोड़ो" to listOf("add", "plus"), "प्लस" to listOf("add", "plus"), "नया" to listOf("new", "add"), "रिफ्रेश" to listOf("refresh", "reload"),
        "स्किप" to listOf("skip"), "आगे" to listOf("next", "forward"), "अगला" to listOf("next", "forward"), "पीछे" to listOf("back", "previous"),
        "इनाम" to listOf("reward", "gift", "prize"), "स्पिन" to listOf("spin", "lucky"), "वॉलेट" to listOf("wallet"),
        "नोटिफिकेशन" to listOf("notification", "bell"), "कमेंट" to listOf("comment"), "रूम" to listOf("room"), "पार्टी" to listOf("party")
    )
    private val hiSkip = setOf("में", "का", "की", "के", "को", "पर", "से", "वाला", "वाली", "वाले", "है", "the", "a", "of")

    /** टेक्स्ट वाला नोड न मिले तो चित्र/आइकन: description, hint, ID (जैसे daily_check_btn) में कमांड के शब्द (हिंदी के अंग्रेज़ी रूप भी) खोजो.
     *  सारे शब्द मिलें तभी; सबसे सटीक (छोटे नाम वाला) एक नोड. पूरी तरह बिना नाम का चित्र नहीं पहचाना जा सकता — उसके लिए 📷 स्क्रीनशॉट वाली कमांड */
    private fun findByHint(root: AccessibilityNodeInfo, target: String): List<AccessibilityNodeInfo> {
        val toks = target.trim().lowercase().split(Regex("[^\\p{L}\\p{M}\\p{N}]+"))
            .filter { it.length >= 2 && it !in hiSkip }
        if (toks.isEmpty()) return emptyList()
        val alts = toks.map { t -> listOf(t) + (hiEn[t] ?: emptyList()) }
        fun squash(x: String) = x.lowercase().replace(Regex("[^\\p{L}\\p{M}\\p{N}]"), "")
        var best: AccessibilityNodeInfo? = null; var bestLen = Int.MAX_VALUE
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            if (n.isVisibleToUser) {
                val parts = ArrayList<String>()
                n.text?.let { parts.add(it.toString()) }
                n.contentDescription?.let { parts.add(it.toString()) }
                if (Build.VERSION.SDK_INT >= 26) n.hintText?.let { parts.add(it.toString()) }
                n.viewIdResourceName?.let { parts.add(it.substringAfterLast('/')) }
                val hay = squash(parts.joinToString(" "))
                if (hay.isNotEmpty() && alts.all { a -> a.any { hay.contains(squash(it)) } }) {
                    if (hay.length < bestLen) { best = n; bestLen = hay.length }
                }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        val b = best
        return if (b != null) listOf(b) else emptyList()
    }

    private fun findNodes(root: AccessibilityNodeInfo, target: String): List<AccessibilityNodeInfo> {
        val t = target.trim().lowercase()
        val all = ArrayList<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            all.add(n)
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        fun txt(n: AccessibilityNodeInfo) =
            (n.text ?: n.contentDescription)?.toString()?.trim()?.lowercase()
        val exact = all.filter { txt(it) == t }
        val list = if (exact.isNotEmpty()) exact else all.filter { val x = txt(it); x != null && x.contains(t) }
        val seen = HashSet<String>()
        val out = ArrayList<Pair<Int, AccessibilityNodeInfo>>()
        for (n in list) {
            if (!n.isVisibleToUser) continue
            var x: AccessibilityNodeInfo? = n
            while (x != null && !x.isClickable) x = x.parent
            val c = x ?: n
            val r = Rect(); c.getBoundsInScreen(r)
            if (!seen.add(r.toShortString())) continue
            out.add(Pair(r.top * 10000 + r.left, n))
        }
        return out.sortedBy { it.first }.map { it.second }
    }

    // "<base> <नंबर>" जैसे सारे दिखते नोड (नंबर lo..hi में, और अभी हुआ न हो), छोटे नंबर पहले
    private fun findNumbered(root: AccessibilityNodeInfo, base: String, lo: Int, hi: Int, done: Set<Int>, failed: Map<Int, Int>): List<Pair<Int, AccessibilityNodeInfo>> {
        val re = Regex("^" + Regex.escape(base.trim()) + "\\s*(\\d+)\$", RegexOption.IGNORE_CASE)
        val out = ArrayList<Pair<Int, AccessibilityNodeInfo>>()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            val t = (n.text ?: n.contentDescription)?.toString()?.trim()
            if (t != null && n.isVisibleToUser) {
                val v = re.find(t)?.groupValues?.get(1)?.toIntOrNull()
                if (v != null && v in lo..hi && v !in done && (failed[v] ?: 0) < 3) out.add(Pair(v, n))
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        // पहले जो अभी हुए नहीं, फिर 🔴 वाले (दोबारा कोशिश); दोनों में छोटा नंबर पहले
        return out.sortedWith(compareBy({ if (failed.containsKey(it.first)) 1 else 0 }, { it.first }))
    }

    /** स्क्रीन पर रेंज वाला टैब/बटन (\"1-50\", \"51 से 100\", \"151 to 200\") जिसकी रेंज में target आता हो; सबसे छोटी रेंज पहले */
    private fun findRangeTab(root: AccessibilityNodeInfo, target: Int): AccessibilityNodeInfo? {
        val re = Regex("(\\d+)\\s*(?:-|–|—|~|to|TO|To|से|तक)\\s*(\\d+)")
        var best: AccessibilityNodeInfo? = null
        var bestSpan = Int.MAX_VALUE
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            val t = (n.text ?: n.contentDescription)?.toString()?.trim()
            if (t != null && t.length <= 20 && n.isVisibleToUser) {
                val m = re.find(t)
                val a = m?.groupValues?.get(1)?.toIntOrNull()
                val b = m?.groupValues?.get(2)?.toIntOrNull()
                if (a != null && b != null && target in a..b && b - a < bestSpan) { bestSpan = b - a; best = n }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return best
    }

    /** नंबर वाली कमांड का नंबर समय में नहीं मिला: उस नंबर की कोशिश +1 (3 कोशिश के बाद वह नंबर छोड़ दिया जाता है) */
    private fun numMarkMiss(cmd: String, permanent: Boolean = false) {
        val p = numParse(cmd) ?: return
        val sp = getSharedPreferences("apps", MODE_PRIVATE)
        val done = numDone(sp, numKey(cmd))
        val failed = numFailed(sp, numFailKey(cmd))
        val t = (p.first..p.second).firstOrNull { it !in done && !failed.containsKey(it) }
            ?: (p.first..p.second).firstOrNull { it !in done && (failed[it] ?: 0) < 3 } ?: return
        failed[t] = if (permanent) 99 else (failed[t] ?: 0) + 1     // 99 = कॉपी मौजूद ही नहीं, दोबारा कभी नहीं खोजना
        sp.edit().putString(numFailKey(cmd), failed.entries.sortedBy { it.key }.joinToString(",") { "${it.key}:${it.value}" }).apply()
        toast(if (permanent) "${p.third} $t है ही नहीं → छोड़ा, कमांड शुरू से" else "${p.third} $t नहीं मिला → अगली कमांड")
    }

    /** नंबर नहीं मिला: वह कॉपी हमेशा के लिए छोड़ो; स्क्रीन पर आपका लिखा पहला टेक्स्ट खोजकर क्लिक, ~1 सेकंड बाद दूसरा टेक्स्ट खोजकर क्लिक, फिर इसी ऐप की सारी कमांड शुरू से */
    private fun numNotFoundRestart(cmd: String) {
        numCloses++
        numMarkMiss(cmd, true)
        val (t1, t2) = numExtras(cmd)
        holdUntil = System.currentTimeMillis() + 20000; stepStart = holdUntil      // इस बीच कमांड का लूप रुका रहे
        fun clickText(t: String, left: Int, done: () -> Unit) {
            if (!running) return
            if (t.isEmpty()) { done(); return }
            val r = rootInActiveWindow
            val nd = if (r != null) findNode(r, t) else null
            if (nd != null && clickNode(nd)) {
                toast("$t ✔")
                handler.postDelayed({ done() }, 1000)
            } else if (left > 0) handler.postDelayed({ clickText(t, left - 1, done) }, 500)
            else { toast("$t स्क्रीन पर नहीं दिखा"); done() }
        }
        clickText(t1, 5) {
            clickText(t2, 5) {
                if (running) {
                    index = 0; gateOkIdx = -1; multiTried = 0; clickPending = false
                    numScrolled = false; numFwd = true; numEdges = 0; numScrolls = 0
                    numRangeTapped.clear()
                    holdUntil = System.currentTimeMillis() + 600; stepStart = holdUntil
                    updateBadge()
                }
            }
        }
    }

    private fun clickNode(n: AccessibilityNodeInfo): Boolean {
        var x: AccessibilityNodeInfo? = n
        while (x != null && !x.isClickable) x = x.parent
        return x?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true
    }

    // पहले exact match, फिर contains (अंग्रेज़ी में बड़े-छोटे अक्षर का फ़र्क नहीं)
    private fun findNode(root: AccessibilityNodeInfo, target: String): AccessibilityNodeInfo? {
        val t = target.trim().lowercase()
        val all = ArrayList<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            all.add(n)
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        fun txt(n: AccessibilityNodeInfo) =
            (n.text ?: n.contentDescription)?.toString()?.trim()?.lowercase()
        return all.firstOrNull { txt(it) == t }
            ?: all.firstOrNull { val s = txt(it); s != null && s.contains(t) }
    }

    // छोटा बैज: कौन सी कमांड चल रही है; टैप करने पर रुक जाएगा
    private fun showBadge() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        badge = TextView(this).apply {
            textSize = 14f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                cornerRadius = 40f; setColor(Color.parseColor("#CC C62828".replace(" ", "")))
            }
            setPadding(24, 12, 24, 12)
            setOnClickListener { toast("रोक दिया"); chainOn = false; stop() }
        }
        updateBadge()
        wm.addView(badge, WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; y = 120 })
    }

    private fun updateBadge() {
        val r = if (autoRetry) "राउंड $round · " else ""
        val pr = if (chainOn) "प्रोजेक्ट ${chainIdx + 1}/${chainNames.size} · " else ""
        val app = pr + r + (if (queue.size > 1) "ऐप ${qIndex + 1}/${queue.size} · " else "")
        badge?.text = "⏹ $app" + "कमांड ${index + 1}/${steps.size}: ${prettyStep(steps[index])}"
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() { stop(); instance = null; super.onDestroy() }
}

/** कमांड को सूची/बैज में दिखाने लायक नाम */
fun prettyStep(s0: String): String {
    val lim = stepLimit(s0)
    val s = stripLimit(s0)
    val core = if (!s.contains("~~")) prettyBase(s) else {
        val d = s.substringAfterLast("~~").toIntOrNull() ?: 0
        val base = prettyBase(s.substringBeforeLast("~~"))
        if (d > 0) "$base  ⏱ $d सेकंड" else base
    }
    return if (lim > 0) "$core  🔍 $lim सेकंड खोजेगा" else core
}

/** कमांड के आख़िर में "@@सेकंड" हो तो वह उस कमांड के खोजने का अपना समय है (जैसे ...~~5@@30) */
fun stepLimit(st: String): Int {
    val t = st.substringAfterLast("@@", "")
    return if (st.contains("@@") && t.isNotEmpty() && t.all { it.isDigit() }) t.toIntOrNull() ?: 0 else 0
}
fun stripLimit(st: String): String {
    val t = st.substringAfterLast("@@", "")
    return if (st.contains("@@") && t.isNotEmpty() && t.all { it.isDigit() }) st.substringBeforeLast("@@") else st
}

/** नंबर वाली कमांड:  NUM:<से>-<तक>:<टेक्स्ट>  → (से, तक, टेक्स्ट) */
fun numParse(cmd: String): Triple<Int, Int, String>? {
    if (!cmd.startsWith("NUM:")) return null
    val p = cmd.removePrefix("NUM:").split(":", limit = 2)
    if (p.size < 2) return null
    val r = p[0].split("-")
    val lo = r.getOrNull(0)?.toIntOrNull() ?: return null
    val hi = r.getOrNull(1)?.toIntOrNull() ?: return null
    return Triple(lo, hi, p[1].substringBefore("¦"))
}
/** नंबर न मिलने पर बंद करने वाले दो टेक्स्ट:  NUM:1-1000:कॉपी¦बंद करें¦पीछे  → (बंद करें, पीछे) */
fun numExtras(cmd: String): Pair<String, String> {
    val p = cmd.removePrefix("NUM:").split(":", limit = 2).getOrNull(1) ?: return Pair("", "")
    val e = p.split("¦")
    return Pair(e.getOrElse(1) { "" }.trim(), e.getOrElse(2) { "" }.trim())
}
/** गिनती की चाबी में बंद-टेक्स्ट शामिल न हों, ताकि उन्हें बदलने पर ✅/🔴 गिनती न मिटे */
/** नंबर न मिलने पर क्लिक करने के लिए कम से कम एक टेक्स्ट लिखा हो तभी वह सुविधा चालू */
fun numCloseOn(cmd: String): Boolean { val e = numExtras(cmd); return e.first.isNotEmpty() || e.second.isNotEmpty() }
private fun numCore(cmd: String): String = cmd.removePrefix("NUM:").substringBefore("¦")
/** कमांड (GATE:/~~ हटाकर) नंबर वाली हो तो उसका रूप NUM:... लौटाओ */
fun numOfStep(st: String): String? {
    val st0 = stripLimit(st)
    val raw = if (st0.contains("~~")) st0.substringBeforeLast("~~") else st0
    val cmd = if (raw.startsWith("GATE:")) raw.removePrefix("GATE:").substringAfter(":") else raw
    return if (numParse(cmd) != null) cmd else null
}
fun numFailKey(cmd: String): String = "nf_" + numCore(cmd)
/** 🔴 वाले नंबर: नंबर → कितनी बार कोशिश में सारी कमांड सफल नहीं हुईं */
fun numFailed(sp: android.content.SharedPreferences, key: String): MutableMap<Int, Int> {
    val out = HashMap<Int, Int>()
    for (e in sp.getString(key, "")!!.split(",")) {
        val p = e.split(":")
        val n = p.getOrNull(0)?.trim()?.toIntOrNull() ?: continue
        out[n] = p.getOrNull(1)?.trim()?.toIntOrNull() ?: 1
    }
    return out
}
fun numKey(cmd: String): String = "nd_" + numCore(cmd)
fun numDone(sp: android.content.SharedPreferences, key: String): MutableSet<Int> =
    sp.getString(key, "")!!.split(",").mapNotNull { it.trim().toIntOrNull() }.toMutableSet()

private fun prettyBase(s: String): String = when {
    s.contains("|ALT|") -> {
        val v = s.split("|ALT|")
        prettyBase(v[0]) + v.drop(1).joinToString("") { "  ➜ न मिले तो: " + prettyBase(it) }
    }
    s.startsWith("NUM:") -> numParse(s)?.let { "🔢 \"${it.third}\" + नंबर (${it.first} से ${it.second})" } ?: s
    s.startsWith("SWIPE:") -> {
        val p = s.split(":", limit = 3)
        val d = when (p[1]) { "left" -> "⬅ बाएँ"; "right" -> "➡ दाएँ"; "up" -> "⬆ ऊपर"; else -> "⬇ नीचे" }
        val t = p.getOrElse(2) { "" }
        val where = when {
            t.isEmpty() -> "स्क्रीन के बीच से"
            t.startsWith("IMG:") -> "🖼 फोटो पर"
            else -> "\"$t\" पर"
        }
        "स्वाइप $d — $where"
    }
    s.startsWith("GATE:") -> "📸 स्क्रीन मिले तो → " + prettyBase(s.removePrefix("GATE:").substringAfter(":"))
    s.startsWith("IMG:opt:") -> "🖼 फोटो (वैकल्पिक)"
    s.startsWith("IMG:req:") -> "🖼 फोटो (ज़रूरी)"
    else -> s
}
