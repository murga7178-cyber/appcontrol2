package com.example.appcontrol

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.widget.*
import java.io.File

class CleanActivity : ToolPage() {
    private lateinit var res: LinearLayout

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        page("🧹 जंक / बड़ी फाइलें")
        box.addView(tv("छुपे फोल्डर समेत पूरी स्टोरेज में 100MB से बड़ी और .tmp / .log / .apk / .bak फाइलें ढूँढता है। कुछ भी अपने-आप नहीं हटता, आप खुद चुनते हैं।"))
        box.addView(btn("🔍 स्कैन शुरू करें") { scan() })
        res = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(res)
    }

    private fun scan() {
        if (Build.VERSION.SDK_INT >= 30) {
            if (!Environment.isExternalStorageManager()) {
                startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
                toast("'सभी फाइल्स' की अनुमति दें, फिर वापस आकर दोबारा स्कैन दबाएँ")
                return
            }
        } else if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            // Android 10
            requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE), 2)
            toast("स्टोरेज की अनुमति दें, फिर दोबारा स्कैन दबाएँ")
            return
        }
        res.removeAllViews()
        res.addView(tv("स्कैन हो रहा है..."))
        Thread {
            val junkExt = setOf("tmp", "temp", "log", "apk", "bak", "thumb")
            val found = ArrayList<File>()
            Environment.getExternalStorageDirectory().walkTopDown()
                .onEnter { it.name != "Android" }
                .filter { it.isFile && (it.length() > 100L * 1024 * 1024 || it.extension.lowercase() in junkExt || it.path.contains("/.thumbnails/")) }
                .forEach { found.add(it) }
            found.sortByDescending { it.length() }
            Shell.h.post { show(found.take(150)) }
        }.start()
    }

    private fun show(list: List<File>) {
        res.removeAllViews()
        res.addView(tv("${list.size} फाइलें मिलीं (छुपे फोल्डर समेत)। कुछ भी पहले से चुना नहीं है।"))
        val checks = ArrayList<Pair<CheckBox, File>>()
        list.forEach { f ->
            val cb = CheckBox(this).apply { text = "${f.name}\n${fmt(f.length())} • ${f.parent}"; textSize = 13f }
            checks.add(cb to f); res.addView(cb)
        }
        res.addView(btn("चुनी हुई फाइलें हटाएँ") {
            var freed = 0L
            checks.filter { it.first.isChecked }.forEach { (_, f) -> val s = f.length(); if (f.delete()) freed += s }
            toast("${fmt(freed)} जगह खाली हुई")
            scan()
        })
    }
}
