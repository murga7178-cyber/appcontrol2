package com.example.appcontrol

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import java.io.File
import java.io.FileOutputStream
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    private val prefs by lazy { getSharedPreferences("apps", Context.MODE_PRIVATE) }
    private lateinit var appList: ListView
    private lateinit var stepList: ListView
    private lateinit var status: TextView
    private lateinit var projLabel: TextView
    private lateinit var boostInfo: TextView
    private val shizukuListener = Shizuku.OnRequestPermissionResultListener { _, _ -> updateBoostInfo() }

    private fun updateBoostInfo() {
        boostInfo.text = when {
            Shell.rootGranted -> "⚡ बूस्ट मोड: पूरा (Root ✅)"
            Shell.shizukuReady() -> "⚡ बूस्ट मोड: पूरा (Shizuku ✅)"
            else -> "⚡ बूस्ट मोड: हल्का (Root/Shizuku नहीं जुड़ा) — 🧰 टूल्स → पावर टूल्स"
        }
    }

    override fun onDestroy() {
        try { Shizuku.removeRequestPermissionResultListener(shizukuListener) } catch (e: Throwable) {}
        super.onDestroy()
    }

    private fun savedApps(): MutableList<String> =
        prefs.getString("pkgs", "")!!.split("\n").filter { it.isNotBlank() }.toMutableList()
    private fun saveApps(l: List<String>) = prefs.edit().putString("pkgs", l.joinToString("\n")).apply()

    private fun savedSteps(): MutableList<String> =
        prefs.getString("steps", "")!!.split("\n").filter { it.isNotBlank() }.toMutableList()
    private fun saveSteps(l: List<String>) {
        val s = l.joinToString("\n")
        val e = prefs.edit().putString("steps", s)
        val cur = curProject()
        if (cur.isNotEmpty()) e.putString("p_$cur", s)   // खुला प्रोजेक्ट अपने-आप सेव होता रहता है
        e.apply()
    }

    // ---------- प्रोजेक्ट ----------
    private fun projectNames(): MutableList<String> =
        prefs.getString("pnames", "")!!.split("\n").filter { it.isNotBlank() }.toMutableList()
    private fun curProject(): String = prefs.getString("cur", "")!!
    private fun projSteps(name: String): List<String> =
        prefs.getString("p_$name", "")!!.split("\n").filter { it.isNotBlank() }

    private fun writeProject(name: String, steps: List<String>) {
        val n = projectNames(); if (name !in n) n.add(name)
        prefs.edit().putString("pnames", n.joinToString("\n"))
            .putString("p_$name", steps.joinToString("\n")).putString("cur", name).apply()
    }

    private fun loadProject(name: String) {
        prefs.edit().putString("cur", name)
            .putString("steps", projSteps(name).joinToString("\n")).apply()
        refresh()
        Toast.makeText(this, "प्रोजेक्ट खुला: $name", Toast.LENGTH_SHORT).show()
    }

    private fun askName(title: String, preset: String, onOk: (String) -> Unit) {
        val et = EditText(this).apply { hint = "प्रोजेक्ट का नाम"; setText(preset) }
        AlertDialog.Builder(this).setTitle(title).setView(et)
            .setPositiveButton("ठीक है") { _, _ ->
                val n = et.text.toString().replace("\n", " ").trim()
                if (n.isEmpty()) Toast.makeText(this, "नाम लिखें", Toast.LENGTH_SHORT).show() else onOk(n)
            }.setNegativeButton("रद्द", null).show()
    }

    /** मौजूदा कमांड इस नाम से सेव (पहले से हो तो बदल जाएगा) */
    private fun saveProjectFlow() {
        askName("प्रोजेक्ट सेव करें", curProject()) { n ->
            val doSave = { writeProject(n, savedSteps()); refresh()
                Toast.makeText(this, "सेव हुआ: $n", Toast.LENGTH_SHORT).show() }
            if (n in projectNames() && n != curProject())
                AlertDialog.Builder(this).setTitle("\"$n\" पहले से है — बदल दें?")
                    .setPositiveButton("बदलें") { _, _ -> doSave() }
                    .setNegativeButton("रद्द", null).show()
            else doSave()
        }
    }

    /** नया खाली प्रोजेक्ट; पिछला (खुला) प्रोजेक्ट पहले से सेव है */
    private fun newProjectFlow() {
        askName("नया प्रोजेक्ट", "") { n ->
            if (n in projectNames()) {
                Toast.makeText(this, "इस नाम का प्रोजेक्ट पहले से है", Toast.LENGTH_SHORT).show(); return@askName
            }
            // बिना नाम की चल रही कमांड हों तो खो न जाएँ
            if (curProject().isEmpty() && savedSteps().isNotEmpty()) {
                var k = 1; while ("बिना नाम $k" in projectNames()) k++
                writeProject("बिना नाम $k", savedSteps())
            }
            writeProject(n, emptyList())
            prefs.edit().putString("steps", "").apply()
            refresh()
        }
    }

    private fun openProjectFlow() {
        val names = projectNames()
        if (names.isEmpty()) { Toast.makeText(this, "अभी कोई प्रोजेक्ट सेव नहीं है", Toast.LENGTH_SHORT).show(); return }
        val dlg = AlertDialog.Builder(this).setTitle("प्रोजेक्ट चुनें (लंबा दबाकर हटाएँ)")
            .setItems(names.map { (if (it == curProject()) "▶ " else "") + it }.toTypedArray()) { _, i -> loadProject(names[i]) }
            .setNegativeButton("रद्द", null).create()
        dlg.show()
        dlg.listView.setOnItemLongClickListener { _, _, i, _ ->
            AlertDialog.Builder(this).setTitle("\"${names[i]}\" हटाएँ?")
                .setPositiveButton("हटाएँ") { _, _ ->
                    val l = projectNames(); l.remove(names[i])
                    val e = prefs.edit().putString("pnames", l.joinToString("\n")).remove("p_${names[i]}")
                    if (curProject() == names[i]) e.putString("cur", "")
                    e.apply(); dlg.dismiss(); refresh()
                }.setNegativeButton("रद्द", null).show()
            true
        }
    }

    private fun label(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) { pkg }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 64, 32, (170 * resources.displayMetrics.density).toInt())   // नीचे खाली जगह, ताकि आख़िर तक स्क्रॉल हो
        }
        root.addView(Button(this).apply {
            text = "Accessibility चालू करें"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        root.addView(Button(this).apply {
            text = "🧰 फोन बूस्ट / क्लीन टूल्स"
            setOnClickListener { startActivity(Intent(this@MainActivity, ToolsActivity::class.java)) }
        })
        boostInfo = TextView(this).apply { textSize = 13f; setTextColor(Color.parseColor("#2E7D32")) }
        root.addView(boostInfo)
        try { Shizuku.addRequestPermissionResultListener(shizukuListener) } catch (e: Throwable) {}

        // ---- खोजने का समय ----
        root.addView(TextView(this).apply {
            text = "हर कमांड के लिए बटन खोजने का समय (सेकंड)"; textSize = 15f; setTextColor(Color.BLACK)
        })
        val limRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        }
        val limInput = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setText(prefs.getInt("limit", 8).toString())
        }
        fun saveLimit(v: Int) {
            prefs.edit().putInt("limit", v).apply()
            limInput.setText(v.toString())
            Toast.makeText(this, "सेव: $v सेकंड", Toast.LENGTH_SHORT).show()
        }
        limRow.addView(limInput, LinearLayout.LayoutParams(0, -2, 1f))
        limRow.addView(Button(this).apply {
            text = "सेव"
            setOnClickListener {
                val v = limInput.text.toString().toIntOrNull()
                if (v == null || v < 1) Toast.makeText(this@MainActivity, "1 या उससे ज़्यादा लिखें", Toast.LENGTH_SHORT).show()
                else saveLimit(v)
            }
        })
        limRow.addView(Button(this).apply {
            text = "चुनें"
            setOnClickListener {
                val secs = intArrayOf(8, 10, 15, 20, 30, 60, 120, 240)
                val names = arrayOf("8 सेकंड", "10 सेकंड", "15 सेकंड", "20 सेकंड", "30 सेकंड", "1 मिनट", "2 मिनट", "4 मिनट")
                AlertDialog.Builder(this@MainActivity).setTitle("खोजने का समय")
                    .setItems(names) { _, i -> saveLimit(secs[i]) }.show()
            }
        })
        root.addView(limRow)
        root.addView(TextView(this).apply {
            text = "अगले ऐप पर जाते समय पिछला ऐप:"; textSize = 15f; setTextColor(Color.BLACK)
        })
        val rg = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        val modes = arrayOf("बंद न करें", "मिनिमाइज़ करके ऊपर स्वाइप से बंद करें", "App info से Force stop करें")
        modes.forEachIndexed { i, t ->
            rg.addView(RadioButton(this).apply { text = t; id = 1000 + i })
        }
        rg.check(1000 + prefs.getInt("closeMode", 1))
        rg.setOnCheckedChangeListener { _, id -> prefs.edit().putInt("closeMode", id - 1000).apply() }
        root.addView(rg)

        // ---- प्रोजेक्ट ----
        projLabel = TextView(this).apply { textSize = 16f; setTextColor(Color.parseColor("#6A1B9A")) }
        root.addView(projLabel)
        val projRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun pb(t: String, f: () -> Unit) = projRow.addView(Button(this).apply {
            text = t; textSize = 12f; setOnClickListener { f() }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        pb("💾 सेव") { saveProjectFlow() }
        pb("📂 खोलें") { openProjectFlow() }
        pb("➕ नया") { newProjectFlow() }
        root.addView(projRow)

        // ---- कमांड (स्टेप) ----
        root.addView(TextView(this).apply {
            text = "कमांड (क्रम से) — लंबा दबाकर हटाएँ"; textSize = 18f; setTextColor(Color.BLACK)
        })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val input = EditText(this).apply { hint = "बटन का टेक्स्ट, जैसे: Cancel" }
        row.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(Button(this).apply {
            text = "जोड़ें"
            setOnClickListener {
                val t = input.text.toString().trim()
                if (t.isNotEmpty()) {
                    val s = savedSteps(); s.add(t); saveSteps(s)
                    input.setText(""); refresh()
                }
            }
        })
        root.addView(row)
        if (Build.VERSION.SDK_INT < 30) {   // Android 10 के लिए
            root.addView(Button(this).apply {
                text = "स्क्रीन कैप्चर अनुमति दें (Android 10, फोटो कमांड के लिए)"
                setOnClickListener {
                    val m = getSystemService(MediaProjectionManager::class.java)
                    startActivityForResult(m.createScreenCaptureIntent(), 88)
                }
            })
        }
        root.addView(Button(this).apply {
            text = "🖼 फोटो कमांड जोड़ें (जैसे क्रॉस का फोटो)"
            setOnClickListener {
                startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }, 77)
            }
        })
        root.addView(Button(this).apply {
            text = "↔ स्वाइप / स्क्रॉल कमांड जोड़ें"
            setOnClickListener { addSwipeFlow() }
        })
        stepList = ListView(this)
        root.addView(stepList, LinearLayout.LayoutParams(-1, (240 * resources.displayMetrics.density).toInt()))

        // ---- ऐप ----
        root.addView(TextView(this).apply {
            text = "ऐप (टैप करने पर 🚀 बूस्ट होकर खुलेगा और कमांड चलेंगे)"; textSize = 18f; setTextColor(Color.BLACK)
        })
        status = TextView(this).apply {
            textSize = 15f; setTextColor(Color.parseColor("#1565C0"))
            setOnClickListener { showFailed() }
        }
        root.addView(status)
        appList = ListView(this)
        root.addView(appList, LinearLayout.LayoutParams(-1, (280 * resources.displayMetrics.density).toInt()))
        root.addView(Button(this).apply {
            text = "▶ सभी ऐप चलाएँ (अधूरे अपने-आप दोहराएँ)"
            setOnClickListener {
                val svc = ControlService.instance
                val apps = savedApps().distinct()
                if (svc == null) {
                    Toast.makeText(this@MainActivity, "पहले Accessibility चालू करें", Toast.LENGTH_LONG).show()
                } else if (apps.isNotEmpty()) {
                    // शुरू में सब 'बाकी'; पूरा होते ही हटते जाते हैं
                    prefs.edit().putString("failed", apps.joinToString("\n")).putBoolean("ran", true).apply()
                    svc.startQueue(apps, savedSteps(), true)
                }
            }
        })
        root.addView(Button(this).apply {
            text = "↻ सिर्फ़ अधूरे चलाएँ (अपने-आप दोहराएँ)"
            setOnClickListener {
                val svc = ControlService.instance
                val f = failedList().filter { it in savedApps() }.distinct()
                if (svc == null) {
                    Toast.makeText(this@MainActivity, "पहले Accessibility चालू करें", Toast.LENGTH_LONG).show()
                } else if (f.isEmpty()) {
                    Toast.makeText(this@MainActivity, "कोई अधूरा ऐप नहीं", Toast.LENGTH_SHORT).show()
                } else svc.startQueue(f, savedSteps(), true)
            }
        })
        root.addView(Button(this).apply {
            text = "+"; textSize = 28f
            setOnClickListener { showAllApps() }
        }, LinearLayout.LayoutParams(-1, -2).apply { gravity = Gravity.END })

        // पूरा पेज एक साथ स्क्रॉल होता है; दोनों लिस्ट अपनी पूरी लंबाई में दिखती हैं (कुछ छुपता नहीं)
        setContentView(ScrollView(this).apply { addView(root) })
        refresh()
    }

    private fun refresh() {
        val cur = curProject()
        projLabel.text = if (cur.isNotEmpty()) "📁 प्रोजेक्ट: $cur  (बदलाव अपने-आप सेव)"
            else "📁 प्रोजेक्ट: बिना नाम — 'सेव' दबाकर नाम दें"
        val steps = savedSteps()
        stepList.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1,
            steps.mapIndexed { i, s -> "कमांड ${i + 1}:  ${show(s)}" })
        stepList.setOnItemLongClickListener { _, _, i, _ ->
            val s = savedSteps(); s.removeAt(i); saveSteps(s); refresh(); true
        }

        val pkgs = savedApps()
        val ran = prefs.getBoolean("ran", false)
        val fs = failedList().toSet()
        appList.adapter = object : ArrayAdapter<String>(
            this, android.R.layout.simple_list_item_1, pkgs.map { label(it) }) {
            override fun getView(pos: Int, v: android.view.View?, p: android.view.ViewGroup): android.view.View {
                val t = super.getView(pos, v, p) as TextView
                val done = ran && pkgs[pos] !in fs
                t.text = (if (done) "✅ " else if (ran) "⚠ " else "") + getItem(pos)
                t.setTextColor(
                    if (done) Color.parseColor("#2E7D32")
                    else if (ran) Color.parseColor("#E65100") else Color.BLACK)
                return t
            }
        }
        appList.setOnItemClickListener { _, _, i, _ -> launch(pkgs[i]) }
        appList.setOnItemLongClickListener { _, _, i, _ ->
            val s = savedApps(); s.removeAt(i); saveApps(s); refresh(); true
        }
        fit(stepList); fit(appList)
        updateStatus()
    }

    /** लिस्ट को उसकी पूरी लंबाई दो, ताकि ScrollView में कोई आइटम छुपे नहीं */
    private fun fit(lv: ListView) {
        val a = lv.adapter ?: return
        val w = if (lv.width > 0) lv.width else resources.displayMetrics.widthPixels - 64
        var total = 0
        for (i in 0 until a.count) {
            val v = a.getView(i, null, lv)
            v.measure(android.view.View.MeasureSpec.makeMeasureSpec(w, android.view.View.MeasureSpec.AT_MOST),
                android.view.View.MeasureSpec.makeMeasureSpec(0, android.view.View.MeasureSpec.UNSPECIFIED))
            total += v.measuredHeight
        }
        val minH = (60 * resources.displayMetrics.density).toInt()
        val lp = lv.layoutParams
        lp.height = maxOf(minH, total + lv.dividerHeight * maxOf(0, a.count - 1) + 8)
        lv.layoutParams = lp
    }

    override fun onResume() { super.onResume(); refresh(); updateBoostInfo(); Shell.autoConnect { updateBoostInfo() } }

    private fun failedList(): List<String> =
        prefs.getString("failed", "")!!.split("\n").filter { it.isNotBlank() }

    private fun updateStatus() {
        val apps = savedApps().distinct()
        val f = failedList().filter { it in apps }.distinct()
        status.text = if (prefs.getBoolean("ran", false))
            "कुल ${apps.size} ऐप · पूरे ${apps.size - f.size} · अधूरे/बाकी ${f.size}  (सूची देखने के लिए दबाएँ)"
        else "कुल ${apps.size} ऐप"
    }

    private fun showFailed() {
        val apps = savedApps()
        val f = failedList().filter { it in apps }.distinct()
        AlertDialog.Builder(this)
            .setTitle("अधूरे/बाकी ऐप (${f.size})")
            .setItems(f.map { label(it) }.toTypedArray(), null)
            .setPositiveButton("ठीक है", null).show()
    }

    private fun show(s: String) = prettyStep(s)

    private var pendingSwipeDir: String? = null

    /** स्वाइप कमांड जोड़ना: दिशा -> कहाँ पर (टेक्स्ट / फोटो / स्क्रीन का बीच) */
    private fun addSwipeFlow() {
        val dirs = arrayOf("left", "right", "up", "down")
        val names = arrayOf("⬅ बाएँ (उंगली दाएँ→बाएँ)", "➡ दाएँ (उंगली बाएँ→दाएँ)",
            "⬆ ऊपर (उंगली नीचे→ऊपर)", "⬇ नीचे (उंगली ऊपर→नीचे)")
        AlertDialog.Builder(this).setTitle("स्वाइप / स्क्रॉल की दिशा")
            .setItems(names) { _, i ->
                val d = dirs[i]
                AlertDialog.Builder(this).setTitle("कहाँ पर स्वाइप करें?")
                    .setItems(arrayOf("किसी टेक्स्ट पर", "किसी फोटो पर", "स्क्रीन के बीच से")) { _, w ->
                        when (w) {
                            0 -> {
                                val et = EditText(this).apply { hint = "स्क्रीन पर लिखा टेक्स्ट, जैसे: Please" }
                                AlertDialog.Builder(this).setTitle("इस टेक्स्ट वाली जगह से स्वाइप")
                                    .setView(et)
                                    .setPositiveButton("जोड़ें") { _, _ ->
                                        val t = et.text.toString().trim()
                                        if (t.isNotEmpty()) addStep("SWIPE:$d:$t")
                                    }
                                    .setNegativeButton("रद्द", null).show()
                            }
                            1 -> {
                                pendingSwipeDir = d
                                startActivityForResult(
                                    Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }, 77)
                            }
                            else -> addStep("SWIPE:$d:")
                        }
                    }.show()
            }.show()
    }

    private fun addStep(s: String) { val l = savedSteps(); l.add(s); saveSteps(l); refresh() }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 88 && res == RESULT_OK && data != null) {
            startForegroundService(Intent(this, CaptureService::class.java)
                .putExtra("code", res).putExtra("data", data))
            return
        }
        if (req == 77 && res != RESULT_OK) { pendingSwipeDir = null; return }
        if (req != 77 || res != RESULT_OK) return
        val uri = data?.data ?: return
        val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } ?: return
        val name = "step_${System.currentTimeMillis()}.png"
        FileOutputStream(File(filesDir, name)).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        val sd = pendingSwipeDir
        if (sd != null) {            // फोटो पर स्वाइप
            pendingSwipeDir = null
            addStep("SWIPE:$sd:IMG:req:$name")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("यह फोटो स्क्रीन पर न मिले तो?")
            .setPositiveButton("खोजते रहो (ज़रूरी)") { _, _ -> addStep("IMG:req:$name") }
            .setNegativeButton("छोड़कर आगे बढ़ो (वैकल्पिक)") { _, _ -> addStep("IMG:opt:$name") }
            .show()
    }

    private fun launch(pkg: String) {
        val svc = ControlService.instance
        if (svc == null) {
            Toast.makeText(this, "पहले Accessibility चालू करें", Toast.LENGTH_LONG).show(); return
        }
        val intent = packageManager.getLaunchIntentForPackage(pkg) ?: return
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val go = { svc.startSequence(savedSteps()); startActivity(intent) }
        if (prefs.getBoolean("boostBefore", true)) Shell.boost(this, setOf(pkg)) { go() } else go()
    }

    private fun addApps(list: List<String>) {
        val s = savedApps()
        for (p in list) if (p !in s) s.add(p)
        saveApps(s); refresh()
    }

    private fun showAllApps() {
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = packageManager.queryIntentActivities(main, 0)
            .map { it.activityInfo.packageName to it.loadLabel(packageManager).toString() }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }
        val checked = BooleanArray(apps.size)
        AlertDialog.Builder(this)
            .setTitle("ऐप चुनें (कई चुन सकते हैं)")
            .setMultiChoiceItems(apps.map { it.second }.toTypedArray(), checked) { _, i, c -> checked[i] = c }
            .setPositiveButton("चुने हुए जोड़ें") { _, _ ->
                addApps(apps.filterIndexed { i, _ -> checked[i] }.map { it.first })
            }
            .setNeutralButton("सारे जोड़ें") { _, _ -> addApps(apps.map { it.first }) }
            .setNegativeButton("रद्द", null)
            .show()
    }
}
