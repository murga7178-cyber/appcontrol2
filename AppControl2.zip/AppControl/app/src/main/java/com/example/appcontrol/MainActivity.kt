package com.example.appcontrol

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import java.io.File
import java.io.FileOutputStream
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.graphics.drawable.GradientDrawable
import android.widget.*
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    companion object { var cur: MainActivity? = null }

    private val prefs by lazy { getSharedPreferences("apps", Context.MODE_PRIVATE) }
    private lateinit var appList: ListView
    private lateinit var stepList: ListView
    private lateinit var status: TextView
    private lateinit var projLabel: TextView
    private lateinit var boostInfo: TextView
    private lateinit var reviewInfo: TextView
    private lateinit var reviewBox: LinearLayout
    private val binderListener = Shizuku.OnBinderReceivedListener {
        // Shizuku बाद में चालू हो तो भी अपने-आप अनुमति माँगो और स्थिति बदलो
        runOnUiThread {
            if (!Shell.rootGranted && !Shell.shizukuReady()) try { Shizuku.requestPermission(7) } catch (e: Throwable) {}
            updateBoostInfo()
        }
    }
    private val shizukuListener = Shizuku.OnRequestPermissionResultListener { _, _ -> updateBoostInfo() }

    private fun updateBoostInfo() {
        boostInfo.text = when {
            Shell.rootGranted -> "⚡ बूस्ट मोड: पूरा (Root ✅)"
            Shell.shizukuReady() -> "⚡ बूस्ट मोड: पूरा (Shizuku ✅)"
            else -> "⚡ बूस्ट मोड: हल्का (Root/Shizuku नहीं जुड़ा) — 🧰 टूल्स → पावर टूल्स"
        }
    }

    override fun onDestroy() {
        if (cur === this) cur = null
        try { Shizuku.removeRequestPermissionResultListener(shizukuListener) } catch (e: Throwable) {}
        try { Shizuku.removeBinderReceivedListener(binderListener) } catch (e: Throwable) {}
        super.onDestroy()
    }

    private fun savedApps(): MutableList<String> =
        prefs.getString("pkgs", "")!!.split("\n").filter { it.isNotBlank() }.toMutableList()
    private fun saveApps(l: List<String>) {
        val a = l.joinToString("\n")
        val e = prefs.edit().putString("pkgs", a)
        val cur = curProject()
        if (cur.isNotEmpty()) e.putString("a_$cur", a)   // खुले प्रोजेक्ट के ऐप भी अपने-आप सेव
        e.apply()
    }

    private fun savedSteps(): MutableList<String> =
        prefs.getString("steps", "")!!.split("\n").filter { it.isNotBlank() }.toMutableList()
    private fun saveSteps(l: List<String>) {
        val s = l.joinToString("\n")
        val e = prefs.edit().putString("steps", s)
        val cur = curProject()
        if (cur.isNotEmpty()) e.putString("p_$cur", s)   // खुला प्रोजेक्ट अपने-आप सेव होता रहता है
        e.apply()
    }

    // ---------- प्रोजेक्ट ----------
    private fun projectNames(): MutableList<String> =
        prefs.getString("pnames", "")!!.split("\n").filter { it.isNotBlank() }.toMutableList()
    private fun curProject(): String = prefs.getString("cur", "")!!
    private fun projSteps(name: String): List<String> =
        prefs.getString("p_$name", "")!!.split("\n").filter { it.isNotBlank() }

    private fun writeProject(name: String, steps: List<String>, apps: List<String>) {
        val n = projectNames(); if (name !in n) n.add(name)
        prefs.edit().putString("pnames", n.joinToString("\n"))
            .putString("p_$name", steps.joinToString("\n"))
            .putString("a_$name", apps.joinToString("\n"))
            .putString("cur", name).apply()
        ProjSettings.snap(prefs, name)      // वीपीएन/वाईफाई/समय आदि सेटिंग भी इसी प्रोजेक्ट में सेव
    }

    private fun loadProject(name: String) {
        val old = curProject()
        if (old.isNotEmpty()) ProjSettings.snap(prefs, old)     // पिछले खुले प्रोजेक्ट की सेटिंग भी सुरक्षित
        val e = prefs.edit().putString("cur", name)
            .putString("steps", projSteps(name).joinToString("\n"))
        // पुराने प्रोजेक्ट (जिनमें ऐप सेव नहीं थे) में मौजूदा ऐप सूची जस की तस रहे
        if (prefs.contains("a_$name")) e.putString("pkgs", prefs.getString("a_$name", "")!!)
        e.remove("failed").putBoolean("ran", false).apply()
        val hadSettings = ProjSettings.apply(prefs, name)       // इस प्रोजेक्ट की सेव सेटिंग सामने आएँगी
        val cnt = savedApps().size
        Toast.makeText(this, "प्रोजेक्ट खुला: $name  (${savedSteps().size} कमांड, $cnt ऐप)", Toast.LENGTH_SHORT).show()
        if (hadSettings) recreate() else refresh()               // पूरा पेज नई सेटिंग से फिर बनेगा
    }

    private fun askName(title: String, preset: String, onOk: (String) -> Unit) {
        val et = EditText(this).apply { hint = "प्रोजेक्ट का नाम"; setText(preset) }
        AlertDialog.Builder(this).setTitle(title).setView(et)
            .setPositiveButton("ठीक है") { _, _ ->
                val n = et.text.toString().replace("\n", " ").trim()
                if (n.isEmpty()) Toast.makeText(this, "नाम लिखें", Toast.LENGTH_SHORT).show() else onOk(n)
            }.setNegativeButton("रद्द", null).show()
    }

    /** मौजूदा कमांड इस नाम से सेव (पहले से हो तो बदल जाएगा) */
    private fun saveProjectFlow() {
        askName("प्रोजेक्ट सेव करें", curProject()) { n ->
            val doSave = { writeProject(n, savedSteps(), savedApps()); refresh()
                Toast.makeText(this, "सेव हुआ: $n  (${savedApps().size} ऐप)", Toast.LENGTH_SHORT).show() }
            if (n in projectNames() && n != curProject())
                AlertDialog.Builder(this).setTitle("\"$n\" पहले से है — बदल दें?")
                    .setPositiveButton("बदलें") { _, _ -> doSave() }
                    .setNegativeButton("रद्द", null).show()
            else doSave()
        }
    }

    /** नया खाली प्रोजेक्ट; पिछला (खुला) प्रोजेक्ट पहले से सेव है */
    private fun newProjectFlow() {
        askName("नया प्रोजेक्ट", "") { n ->
            if (n in projectNames()) {
                Toast.makeText(this, "इस नाम का प्रोजेक्ट पहले से है", Toast.LENGTH_SHORT).show(); return@askName
            }
            // बिना नाम की चल रही कमांड हों तो खो न जाएँ
            if (curProject().isEmpty() && savedSteps().isNotEmpty()) {
                var k = 1; while ("बिना नाम $k" in projectNames()) k++
                writeProject("बिना नाम $k", savedSteps(), savedApps())
            }
            // कमांड/सेटिंग पिछली बार वाली ही रहें (बदल सकते हैं); ऐप सूची खाली
            writeProject(n, savedSteps(), emptyList())
            prefs.edit().putString("pkgs", "").remove("failed").putBoolean("ran", false).apply()
            refresh()
        }
    }

    /** प्रोजेक्ट चुनो (जिस क्रम में टैप करोगे उसी क्रम में चलेंगे) */
    private fun chooseVpnApp(done: () -> Unit) {
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = packageManager.queryIntentActivities(main, 0)
            .map { it.activityInfo.packageName to it.loadLabel(packageManager).toString() }
            .filter { it.first != packageName }.distinctBy { it.first }.sortedBy { it.second.lowercase() }
        AlertDialog.Builder(this).setTitle("अपना वीपीएन ऐप चुनें")
            .setItems(apps.map { it.second }.toTypedArray()) { _, i ->
                prefs.edit().putString("vpnPkg", apps[i].first).apply(); done()
            }
            .setNeutralButton("हटाएँ") { _, _ -> prefs.edit().remove("vpnPkg").apply(); done() }
            .setNegativeButton("रद्द", null).show()
    }

    /** सुरक्षित ऐप चुनो: ये किसी भी मोड में Recents से नहीं हटेंगे और force-stop/boost से भी बचेंगे */
    private fun chooseProtectedApps(done: () -> Unit) {
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = packageManager.queryIntentActivities(main, 0)
            .map { it.activityInfo.packageName to it.loadLabel(packageManager).toString() }
            .filter { it.first != packageName }.distinctBy { it.first }.sortedBy { it.second.lowercase() }
        val cur = prefs.getString("protectPkgs", "")!!.split("\n").filter { it.isNotBlank() }.toHashSet()
        val checked = BooleanArray(apps.size) { apps[it].first in cur }
        AlertDialog.Builder(this).setTitle("🛡 सुरक्षित ऐप चुनें")
            .setMultiChoiceItems(apps.map { it.second }.toTypedArray(), checked) { _, i, c -> checked[i] = c }
            .setPositiveButton("सेव") { _, _ ->
                val keep = apps.indices.filter { checked[it] }.map { apps[it].first }
                prefs.edit().putString("protectPkgs", keep.joinToString("\n")).apply()
                Toast.makeText(this, "सेव: ${keep.size} ऐप सुरक्षित", Toast.LENGTH_SHORT).show()
                done()
            }
            .setNeutralButton("और नाम") { _, _ ->
                // Recents के कार्ड पर ऐप का नाम अलग दिखे (जैसे पेज का टाइटल) तो वह नाम यहाँ लिखें, हर लाइन में एक
                val et = EditText(this).apply {
                    setText(prefs.getString("protectNames", ""))
                    hint = "कार्ड पर दिखने वाला नाम, हर लाइन में एक"
                    minLines = 3; gravity = Gravity.TOP
                    inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
                }
                AlertDialog.Builder(this).setTitle("कार्ड के नाम (सुरक्षित)").setView(et)
                    .setPositiveButton("सेव") { _, _ ->
                        prefs.edit().putString("protectNames", et.text.toString().trim()).apply(); done()
                    }.setNegativeButton("रद्द", null).show()
            }
            .setNegativeButton("रद्द", null).show()
    }

    private fun chainFlow() {
        if (prefs.getBoolean("vpnCycle", false) && prefs.getString("vpnPkg", "").isNullOrEmpty())
            Toast.makeText(this, "वीपीएन चालू है पर वीपीएन ऐप चुना नहीं — वीपीएन वाला हिस्सा छूट जाएगा", Toast.LENGTH_LONG).show()
        val names = projectNames()
        if (names.size < 2) { Toast.makeText(this, "कम से कम 2 प्रोजेक्ट सेव होने चाहिए", Toast.LENGTH_LONG).show(); return }
        val order = mutableListOf<String>()
        val lv = ListView(this)
        val ad = object : ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, names) {
            override fun getView(pos: Int, v: android.view.View?, p: android.view.ViewGroup): android.view.View {
                val t = super.getView(pos, v, p) as TextView
                val n = names[pos]; val k = order.indexOf(n)
                val cnt = prefs.getString("a_$n", "")!!.split("\n").count { it.isNotBlank() }
                t.text = (if (k >= 0) "${k + 1}. ✔  " else "☐  ") + n + "   ($cnt ऐप)"
                return t
            }
        }
        lv.adapter = ad
        lv.setOnItemClickListener { _, _, i, _ -> val n = names[i]; if (!order.remove(n)) order.add(n); ad.notifyDataSetChanged() }
        AlertDialog.Builder(this).setTitle("जिस क्रम में चलाना है उसी क्रम में टैप करें").setView(lv)
            .setPositiveButton("▶ चलाएँ") { _, _ ->
                val svc = ControlService.instance
                when {
                    svc == null -> Toast.makeText(this, "पहले Accessibility चालू करें", Toast.LENGTH_LONG).show()
                    order.isEmpty() -> Toast.makeText(this, "कोई प्रोजेक्ट नहीं चुना", Toast.LENGTH_SHORT).show()
                    else -> { ProjSettings.snap(prefs, curProject()); svc.startChain(order.toList()); refresh() }
                }
            }.setNegativeButton("रद्द", null).show()
    }

    private fun openProjectFlow() {
        val names = projectNames()
        if (names.isEmpty()) { Toast.makeText(this, "अभी कोई प्रोजेक्ट सेव नहीं है", Toast.LENGTH_SHORT).show(); return }
        val dlg = AlertDialog.Builder(this).setTitle("प्रोजेक्ट चुनें (लंबा दबाकर हटाएँ)")
            .setItems(names.map { (if (it == curProject()) "▶ " else "") + it }.toTypedArray()) { _, i -> loadProject(names[i]) }
            .setNegativeButton("रद्द", null).create()
        dlg.show()
        dlg.listView.setOnItemLongClickListener { _, _, i, _ ->
            AlertDialog.Builder(this).setTitle("\"${names[i]}\" हटाएँ?")
                .setPositiveButton("हटाएँ") { _, _ ->
                    val l = projectNames(); l.remove(names[i])
                    val e = prefs.edit().putString("pnames", l.joinToString("\n")).remove("p_${names[i]}")
                    if (curProject() == names[i]) e.putString("cur", "")
                    e.apply(); ProjSettings.delete(prefs, names[i]); dlg.dismiss(); refresh()
                }.setNegativeButton("रद्द", null).show()
            true
        }
    }

    private fun label(pkg: String): String = if (pkg.startsWith("home:")) "🏠 " + pkg.removePrefix("home:") else try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) { pkg }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        cur = this
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 64, 32, (170 * resources.displayMetrics.density).toInt())   // नीचे खाली जगह, ताकि आख़िर तक स्क्रॉल हो
        }
        root.addView(Button(this).apply {
            text = "Accessibility चालू करें"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        root.addView(Button(this).apply {
            text = "🧰 फोन बूस्ट / क्लीन टूल्स"
            setOnClickListener { startActivity(Intent(this@MainActivity, ToolsActivity::class.java)) }
        })
        boostInfo = TextView(this).apply { textSize = 13f; setTextColor(Color.parseColor("#2E7D32")) }
        root.addView(boostInfo)
        try { Shizuku.addRequestPermissionResultListener(shizukuListener) } catch (e: Throwable) {}
        try { Shizuku.addBinderReceivedListenerSticky(binderListener) } catch (e: Throwable) {}
        root.addView(Button(this).apply {
            text = "🔗 Shizuku जोड़ें / अनुमति दें"
            setOnClickListener { Shell.connectShizuku(this@MainActivity) { updateBoostInfo() } }
        })

        // ---- खोजने का समय ----
        root.addView(TextView(this).apply {
            text = "हर कमांड के लिए बटन खोजने का समय (सेकंड)"; textSize = 15f; setTextColor(Color.BLACK)
        })
        val limRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        }
        val limInput = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setText(prefs.getInt("limit", 8).toString())
        }
        fun saveLimit(v: Int) {
            prefs.edit().putInt("limit", v).apply()
            limInput.setText(v.toString())
            Toast.makeText(this, "सेव: $v सेकंड", Toast.LENGTH_SHORT).show()
        }
        limRow.addView(limInput, LinearLayout.LayoutParams(0, -2, 1f))
        limRow.addView(Button(this).apply {
            text = "सेव"
            setOnClickListener {
                val v = limInput.text.toString().toIntOrNull()
                if (v == null || v < 1) Toast.makeText(this@MainActivity, "1 या उससे ज़्यादा लिखें", Toast.LENGTH_SHORT).show()
                else saveLimit(v)
            }
        })
        limRow.addView(Button(this).apply {
            text = "चुनें"
            setOnClickListener {
                val secs = intArrayOf(8, 10, 15, 20, 30, 60, 120, 240)
                val names = arrayOf("8 सेकंड", "10 सेकंड", "15 सेकंड", "20 सेकंड", "30 सेकंड", "1 मिनट", "2 मिनट", "4 मिनट")
                AlertDialog.Builder(this@MainActivity).setTitle("खोजने का समय")
                    .setItems(names) { _, i -> saveLimit(secs[i]) }.show()
            }
        })
        root.addView(limRow)
        root.addView(TextView(this).apply {
            text = "अगले ऐप पर जाते समय पिछला ऐप:"; textSize = 15f; setTextColor(Color.BLACK)
        })
        val rg = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        val modes = arrayOf("बंद न करें", "मिनिमाइज़ करके ऊपर स्वाइप से बंद करें", "App info से Force stop करें")
        modes.forEachIndexed { i, t ->
            rg.addView(RadioButton(this).apply { text = t; id = 1000 + i })
        }
        rg.check(1000 + prefs.getInt("closeMode", 1))
        rg.setOnCheckedChangeListener { _, id -> prefs.edit().putInt("closeMode", id - 1000).apply() }
        root.addView(rg)
        // ---- सुरक्षित ऐप: ये Recents से कभी नहीं हटेंगे, force-stop भी नहीं होंगे ----
        val protBtn = Button(this).apply { textSize = 13f }
        fun protLabel() {
            val n = prefs.getString("protectPkgs", "")!!.split("\n").count { it.isNotBlank() }
            val m = prefs.getString("protectNames", "")!!.split("\n").count { it.isNotBlank() }
            protBtn.text = "🛡 सुरक्षित ऐप (Recents से कभी न हटें): $n ऐप" + (if (m > 0) " + $m नाम" else "")
        }
        protLabel()
        protBtn.setOnClickListener { chooseProtectedApps { protLabel() } }
        root.addView(protBtn)
        root.addView(CheckBox(this).apply {
            text = "नंबर वाली कमांड चलते समय: नंबर वाले कार्ड के साथ बाकी सारे ऐप भी Recents से हटाएँ (VPN, App Control और जुड़े ऐप नहीं हटेंगे)"
            textSize = 13f
            isChecked = prefs.getBoolean("numClearAll", false)
            setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("numClearAll", c).apply() }
        })

        // ---- प्रोजेक्ट ----
        projLabel = TextView(this).apply { textSize = 16f; setTextColor(Color.parseColor("#6A1B9A")) }
        root.addView(projLabel)
        val projRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun pb(t: String, f: () -> Unit) = projRow.addView(Button(this).apply {
            text = t; textSize = 12f; setOnClickListener { f() }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        pb("💾 सेव") { saveProjectFlow() }
        pb("📂 खोलें") { openProjectFlow() }
        pb("➕ नया") { newProjectFlow() }
        root.addView(projRow)
        root.addView(Button(this).apply {
            text = "⛓ कई प्रोजेक्ट एक के बाद एक चलाएँ"
            setOnClickListener { chainFlow() }
        })
        root.addView(CheckBox(this).apply {
            text = "प्रोजेक्ट बदलते समय वाईफाई बंद-चालू (Shizuku/Root चाहिए)"
            isChecked = prefs.getBoolean("wifiCycle", true)
            setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("wifiCycle", c).apply() }
        })
        root.addView(CheckBox(this).apply {
            text = "प्रोजेक्ट बदलते समय वीपीएन बंद-चालू (Shizuku/Root चाहिए)"
            isChecked = prefs.getBoolean("vpnCycle", false)
            setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("vpnCycle", c).apply() }
        })
        val vpnBtnView = Button(this).apply { textSize = 12f }
        fun vpnLabel() {
            val p = prefs.getString("vpnPkg", "")!!
            vpnBtnView.text = "🔒 वीपीएन ऐप: " + (if (p.isEmpty()) "चुना नहीं — दबाकर चुनें" else label(p))
        }
        vpnLabel()
        vpnBtnView.setOnClickListener { chooseVpnApp { vpnLabel() } }
        root.addView(vpnBtnView)
        fun stepBox(key: String, title: String, hintTxt: String, imgReq: Int) {
            root.addView(TextView(this).apply { text = title; textSize = 14f; setTextColor(Color.BLACK) })
            root.addView(EditText(this).apply {
                vpnBoxes[key] = this
                hint = hintTxt; minLines = 2; gravity = Gravity.TOP
                inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
                setText(prefs.getString(key, ""))
                addTextChangedListener(object : android.text.TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                    override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                    override fun afterTextChanged(e: android.text.Editable?) {
                        prefs.edit().putString(key, e.toString()).apply()
                    }
                })
            })
            root.addView(Button(this).apply {
                text = "🖼 फोटो जोड़ें (बटन का फोटो/क्रॉप किया हुआ हिस्सा)"
                textSize = 12f; isAllCaps = false
                setOnClickListener {
                    startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }, imgReq)
                }
            })
        }
        stepBox("vpnOff", "वीपीएन बंद करने के स्टेप (हर लाइन में बटन का टेक्स्ट, या IMG:फोटो — क्रम से)", "जैसे:\nDisconnect\nYes   (खाली = ऐप Force stop होगा)", 81)
        stepBox("vpnOn", "वीपीएन चालू करने के स्टेप (हर लाइन में बटन का टेक्स्ट, या IMG:फोटो — क्रम से)", "जैसे:\nConnect\nOK   (खाली = ऐप खुलते ही खुद जुड़ता है)", 82)
        stepBox("vpnCountry", "वीपीएन का देश बदलने के स्टेप (कमांड दोबारा भी छूटे तो चलेगा). पहली लाइन = नीचे जो देश लिखा है उस पर टैप (उसकी फोटो IMG: या टेक्स्ट). उसके बाद सूची में से कोई दूसरा देश अपने-आप चुना जाएगा", "जैसे:\nIMG:फोटो   (नीचे वाली देश की पट्टी)\n(खाली = देश नहीं बदलेगा)", 83)

        // ---- कमांड (स्टेप) ----
        root.addView(TextView(this).apply {
            text = "कमांड (क्रम से) — लंबा दबाकर हटाएँ"; textSize = 18f; setTextColor(Color.BLACK)
        })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val input = EditText(this).apply { hint = "बटन का टेक्स्ट, जैसे: Cancel" }
        row.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(Button(this).apply {
            text = "जोड़ें"
            setOnClickListener {
                val t = input.text.toString().trim()
                if (t.isNotEmpty()) {
                    val s = savedSteps(); s.add(t); saveSteps(s)
                    input.setText(""); refresh()
                }
            }
        })
        root.addView(row)
        if (Build.VERSION.SDK_INT < 30) {   // Android 10 के लिए
            root.addView(Button(this).apply {
                text = "स्क्रीन कैप्चर अनुमति दें (Android 10, फोटो कमांड के लिए)"
                setOnClickListener {
                    val m = getSystemService(MediaProjectionManager::class.java)
                    startActivityForResult(m.createScreenCaptureIntent(), 88)
                }
            })
        }
        root.addView(Button(this).apply {
            text = "🖼 फोटो कमांड जोड़ें (जैसे क्रॉस का फोटो)"
            setOnClickListener {
                startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }, 77)
            }
        })
        root.addView(Button(this).apply {
            text = "📸 स्क्रीनशॉट जोड़ें (स्क्रीन मिले तभी कमांड चले)"
            setOnClickListener {
                startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }, 79)
            }
        })
        root.addView(Button(this).apply {
            text = "↔ स्वाइप / स्क्रॉल कमांड जोड़ें"
            setOnClickListener { addSwipeFlow() }
        })
        stepList = ListView(this)
        root.addView(stepList, LinearLayout.LayoutParams(-1, (240 * resources.displayMetrics.density).toInt()))

        // ---- ऐप ----
        root.addView(TextView(this).apply {
            text = "ऐप (टैप करने पर 🚀 बूस्ट होकर खुलेगा और कमांड चलेंगे)"; textSize = 18f; setTextColor(Color.BLACK)
        })
        status = TextView(this).apply {
            textSize = 15f; setTextColor(Color.parseColor("#1565C0"))
            setOnClickListener { showFailed() }
        }
        root.addView(status)
        appList = ListView(this)
        root.addView(appList, LinearLayout.LayoutParams(-1, (280 * resources.displayMetrics.density).toInt()))
        // ---- रिव्यू फोटो (दोबारा चेक के लिए; सभी ऐप के लिए एक ही) ----
        reviewInfo = TextView(this).apply { textSize = 14f; setTextColor(Color.parseColor("#E65100")) }
        root.addView(reviewInfo)
        reviewBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(reviewBox)
        val revRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        revRow.addView(Button(this).apply {
            text = "✅ रिव्यू फोटो जोड़ें (कमांड नंबर के साथ)"; textSize = 12f
            setOnClickListener {
                startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }, 78)
            }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        revRow.addView(Button(this).apply {
            text = "🗑 सभी रिव्यू फोटो हटाएँ"; textSize = 12f
            setOnClickListener {
                reviewImgs().forEach { File(filesDir, it.substringAfter("|")).delete() }
                prefs.edit().remove("reviewImgs").apply(); updateReviewInfo()
            }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(revRow)
        root.addView(Button(this).apply {
            text = "▶ सभी ऐप चलाएँ (अधूरे अपने-आप दोहराएँ)"
            setOnClickListener {
                val svc = ControlService.instance
                val apps = savedApps().distinct()
                if (svc == null) {
                    Toast.makeText(this@MainActivity, "पहले Accessibility चालू करें", Toast.LENGTH_LONG).show()
                } else if (apps.isNotEmpty()) {
                    if (!prefs.getBoolean("ran", false)) {
                        // पहली बार: शुरू में सब 'बाकी'; पूरा होते ही हटते जाते हैं
                        prefs.edit().putString("failed", apps.joinToString("\n")).putBoolean("ran", true).apply()
                        svc.startQueue(apps, savedSteps(), true)
                    } else {
                        // ✔ सिर्फ़ 'रीस्टार्ट' से हटते हैं; यहाँ सिर्फ़ बाकी ऐप चलेंगे
                        val pending = failedList().filter { it in apps }.distinct()
                        if (pending.isEmpty())
                            Toast.makeText(this@MainActivity, "सारे ऐप ✔ हैं — दोबारा चलाने के लिए 🔄 रीस्टार्ट दबाएँ", Toast.LENGTH_LONG).show()
                        else svc.startQueue(pending, savedSteps(), true)
                    }
                }
            }
        })
        root.addView(Button(this).apply {
            text = "↻ सिर्फ़ अधूरे चलाएँ (अपने-आप दोहराएँ)"
            setOnClickListener {
                val svc = ControlService.instance
                val f = failedList().filter { it in savedApps() }.distinct()
                if (svc == null) {
                    Toast.makeText(this@MainActivity, "पहले Accessibility चालू करें", Toast.LENGTH_LONG).show()
                } else if (f.isEmpty()) {
                    Toast.makeText(this@MainActivity, "कोई अधूरा ऐप नहीं", Toast.LENGTH_SHORT).show()
                } else svc.startQueue(f, savedSteps(), true, true)
            }
        })
        root.addView(Button(this).apply {
            text = "🔄 रीस्टार्ट (सारे ✔ हटाकर फिर से तैयार करें)"
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("सारे ✔ हटा दें?")
                    .setMessage("सभी ऐप फिर से काम के लिए उपलब्ध हो जाएँगे।")
                    .setPositiveButton("हाँ, रीस्टार्ट") { _, _ ->
                        prefs.edit().remove("failed").putBoolean("ran", false).apply()
                        refresh()
                    }
                    .setNegativeButton("रद्द", null).show()
            }
        })
        root.addView(Button(this).apply {
            text = "⋯ और (मोर): देश, IP, रिकॉर्ड, टच-ताला, POS…"
            setOnClickListener { showMoreMenu() }
        })
        root.addView(Button(this).apply {
            text = "+"; textSize = 28f
            setOnClickListener { chooseAddMode() }
        }, LinearLayout.LayoutParams(-1, -2).apply { gravity = Gravity.END })

        // पूरा पेज एक साथ स्क्रॉल होता है; दोनों लिस्ट अपनी पूरी लंबाई में दिखती हैं (कुछ छुपता नहीं)
        styleButtons(root)
        setContentView(ScrollView(this).apply { addView(root) })
        refresh()
    }

    /** हर बटन साफ़ दिखे: रंगीन गोल पट्टी, सफ़ेद बड़े अक्षर, बटनों के बीच जगह */
    private fun styleButtons(v: View) {
        val dn = resources.displayMetrics.density
        if (v is ViewGroup) {
            for (i in 0 until v.childCount) styleButtons(v.getChildAt(i))
            return
        }
        if (v !is Button) return
        v.isAllCaps = false
        v.setTextColor(Color.WHITE)
        v.textSize = maxOf(v.textSize / resources.displayMetrics.scaledDensity, 14f)
        v.minHeight = (48 * dn).toInt()
        v.minimumHeight = (48 * dn).toInt()
        v.setPadding((10 * dn).toInt(), (8 * dn).toInt(), (10 * dn).toInt(), (8 * dn).toInt())
        v.background = GradientDrawable().apply {
            cornerRadius = 14 * dn
            setColor(Color.parseColor(if (v.text.toString().startsWith("▶")) "#2E7D32" else "#1565C0"))
        }
        (v.layoutParams as? LinearLayout.LayoutParams)?.setMargins((3 * dn).toInt(), (5 * dn).toInt(), (3 * dn).toInt(), (5 * dn).toInt())
    }

    private fun reviewImgs(): MutableList<String> =
        prefs.getString("reviewImgs", "")!!.split("\n").filter { it.isNotBlank() }.toMutableList()

    private fun updateReviewInfo() {
        val l = reviewImgs()
        reviewInfo.text = if (l.isEmpty()) "रिव्यू फोटो: कोई नहीं"
            else "रिव्यू फोटो: ${l.size} (दोबारा चेक में सिर्फ़ उसी कमांड नंबर पर खोजी जाएगी · हटाने के लिए दबाएँ)"
        reviewBox.removeAllViews()
        val d = resources.displayMetrics.density
        for (line in l) {
            val num = line.substringBefore("|", "0")
            val name = line.substringAfter("|")
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(0, (4 * d).toInt(), 0, (4 * d).toInt())
                setOnClickListener {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("यह रिव्यू फोटो हटाएँ?")
                        .setPositiveButton("हटाएँ") { _, _ ->
                            File(filesDir, name).delete()
                            val r = reviewImgs(); r.remove(line)
                            prefs.edit().putString("reviewImgs", r.joinToString("\n")).apply()
                            updateReviewInfo()
                        }
                        .setNegativeButton("रहने दें", null).show()
                }
            }
            val bmp = try { BitmapFactory.decodeFile(File(filesDir, name).path) } catch (e: Throwable) { null }
            row.addView(ImageView(this).apply { bmp?.let { setImageBitmap(it) }; adjustViewBounds = true; scaleType = ImageView.ScaleType.FIT_CENTER },
                LinearLayout.LayoutParams((64 * d).toInt(), (64 * d).toInt()))
            row.addView(TextView(this).apply {
                text = if (num == "0") "  हर कमांड पर" else "  कमांड $num पर काम करेगी"
                textSize = 15f; setTextColor(Color.BLACK)
            })
            reviewBox.addView(row)
        }
    }

    /** रिव्यू फोटो किस कमांड नंबर पर खोजी जाए, यह पूछो */
    private fun failPrefLines(): MutableList<String> =
        prefs.getString("failText", "")!!.split("\n").filter { it.isNotBlank() }.toMutableList()

    /** कमांड चुनो, फिर उसके क्लिक के बाद स्क्रीन पर आने वाले "गलती के संदेश" लिखो (हर लाइन एक) */
    private fun askFailCommand() {
        val steps = savedSteps()
        if (steps.isEmpty()) { Toast.makeText(this, "पहले कमांड जोड़ें", Toast.LENGTH_LONG).show(); return }
        val items = steps.mapIndexed { i, st -> "कमांड ${i + 1}:  ${show(st)}" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("किस कमांड के क्लिक के बाद संदेश देखना है?")
            .setItems(items) { _, i ->
                val n = i + 1
                val old = failPrefLines().firstOrNull { it.substringBefore("|") == n.toString() }?.substringAfter("|")?.split("¦")?.joinToString("\n") ?: ""
                val e = EditText(this).apply {
                    hint = "जैसे:\nCheck-in failed\n(हर लाइन में एक संदेश, स्क्रीन पर जैसा लिखा आता है हू-ब-हू)"
                    minLines = 3; gravity = Gravity.TOP; setText(old)
                    inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
                }
                val col = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL; setPadding(48, 16, 48, 0)
                    addView(TextView(this@MainActivity).apply {
                        text = "कमांड $n क्लिक होते ही करीब 4 सेकंड स्क्रीन देखी जाएगी (बीच में आने वाला संदेश/टोस्ट भी). इनमें से कोई भी संदेश दिखा तो वह कॉपी ❌ क्रॉस मानी जाएगी, रिव्यू फोटो नहीं खोजी जाएगी, और सीधे अगला खुलेगा. सिर्फ़ तब चलता है जब किसी कमांड पर गिनती (नंबर) वाला काम चालू हो. खाली छोड़कर सेव करो तो हट जाएगा."
                        textSize = 13f
                    })
                    addView(e)
                }
                AlertDialog.Builder(this).setTitle("⚠ गलती का संदेश (कमांड $n)").setView(col)
                    .setPositiveButton("सेव") { _, _ ->
                        val t = e.text.toString().split("\n").map { it.trim().replace("¦", " ").replace("|", " ") }.filter { it.isNotEmpty() }
                        val l = failPrefLines().filter { it.substringBefore("|") != n.toString() }.toMutableList()
                        if (t.isNotEmpty()) l.add("$n|" + t.joinToString("¦"))
                        prefs.edit().putString("failText", l.joinToString("\n")).apply()
                        Toast.makeText(this, if (t.isEmpty()) "कमांड $n से हटा दिया" else "सेव हुआ", Toast.LENGTH_SHORT).show()
                    }.setNegativeButton("रद्द", null).show()
            }
            .setNegativeButton("रद्द", null).show()
    }

    /** "और" की सूची: कम काम आने वाली चीज़ें एक जगह, मुख्य स्क्रीन साफ़ */
    private fun showMoreMenu() {
        val ev = IpLog.threshold(this)
        val items = arrayOf(
            "🌍 देश के नाम (${prefs.getString("vpnCountryNames", "")!!.split("\n").count { it.isNotBlank() }})",
            "🌐 नया IP: सेटिंग",
            "📋 IP रिकॉर्ड (${IpLog.recs(this).size} IP)",
            "⚙ रिव्यू से पहले चलाएँ (टेक्स्ट / क्रॉस / फोटो)",
            "⚠ गलती का संदेश आए तो ❌",
            "🔒 टच-ताला: ${if (prefs.getBoolean("touchLock", true)) "चालू" else "बंद"}",
            "📺 ऐड गार्ड: ${if (prefs.getBoolean("adGuard", true)) "चालू" else "बंद"}",
            "👆 उँगली और स्टेटस पट्टी: ${if (prefs.getBoolean("showFinger", true)) "चालू" else "बंद"}",
            "📍 POS बनाओ (X, Y डालकर)"
        )
        AlertDialog.Builder(this).setTitle("⋯ और").setItems(items) { _, i ->
            when (i) {
                0 -> showCountriesDialog()
                1 -> showIpSettings()
                2 -> showIpRecord()
                3 -> askPreCommand()
                4 -> askFailCommand()
                5 -> showTouchLock()
                6 -> showAdGuard()
                7 -> showFx()
                8 -> showPosCalc()
            }
        }.setNegativeButton("बंद", null).show()
    }

    private fun simpleWatcher(onChange: (String) -> Unit) = object : android.text.TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        override fun afterTextChanged(e: android.text.Editable?) { onChange(e.toString()) }
    }

    /** देश के नाम: एक क्लिक पर सब दिखें, वहीं बदलो */
    private fun showCountriesDialog() {
        val e = EditText(this).apply {
            hint = "जैसे:\nIndia\nUnited States\nGermany"
            minLines = 6; gravity = Gravity.TOP
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
            setText(prefs.getString("vpnCountryNames", ""))
            addTextChangedListener(simpleWatcher { prefs.edit().putString("vpnCountryNames", it).apply() })
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(48, 16, 48, 0)
            addView(TextView(this@MainActivity).apply {
                text = "हर लाइन में एक देश, स्क्रीन पर जैसा लिखा है हू-ब-हू वैसा. देश बदलते समय सूची में इनमें से जो मिलेगा वही चुना जाएगा (पहले हर देश पर एक-एक कोशिश, फिर दूसरा चक्कर); सूची में नीचे स्क्रॉल करके भी खोजेगा. खाली हो तो कोई भी देश."
                textSize = 13f
            })
            addView(e)
        }
        AlertDialog.Builder(this).setTitle("🌍 देश के नाम").setView(ScrollView(this).apply { addView(col) })
            .setPositiveButton("ठीक है", null).show()
    }

    /** नया IP की सेटिंग */
    private fun showIpSettings() {
        val cb = CheckBox(this).apply {
            text = "क्रॉस (❌) आने पर नया IP लो, और शुरू में VPN जोड़कर IP पढ़ो (वीपीएन ऐप और चालू/बंद के स्टेप भरे होने चाहिए)"
            isChecked = prefs.getBoolean("ipOn", false)
            setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("ipOn", c).apply() }
        }
        val seek = CheckBox(this).apply {
            text = "जब बचे सारे नंबर किसी दूसरे IP से जुड़े हों, तो पहले वे पुराने IP खोजो (5 कोशिश तक; न मिले तो इसी IP पर चलाओ). बंद रखो तो नंबर बिना IP देखे चलेंगे"
            isChecked = prefs.getBoolean("ipSeek", true)
            setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("ipSeek", c).apply() }
        }
        val every = EditText(this).apply {
            hint = "एक IP पर कम से कम कितनी कॉपी (डिफ़ॉल्ट 20)"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setText(prefs.getInt("ipEvery", 20).toString())
            addTextChangedListener(simpleWatcher { prefs.edit().putInt("ipEvery", it.trim().toIntOrNull()?.coerceAtLeast(1) ?: 20).apply() })
        }
        val word = EditText(this).apply {
            hint = "नीचे वाले IP के पास लिखा शब्द, जैसे from (खाली = सबसे नीचे वाला IP)"
            setText(prefs.getString("ipWord", ""))
            addTextChangedListener(simpleWatcher { prefs.edit().putString("ipWord", it.trim()).apply() })
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(48, 16, 48, 0)
            addView(TextView(this@MainActivity).apply {
                text = "VPN ऐप में ऊपर असली IP और नीचे VPN वाला IP दिखता है; सिर्फ़ नीचे वाला देखा जाएगा. IP सिर्फ़ क्रॉस (लगातार 2) आने पर बदलता है. कम से कम गिनती: इतनी या ज़्यादा कॉपी जिस IP पर चल जाएँ वह 24 घंटे दोबारा नहीं लिया जाता (चलने की कोई ऊपरी सीमा नहीं)."
                textSize = 13f
            })
            addView(cb); addView(seek); addView(every); addView(word)
        }
        AlertDialog.Builder(this).setTitle("🌐 नया IP").setView(ScrollView(this).apply { addView(col) })
            .setPositiveButton("ठीक है", null).show()
    }

    private fun showAdGuard() {
        val on = CheckBox(this).apply {
            text = "कमांड खोजते समय ऐड आए तो अपने-आप संभालो: ऐड को चलने दो, रुकने पर क्रॉस / स्किप / बैक / Escape से बंद करो"
            isChecked = prefs.getBoolean("adGuard", true)
            setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("adGuard", c).apply() }
        }
        val full = CheckBox(this).apply {
            text = "ऐड पूरा चलने दो (बंद करने पर: क्रॉस/स्किप बटन दिखते ही दबा दो)"
            isChecked = prefs.getBoolean("adPlayFully", true)
            setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("adPlayFully", c).apply() }
        }
        val note = TextView(this).apply {
            text = "Escape कुंजी सिर्फ़ तब जाती है जब Root/Shizuku जुड़ा हो, वरना उसकी जगह बैक दबता है. ऐड बंद न हो तो पेज के सारे बटन (पीछे वाले भी), बैक, Escape और ऐड पर टैप बार-बार आज़माता है; ~80 कोशिश के बाद ही आगे बढ़ता है."
            textSize = 12f
        }
        AlertDialog.Builder(this).setTitle("📺 ऐड गार्ड")
            .setView(LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 24, 48, 0); addView(on); addView(full); addView(note) })
            .setPositiveButton("ठीक है", null).show()
    }

    private fun showFx() {
        val a = CheckBox(this).apply {
            text = "👆 जहाँ क्लिक/टैप/स्वाइप हो वहाँ स्क्रीन पर उँगली चले और लहर दिखे"
            isChecked = prefs.getBoolean("showFinger", true)
            setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("showFinger", c).apply() }
        }
        val b = CheckBox(this).apply {
            text = "💭 नीचे छोटी पट्टी: स्क्रीन क्या पढ़ी, कौन सी कमांड खोज रहा है, क्या मिला, आगे क्या करेगा"
            isChecked = prefs.getBoolean("showThink", true)
            setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("showThink", c).apply() }
        }
        val note = TextView(this).apply {
            text = "ये सिर्फ़ दिखाने के लिए हैं, छूने पर कुछ नहीं होता. फोटो-मिलान वाली कमांड में दिक्कत लगे तो उँगली बंद करके देखें."
            textSize = 12f
        }
        AlertDialog.Builder(this).setTitle("👆 उँगली और स्टेटस")
            .setView(LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 24, 48, 0); addView(a); addView(b); addView(note) })
            .setPositiveButton("ठीक है", null).show()
    }

    private fun showTouchLock() {
        val cb = CheckBox(this).apply {
            text = "कमांड चलते समय कोई भी टच (उंगली या भूतिया) काम न करे. सिर्फ़ ऊपर का 'रोकें' बटन चलेगा"
            isChecked = prefs.getBoolean("touchLock", true)
            setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("touchLock", c).apply() }
        }
        AlertDialog.Builder(this).setTitle("🔒 टच-ताला").setView(LinearLayout(this).apply { setPadding(48, 24, 48, 0); addView(cb) })
            .setPositiveButton("ठीक है", null).show()
    }

    /** IP रिकॉर्ड: देशों की सूची → देश पर दबाओ तो उसके सारे IP (एक के नीचे एक) और हर IP पर चले नंबर */
    private fun showIpRecord() {
        val recs = IpLog.recs(this).associateBy { it.ip }
        val ev = IpLog.threshold(this)
        val cmap = IpNum.countryMap(this)
        val ips = (recs.keys + IpNum.allIps(this)).distinct()
        val byCountry = ips.groupBy { cmap[it] ?: "" }
        val names = byCountry.keys.sortedWith(compareBy({ it.isEmpty() }, { it }))
        val labels = names.map { c ->
            val list = byCountry[c]!!
            val nums = list.sumOf { IpNum.numbersFor(this, it).size }
            val f = if (c.isEmpty()) 0 else IpLog.countryFails(this, c)
            "🌍 ${if (c.isEmpty()) "(देश पता नहीं)" else c}  ·  ${list.size} IP  ·  $nums नंबर" + (if (f > 0) "  ·  असफल $f/${IpLog.MAX_TRIES}" else "")
        }.toMutableList()
        if (names.isEmpty()) labels.add("(अभी कोई रिकॉर्ड नहीं)")
        AlertDialog.Builder(this).setTitle("📋 IP रिकॉर्ड (देश पर दबाओ)")
            .setItems(labels.toTypedArray()) { _, i ->
                val c = names.getOrNull(i) ?: return@setItems
                val list = byCountry[c]!!
                val fmt = java.text.SimpleDateFormat("dd/MM HH:mm", java.util.Locale.getDefault())
                val sb = StringBuilder()
                list.forEachIndexed { k, ip ->
                    if (k > 0) sb.append("\n\n———————————\n\n")
                    sb.append("IP: ").append(ip).append("\n")
                    val r = recs[ip]
                    if (r != null) {
                        sb.append("कॉपी: ").append(if (r.copies > 9000) "पूरी" else "${r.copies}/$ev").append("  ·  फेल: ${r.fails}/${IpLog.MAX_TRIES}\n")
                        sb.append(if (IpLog.isBlockedRec(this, r)) "🚫 अभी बंद (24 घंटे में नई गिनती)" else "✔ अभी चल सकता है").append("   (पहली बार ${fmt.format(java.util.Date(r.first))})\n")
                    }
                    val es = IpNum.entriesFor(this, ip)
                    sb.append("इस IP पर चले नंबर (✅ हरा = हो चुका, 🔴 = क्रॉस):\n")
                    if (es.isEmpty()) sb.append("(कोई नहीं)")
                    else sb.append(es.joinToString("   ") { (key, n) ->
                        val done = numDone(prefs, key)
                        val failed = numFailed(prefs, "nf_" + key.removePrefix("nd_"))
                        when { n in done -> "$n ✅"; (failed[n] ?: 0) in 1..98 -> "$n 🔴"; else -> "$n" }
                    })
                }
                val col = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL; setPadding(48, 24, 48, 8)
                    addView(TextView(this@MainActivity).apply { textSize = 14f; setTextColor(Color.parseColor("#263238")); setTextIsSelectable(true); text = sb.toString() })
                    addView(TextView(this@MainActivity).apply {
                        textSize = 12f; setTextColor(Color.parseColor("#546E7A")); setPadding(0, 24, 0, 0)
                        text = "यही देश जुड़े और यही (या इसी देश का कोई) IP आए तो ये नंबर पहले चलेंगे. यहाँ गलत संदेश/क्रॉस आए तो नंबर किसी दूसरे देश पर चलेगा और वहीं दर्ज होगा."
                    })
                }
                AlertDialog.Builder(this).setTitle("🌍 ${if (c.isEmpty()) "(देश पता नहीं)" else c}").setView(ScrollView(this).apply { addView(col) })
                    .setPositiveButton("ठीक है", null).show()
            }
            .setPositiveButton("बंद", null)
            .setNeutralButton("🗑 खाली करें") { _, _ ->
                AlertDialog.Builder(this).setTitle("सारा IP रिकॉर्ड हटाएँ?")
                    .setMessage("IP, देश-वार गिनती और IP/देश पर चले नंबर, सब मिट जाएँगे.")
                    .setPositiveButton("हटाओ") { _, _ -> IpLog.clear(this); prefs.edit().putInt("ipCount", 0).apply(); Toast.makeText(this, "हटा दिया", Toast.LENGTH_SHORT).show() }
                    .setNegativeButton("रद्द", null).show()
            }
            .show()
    }

    private var preEdit1: EditText? = null
    private var preEdit2: EditText? = null

    /** रिव्यू फोटो जाँचने से पहले कौन-से टेक्स्ट/फोटो चलें: कमांड चुनो, फिर दो खाने भरो */
    private fun askPreCommand() {
        val steps = savedSteps()
        if (steps.isEmpty()) { Toast.makeText(this, "पहले कमांड जोड़ें", Toast.LENGTH_LONG).show(); return }
        val items = steps.mapIndexed { i, st -> "कमांड ${i + 1}:  ${show(st)}" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("किस कमांड की रिव्यू जाँच से पहले?")
            .setItems(items) { _, i -> showPreDialog(i + 1) }
            .setNegativeButton("रद्द", null).show()
    }

    private fun prePrefLines(): MutableList<String> =
        prefs.getString("reviewPre", "")!!.split("\n").filter { it.isNotBlank() }.toMutableList()

    private fun showPreDialog(n: Int) {
        val old = prePrefLines().firstOrNull { it.substringBefore("|") == n.toString() }?.substringAfter("|")?.split("¦") ?: emptyList()
        fun row(hint: String, v: String, req: Int): Pair<EditText, LinearLayout> {
            val e = EditText(this).apply { this.hint = hint; setText(v) }
            val b = Button(this).apply {
                text = "🖼 फोटो"; textSize = 12f
                setOnClickListener { startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }, req) }
            }
            val l = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            l.addView(e, LinearLayout.LayoutParams(0, -2, 1f)); l.addView(b)
            return Pair(e, l)
        }
        val (e1, r1) = row("पहला: टेक्स्ट / x (क्रॉस) / POS:50,68 / फोटो", old.getOrElse(0) { "" }, 84)
        val (e2, r2) = row("दूसरा (खाली छोड़ सकते हो)", old.getOrElse(1) { "" }, 85)
        preEdit1 = e1; preEdit2 = e2
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(48, 16, 48, 0)
            addView(TextView(this@MainActivity).apply {
                text = "कमांड $n की रिव्यू फोटो जाँचने से पहले ये चलेंगे (पहला, फिर दूसरा). जैसे कमांड में टेक्स्ट खोजकर क्लिक होता है वैसे ही. 'x' लिखो तो ×/क्रॉस वाला बटन दबेगा. दोनों खाली हों तो सीधे रिव्यू ही जाँचेगा."
                textSize = 13f
            })
            addView(r1); addView(r2)
        }
        AlertDialog.Builder(this).setTitle("⚙ रिव्यू से पहले (कमांड $n)").setView(col)
            .setPositiveButton("सेव") { _, _ ->
                fun clean(t: String) = cmdClean(t).replace("¦", " ")
                val a = clean(e1.text.toString()); val b = clean(e2.text.toString())
                val l = prePrefLines().filter { it.substringBefore("|") != n.toString() }.toMutableList()
                if (a.isNotEmpty() || b.isNotEmpty()) l.add("$n|$a¦$b")
                prefs.edit().putString("reviewPre", l.joinToString("\n")).apply()
                Toast.makeText(this, if (a.isEmpty() && b.isEmpty()) "कमांड $n से हटा दिया" else "सेव हुआ", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("रद्द", null).show()
    }

    private fun askReviewCommand(name: String) {
        val steps = savedSteps()
        if (steps.isEmpty()) {
            File(filesDir, name).delete()
            Toast.makeText(this, "पहले कमांड जोड़ें, फिर रिव्यू फोटो", Toast.LENGTH_LONG).show(); return
        }
        val items = steps.mapIndexed { i, st -> "कमांड ${i + 1}:  ${show(st)}" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("यह रिव्यू फोटो किस कमांड पर देखनी है?")
            .setItems(items) { _, i ->
                val l = reviewImgs(); l.add("${i + 1}|$name")
                prefs.edit().putString("reviewImgs", l.joinToString("\n")).apply()
                updateReviewInfo()
            }
            .setNegativeButton("रद्द") { _, _ -> File(filesDir, name).delete() }
            .setOnCancelListener { File(filesDir, name).delete() }
            .show()
    }

    private fun refresh() {
        updateReviewInfo()
        val cur = curProject()
        projLabel.text = if (cur.isNotEmpty()) "📁 प्रोजेक्ट: $cur  (बदलाव अपने-आप सेव)"
            else "📁 प्रोजेक्ट: बिना नाम — 'सेव' दबाकर नाम दें"
        val steps = savedSteps()
        val stepTexts = steps.mapIndexed { i, s -> "कमांड ${i + 1}:  ${show(s)}" }
        val dn = resources.displayMetrics.density
        stepList.adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, stepTexts) {
            override fun getView(pos: Int, v: android.view.View?, p: android.view.ViewGroup): android.view.View {
                val t = super.getView(pos, v, p) as TextView
                t.text = getItem(pos)
                t.textSize = 16f
                t.setTextColor(numColor(steps.getOrNull(pos) ?: "") ?: Color.parseColor("#0D1B2A"))
                t.setPadding((12 * dn).toInt(), (12 * dn).toInt(), (12 * dn).toInt(), (12 * dn).toInt())
                t.minHeight = (52 * dn).toInt()
                t.setBackgroundColor(Color.parseColor(if (pos % 2 == 0) "#E8F0FE" else "#F6F9FF"))
                return t
            }
        }
        stepList.setOnItemClickListener { _, _, i, _ -> editStepFlow(i) }
        stepList.setOnItemLongClickListener { _, _, i, _ ->
            val s = savedSteps(); s.removeAt(i); saveSteps(s); refresh(); true
        }

        val pkgs = savedApps()
        val ran = prefs.getBoolean("ran", false)
        val fs = failedList().toSet()
        appList.adapter = object : ArrayAdapter<String>(
            this, android.R.layout.simple_list_item_1, pkgs.map { label(it) }) {
            override fun getView(pos: Int, v: android.view.View?, p: android.view.ViewGroup): android.view.View {
                val t = super.getView(pos, v, p) as TextView
                val done = ran && pkgs[pos] !in fs
                t.text = (if (done) "✅ " else if (ran) "⚠ " else "") + getItem(pos)
                t.setTextColor(
                    if (done) Color.parseColor("#2E7D32")
                    else if (ran) Color.parseColor("#E65100") else Color.BLACK)
                t.textSize = 16f
                val dn2 = resources.displayMetrics.density
                t.setPadding((12 * dn2).toInt(), (10 * dn2).toInt(), (12 * dn2).toInt(), (10 * dn2).toInt())
                t.minHeight = (48 * dn2).toInt()
                t.setBackgroundColor(Color.parseColor(if (pos % 2 == 0) "#F5F5F5" else "#FFFFFF"))
                return t
            }
        }
        appList.setOnItemClickListener { _, _, i, _ -> launch(pkgs[i]) }
        appList.setOnItemLongClickListener { _, _, i, _ ->
            val s = savedApps(); s.removeAt(i); saveApps(s); refresh(); true
        }
        fit(stepList); fit(appList)
        updateStatus()
    }

    /** लिस्ट को उसकी पूरी लंबाई दो, ताकि ScrollView में कोई आइटम छुपे नहीं */
    private fun fit(lv: ListView) {
        val a = lv.adapter ?: return
        val w = if (lv.width > 0) lv.width else resources.displayMetrics.widthPixels - 64
        var total = 0
        for (i in 0 until a.count) {
            val v = a.getView(i, null, lv)
            v.measure(android.view.View.MeasureSpec.makeMeasureSpec(w, android.view.View.MeasureSpec.AT_MOST),
                android.view.View.MeasureSpec.makeMeasureSpec(0, android.view.View.MeasureSpec.UNSPECIFIED))
            total += v.measuredHeight
        }
        val minH = (60 * resources.displayMetrics.density).toInt()
        val lp = lv.layoutParams
        lp.height = maxOf(minH, total + lv.dividerHeight * maxOf(0, a.count - 1) + 8)
        lv.layoutParams = lp
    }

    override fun onPause() {
        super.onPause()
        ProjSettings.snap(prefs, curProject())       // खुले प्रोजेक्ट की सेटिंग अपने-आप सेव
    }

    override fun onResume() {
        super.onResume(); refresh(); updateBoostInfo(); Shell.autoConnect { updateBoostInfo() }
        val m = prefs.getString("stopMsg", "") ?: ""
        if (m.isNotEmpty()) {
            prefs.edit().remove("stopMsg").apply()
            AlertDialog.Builder(this).setTitle("⚠ प्रोजेक्ट रुका").setMessage(m).setPositiveButton("ठीक है", null).show()
        }
        // ग्रिड से कॉपी खोलकर लौटे: वही नंबर की स्थिति वाली सूची (उसी पेज पर, अब ✅ हरे के साथ) फिर खुली दिखे
        val pc = pendingGridCmd
        if (pc != null && !pendingGridWaitSvc()) {
            pendingGridCmd = null
            showNumGrid(pc, pendingGridFrom)
        }
    }

    private var pendingGridCmd: String? = null
    private var pendingGridFrom: Int? = null
    /** सेवा अभी "कॉपी खोलो" रन चला रही हो तो रुको (उसके खत्म होने पर ही सूची दिखाओ) */
    private fun pendingGridWaitSvc(): Boolean = ControlService.instance?.isRunningNow() == true

    private fun failedList(): List<String> =
        prefs.getString("failed", "")!!.split("\n").filter { it.isNotBlank() }

    private fun updateStatus() {
        val apps = savedApps().distinct()
        val f = failedList().filter { it in apps }.distinct()
        status.text = if (prefs.getBoolean("ran", false))
            "कुल ${apps.size} ऐप · पूरे ${apps.size - f.size} · अधूरे/बाकी ${f.size}  (सूची देखने के लिए दबाएँ)"
        else "कुल ${apps.size} ऐप"
    }

    private fun showFailed() {
        val apps = savedApps()
        val f = failedList().filter { it in apps }.distinct()
        AlertDialog.Builder(this)
            .setTitle("अधूरे/बाकी ऐप (${f.size})")
            .setItems(f.map { label(it) }.toTypedArray(), null)
            .setPositiveButton("ठीक है", null).show()
    }

    /** नंबर वाली कमांड का रंग: सारे पूरे = हरा, कोई 🔴 बचा = लाल, कुछ ✅ हुए = गहरा हरा; बाकी सामान्य */
    private fun numColor(s: String): Int? {
        val c = numOfStep(s) ?: return null
        val p = numParse(c) ?: return null
        val dn = numDone(prefs, numKey(c)); val d = dn.count { it in p.first..p.second }
        val r = numFailed(prefs, numFailKey(c)).count { it.key !in dn && it.value < 99 }     // 99 = कॉपी है ही नहीं → लाल नहीं गिनना
        return when {
            d >= p.second - p.first + 1 -> Color.parseColor("#2E7D32")
            r > 0 -> Color.parseColor("#C62828")
            d > 0 -> Color.parseColor("#388E3C")
            else -> null
        }
    }

    /** हर नंबर का रंग: हरा ✅ = सारी कमांड सफल, लाल 🔴 = कुछ कमांड फेल (दोबारा होगा), धूसर = अभी बाकी */
    private fun showNumGrid(cmd: String, start: Int? = null) {
        val p = numParse(cmd) ?: return
        val dn = numDone(prefs, numKey(cmd))
        val fl = numFailed(prefs, numFailKey(cmd))
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(8), dp(10), dp(8)) }
        val nDone = dn.count { it in p.first..p.second }
        val nFail = fl.count { it.key !in dn && it.value < 99 }
        val nMiss = fl.count { it.key !in dn && it.value >= 99 && it.key in p.first..p.second }     // कॉपी है ही नहीं
        col.addView(TextView(this).apply {
            text = "\"${p.third}\"   ✅ $nDone   🔴 $nFail   ⬜ ${p.second - p.first + 1 - nDone - nFail - nMiss}"
            textSize = 15f; setPadding(0, 0, 0, dp(8))
        })
        val grid = android.widget.GridLayout(this).apply { columnCount = 5 }
        var gridDlg: AlertDialog? = null
        val from = start ?: p.first
        val to = minOf(p.second.toLong(), from.toLong() + 499L).toInt()      // एक बार में 500 नंबर (हज़ारों हों तो पन्ने)
        for (n in from..to) {
            val st = when { n in dn -> 2; (fl[n] ?: 0) >= 99 -> 3; fl.containsKey(n) -> 1; else -> 0 }   // 3 = कॉपी है ही नहीं → सफ़ेद
            grid.addView(TextView(this).apply {
                text = if (st == 2) "$n ✔" else if (st == 1) "$n ✖" else "$n"
                textSize = 13f; gravity = Gravity.CENTER
                setTextColor(if (st == 0 || st == 3) Color.parseColor(if (st == 3) "#B0BEC5" else "#37474F") else Color.WHITE)
                setBackgroundColor(Color.parseColor(when (st) { 2 -> "#2E7D32"; 1 -> "#C62828"; 3 -> "#FFFFFF"; else -> "#ECEFF1" }))
                setPadding(dp(4), dp(8), dp(4), dp(8))
                if (st == 3) setOnClickListener {
                    Toast.makeText(this@MainActivity, "कॉपी $n ऐप में है ही नहीं — इसलिए नहीं खुलेगी", Toast.LENGTH_SHORT).show()
                }
                if (st == 1 || st == 0) setOnClickListener {            // 🔴 या बिना निशान वाले नंबर पर दबाओ: सीधे वही कॉपी खोज-कर खोलो (पूछे बिना)
                    val svc = ControlService.instance
                    val a = savedApps().distinct()
                    if (svc == null) Toast.makeText(this@MainActivity, "पहले Accessibility चालू करें", Toast.LENGTH_LONG).show()
                    else if (a.isEmpty()) Toast.makeText(this@MainActivity, "पहले ऐप जोड़ें", Toast.LENGTH_LONG).show()
                    else { pendingGridCmd = cmd; pendingGridFrom = from; gridDlg?.dismiss(); svc.startNumOnly(cmd, n, a, savedSteps()) }
                }
            }, android.widget.GridLayout.LayoutParams().apply {
                width = (resources.displayMetrics.widthPixels - dp(118)) / 5        // डायलॉग की चौड़ाई के भीतर पाँचों कॉलम पूरे दिखें
                setMargins(dp(2), dp(2), dp(2), dp(2))
            })
        }
        col.addView(grid)
        col.addView(Button(this).apply {
            text = "🔄 गिनती रीसेट (सब हरा/लाल/सफ़ेद हटाओ)"
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity).setTitle("गिनती रीसेट?")
                    .setMessage("इस कमांड के सारे ✅ हरे, 🔴 लाल और सफ़ेद निशान हट जाएँगे, और नंबरों का IP/देश से जुड़ाव भी मिट जाएगा. फिर सब नए सिरे से चलेंगे.")
                    .setPositiveButton("रीसेट") { _, _ ->
                        prefs.edit().remove(numKey(cmd)).remove(numFailKey(cmd)).putInt("ipCount", 0).apply()
                        IpNum.clearKey(this@MainActivity, numKey(cmd))
                        Toast.makeText(this@MainActivity, "गिनती रीसेट हो गई", Toast.LENGTH_SHORT).show()
                        gridDlg?.dismiss(); showNumGrid(cmd, start)
                    }.setNegativeButton("रद्द", null).show()
            }
        })
        gridDlg = AlertDialog.Builder(this).setTitle("नंबर की स्थिति (दबाओ = कॉपी खोलो)")
            .setView(ScrollView(this).apply { addView(col) })
            .setPositiveButton("बंद", null)
            .apply {
                if (to < p.second) setNeutralButton("अगले ▶ (${to + 1}…)") { _, _ -> showNumGrid(cmd, to + 1) }
                if (from > p.first) setNegativeButton("◀ पिछले") { _, _ -> showNumGrid(cmd, maxOf(p.first, from - 500)) }
            }
            .show()
    }

    private fun show(s: String): String {
        val c = numOfStep(s)
        val p = c?.let { numParse(it) }
        if (c == null || p == null) return prettyStep(s)
        val tot = p.second - p.first + 1
        val dn = numDone(prefs, numKey(c)); val d = dn.count { it in p.first..p.second }
        val fl = numFailed(prefs, numFailKey(c))
        val r = fl.count { it.key !in dn && it.value < 99 }
        val m = fl.count { it.key !in dn && it.value >= 99 && it.key in p.first..p.second }     // कॉपी है ही नहीं (सफ़ेद)
        return prettyStep(s) + if (d >= tot) "  ✅ सारे $tot पूरे" else "  (✅$d · 🔴$r · बाकी ${tot - d - r - m})"
    }

    private var pendingSwipeDir: String? = null

    /** स्वाइप कमांड जोड़ना: दिशा -> कहाँ पर (टेक्स्ट / फोटो / स्क्रीन का बीच) */
    private fun addSwipeFlow() {
        val dirs = arrayOf("left", "right", "up", "down")
        val names = arrayOf("⬅ बाएँ (उंगली दाएँ→बाएँ)", "➡ दाएँ (उंगली बाएँ→दाएँ)",
            "⬆ ऊपर (उंगली नीचे→ऊपर)", "⬇ नीचे (उंगली ऊपर→नीचे)")
        AlertDialog.Builder(this).setTitle("स्वाइप / स्क्रॉल की दिशा")
            .setItems(names) { _, i ->
                val d = dirs[i]
                AlertDialog.Builder(this).setTitle("कहाँ पर स्वाइप करें?")
                    .setItems(arrayOf("किसी टेक्स्ट पर", "किसी फोटो पर", "स्क्रीन के बीच से")) { _, w ->
                        when (w) {
                            0 -> {
                                val et = EditText(this).apply { hint = "स्क्रीन पर लिखा टेक्स्ट, जैसे: Please" }
                                AlertDialog.Builder(this).setTitle("इस टेक्स्ट वाली जगह से स्वाइप")
                                    .setView(et)
                                    .setPositiveButton("जोड़ें") { _, _ ->
                                        val t = et.text.toString().trim()
                                        if (t.isNotEmpty()) addStep("SWIPE:$d:$t")
                                    }
                                    .setNegativeButton("रद्द", null).show()
                            }
                            1 -> {
                                pendingSwipeDir = d
                                startActivityForResult(
                                    Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }, 77)
                            }
                            else -> addStep("SWIPE:$d:")
                        }
                    }.show()
            }.show()
    }


    // ---------- एक कमांड को वहीं बदलना ----------
    private var editIdx = -1
    private var editTarget = ""

    private fun splitStep(raw: String): Pair<String?, String> =
        if (raw.startsWith("GATE:")) Pair(raw.removePrefix("GATE:").substringBefore(":"), raw.removePrefix("GATE:").substringAfter(":"))
        else Pair(null, raw)

    private fun joinStep(gate: String?, inner: String) = if (gate != null) "GATE:$gate:$inner" else inner

    // कमांड के आख़िर में "~~सेकंड" जुड़ा हो तो वह उस कमांड के बाद रुकने का टाइमर है
    // उसके बाद वैकल्पिक "@@सेकंड" = इस कमांड के खोजने का अपना समय
    private fun splitDelay(raw0: String): Pair<String, Int> {
        val raw = stripLimit(raw0)
        return if (raw.contains("~~")) Pair(raw.substringBeforeLast("~~"), raw.substringAfterLast("~~").toIntOrNull() ?: 0)
        else Pair(raw, 0)
    }
    /** कमांड का पूँछ वाला हिस्सा (~~टाइमर और @@खोज-समय), जो हर बदलाव में वैसा ही रखना है */
    private fun tailOf(raw: String) = raw.substring(splitDelay(raw).first.length)
    private fun delaySuffix(d: Int) = if (d > 0) "~~$d" else ""

    // एक कमांड में दूसरी (वैकल्पिक) कमांड:  पहली|ALT|दूसरी|ALT|तीसरी
    private fun splitAlt(inner: String): Pair<String, List<String>> {
        val p = inner.split("|ALT|"); return Pair(p[0], p.drop(1))
    }
    private fun joinAlt(main: String, alts: List<String>) = main + alts.joinToString("") { "|ALT|$it" }

    private fun setStep(i: Int, v: String) {   // टाइमर और दूसरी कमांड वैसी ही रहती हैं
        val l = savedSteps(); if (i >= l.size) return
        val curBase = splitDelay(l[i]).first
        val curAlts = splitAlt(splitStep(curBase).second).second
        val nv = if (v.contains("|ALT|")) v else joinAlt(v, curAlts)
        l[i] = nv + tailOf(l[i]); saveSteps(l); refresh()
    }
    private fun setAlts(i: Int, alts: List<String>) {
        val l = savedSteps(); if (i >= l.size) return
        val b = splitDelay(l[i]).first; val (gate, inner0) = splitStep(b)
        l[i] = joinStep(gate, joinAlt(splitAlt(inner0).first, alts)) + tailOf(l[i])
        saveSteps(l); refresh()
    }
    private fun setTimers(i: Int, d: Int, lim: Int) {
        val l = savedSteps(); if (i >= l.size) return
        l[i] = splitDelay(l[i]).first + delaySuffix(d.coerceIn(0, 3600)) +
            (if (lim > 0) "@@${lim.coerceIn(1, 3600)}" else ""); saveSteps(l); refresh()
    }

    private fun pickReplacement(i: Int, target: String) {
        editIdx = i; editTarget = target
        startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }, 80)
    }

    private fun askText(title: String, preset: String, hintTxt: String, onOk: (String) -> Unit) {
        val et = EditText(this).apply { setText(preset); hint = hintTxt; setSelection(text.length) }
        AlertDialog.Builder(this).setTitle(title).setView(et)
            .setPositiveButton("सेव") { _, _ -> onOk(et.text.toString().trim()) }
            .setNegativeButton("रद्द", null).show()
    }

    /** टेक्स्ट + नंबर की सीमा पूछो (जैसे कॉपी, 1 से 1000) */
    /** डेवलपर विकल्प "Pointer location" से मिले X, Y (पिक्सल) डालो → POS:x%,y% बनाकर कॉपी करो */
    private fun showPosCalc() {
        val dm = android.util.DisplayMetrics()
        @Suppress("DEPRECATION") windowManager.defaultDisplay.getRealMetrics(dm)
        fun field(h: String, v: String = "") = EditText(this).apply {
            hint = h; setText(v)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        }
        val ex = field("X (Pointer location वाला X)")
        val ey = field("Y (Pointer location वाला Y)")
        val ew = field("स्क्रीन की चौड़ाई (पिक्सल)", dm.widthPixels.toString())
        val eh = field("स्क्रीन की ऊँचाई (पिक्सल)", dm.heightPixels.toString())
        val res = TextView(this).apply { textSize = 22f; setTextColor(Color.parseColor("#1565C0")); setPadding(0, 16, 0, 8); text = "POS:  —" }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(48, 16, 48, 0)
            addView(TextView(this@MainActivity).apply { text = "X और Y डालो (dX, dY नहीं). नीचे चौड़ाई-ऊँचाई इस फ़ोन की अपने-आप भरी है, चाहो तो बदल सकते हो."; textSize = 13f })
            addView(ex); addView(ey); addView(ew); addView(eh); addView(res)
        }
        var cur = ""
        fun calc() {
            val x = ex.text.toString().toFloatOrNull(); val y = ey.text.toString().toFloatOrNull()
            val w = ew.text.toString().toFloatOrNull(); val h = eh.text.toString().toFloatOrNull()
            if (x == null || y == null || w == null || h == null || w <= 0f || h <= 0f) { cur = ""; res.text = "POS:  —"; return }
            cur = "POS:" + String.format(java.util.Locale.US, "%.1f", x / w * 100f) + "," + String.format(java.util.Locale.US, "%.1f", y / h * 100f)
            res.text = if (x > w || y > h) "$cur   ⚠ X/Y स्क्रीन से बड़ा है" else cur
        }
        val tw = object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(e: android.text.Editable?) { calc() }
        }
        listOf(ex, ey, ew, eh).forEach { it.addTextChangedListener(tw) }
        val dlg = AlertDialog.Builder(this).setTitle("📍 POS बनाओ").setView(col)
            .setPositiveButton("📋 कॉपी", null).setNegativeButton("बंद", null).create()
        dlg.show()
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {      // कॉपी के बाद डायलॉग खुला रहे, दूसरा बटन भी निकाल सको
            if (cur.isEmpty()) Toast.makeText(this, "पहले X और Y डालो", Toast.LENGTH_SHORT).show()
            else {
                (getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager)
                    .setPrimaryClip(android.content.ClipData.newPlainText("pos", cur))
                Toast.makeText(this, "कॉपी हुआ: $cur", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun askNumRange(title: String, base: String, lo: String, hi: String, c1: String = "", c2: String = "", onOk: (String, Int, Int, String, String) -> Unit) {
        val dn = resources.displayMetrics.density
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((20 * dn).toInt(), (8 * dn).toInt(), (20 * dn).toInt(), (8 * dn).toInt())
        }
        val eb = EditText(this).apply { setText(base); hint = "बटन का टेक्स्ट (जैसे कॉपी)"; setSelection(text.length) }
        val el = EditText(this).apply { inputType = android.text.InputType.TYPE_CLASS_NUMBER; setText(lo); hint = "कहाँ से (जैसे 1)" }
        val eh = EditText(this).apply { inputType = android.text.InputType.TYPE_CLASS_NUMBER; setText(hi); hint = "कहाँ तक (1000, 10000… कुछ भी)" }
        col.addView(TextView(this).apply { text = "हर बार स्क्रीन पर दिखे \"टेक्स्ट नंबर\" में से सबसे छोटा नंबर जो अभी हुआ नहीं, उसी पर क्लिक होगा। जो हो गया वह दोबारा नहीं लेगा।"; textSize = 13f })
        col.addView(eb); col.addView(el); col.addView(eh)
        col.addView(TextView(this).apply {
            text = "नंबर न मिले तो (खाली छोड़ सकते हो): स्क्रीन पर नीचे दिए टेक्स्ट खोजकर क्लिक होंगे: पहला, फिर लगभग 1 सेकंड बाद दूसरा, फिर इसी ऐप की सारी कमांड शुरू से (वह कॉपी छोड़कर अगली कॉपी). एक ही टेक्स्ट लिखो तो एक ही बार क्लिक"
            textSize = 13f
        })
        val e1 = EditText(this).apply { setText(c1); hint = "पहला टेक्स्ट (जैसे बंद करें)" }
        val e2 = EditText(this).apply { setText(c2); hint = "दूसरा टेक्स्ट (खाली = छोड़ो)" }
        col.addView(e1); col.addView(e2)
        AlertDialog.Builder(this).setTitle(title).setView(col)
            .setPositiveButton("सेव") { _, _ ->
                val b = eb.text.toString().trim().replace(":", " ")
                val l = el.text.toString().trim().toIntOrNull() ?: 1
                val h = eh.text.toString().trim().toIntOrNull() ?: 1000
                if (b.isNotEmpty()) onOk(b, minOf(l, h), maxOf(l, h), e1.text.toString().trim().replace(":", " ").replace("¦", " "), e2.text.toString().trim().replace(":", " ").replace("¦", " "))
            }
            .setNegativeButton("रद्द", null).show()
    }

    private fun editStepFlow(i: Int) {
        val steps = savedSteps(); if (i >= steps.size) return
        val curDelay = splitDelay(steps[i]).second
        val curLim = stepLimit(steps[i])
        val (gate, inner0) = splitStep(splitDelay(steps[i]).first)
        val (inner, alts) = splitAlt(inner0)
        val labels = ArrayList<String>(); val acts = ArrayList<() -> Unit>()
        fun add(l: String, a: () -> Unit) { labels.add(l); acts.add(a) }

        if (gate != null) {
            add("🖼 स्क्रीनशॉट (शर्त) बदलें") { pickReplacement(i, "gate") }
            add("❌ स्क्रीनशॉट शर्त हटाएँ (कमांड रहेगी)") {
                File(filesDir, gate).delete(); setStep(i, inner)
            }
        }
        if (inner.startsWith("SWIPE:")) {
            val p = inner.split(":", limit = 3); val dir = p[1]; val tgt = p.getOrElse(2) { "" }
            add("↔ दिशा बदलें") {
                val dirs = arrayOf("left", "right", "up", "down")
                AlertDialog.Builder(this).setTitle("नई दिशा")
                    .setItems(arrayOf("⬅ बाएँ", "➡ दाएँ", "⬆ ऊपर", "⬇ नीचे")) { _, k ->
                        setStep(i, joinStep(gate, "SWIPE:${dirs[k]}:$tgt"))
                    }.show()
            }
            if (tgt.startsWith("IMG:")) add("🖼 स्वाइप वाली फोटो बदलें") { pickReplacement(i, "inner") }
            add("✏ जगह (टेक्स्ट) बदलें / खाली = स्क्रीन का बीच") {
                askText("इस टेक्स्ट वाली जगह से स्वाइप", if (tgt.startsWith("IMG:")) "" else tgt, "स्क्रीन पर लिखा टेक्स्ट") { t ->
                    if (tgt.startsWith("IMG:")) File(filesDir, tgt.substringAfterLast(":")).delete()
                    setStep(i, joinStep(gate, "SWIPE:$dir:${t.replace(":", " ")}"))
                }
            }
        } else if (inner.startsWith("IMG:")) {
            val mode = inner.split(":")[1]
            add("🖼 फोटो बदलें") { pickReplacement(i, "inner") }
            add(if (mode == "req") "⏭ वैकल्पिक करें (न मिले तो आगे बढ़ो)" else "🔁 ज़रूरी करें (खोजते रहो)") {
                setStep(i, joinStep(gate, "IMG:${if (mode == "req") "opt" else "req"}:${inner.substringAfterLast(":")}"))
            }
        } else if (inner.startsWith("NUM:") && numParse(inner) != null) {
            val (lo, hi, base) = numParse(inner)!!
            val nd = numDone(prefs, numKey(inner)).size
            add("✏ टेक्स्ट / नंबर की सीमा बदलें") {
                val ex = numExtras(inner)
                askNumRange("कमांड ${i + 1}: नंबर वाली", base, lo.toString(), hi.toString(), ex.first, ex.second) { b, l, h, x1, x2 ->
                    setStep(i, joinStep(gate, "NUM:$l-$h:$b" + (if (x1.isNotEmpty() || x2.isNotEmpty()) "¦$x1¦$x2" else "")))
                }
            }
            add("📊 हर नंबर की स्थिति देखें (हरा / लाल)") { showNumGrid(inner) }
            add("🔄 गिनती रीसेट (अभी $nd हो चुके)") {
                prefs.edit().remove(numKey(inner)).remove(numFailKey(inner)).apply()
                Toast.makeText(this, "गिनती रीसेट: फिर से $lo से", Toast.LENGTH_SHORT).show()
            }
            add("↩ सामान्य कमांड बनाएँ") { setStep(i, joinStep(gate, base)) }
        } else {
            if (alts.isEmpty()) add("🔢 नंबर वाली कमांड बनाएँ (कॉपी 1, कॉपी 2 …)") {
                askNumRange("कमांड ${i + 1}: नंबर वाली", inner, "1", "1000") { b, l, h, x1, x2 ->
                    setStep(i, joinStep(gate, "NUM:$l-$h:$b" + (if (x1.isNotEmpty() || x2.isNotEmpty()) "¦$x1¦$x2" else "")))
                }
            }
            add("✏ कमांड का टेक्स्ट बदलें") {
                askText("कमांड ${i + 1} बदलें", inner, "बटन का टेक्स्ट") { t ->
                    val v = cmdClean(t)
                    if (v.isNotEmpty()) setStep(i, joinStep(gate, v))
                }
            }
        }
        // ---- दूसरी कमांड: पहली न मिले तो इसी कमांड में दूसरी (टेक्स्ट या फोटो) खोजो ----
        val canAlt = !inner.startsWith("SWIPE:") && !(inner.startsWith("NUM:") && numParse(inner) != null)
        if (canAlt) {
            alts.forEachIndexed { k, a ->
                if (a.startsWith("IMG:")) add("🖼 दूसरी कमांड ${k + 1} (फोटो) बदलें") { pickReplacement(i, "alt$k") }
                else add("✏ दूसरी कमांड ${k + 1} (\"$a\") बदलें") {
                    val retry = a.startsWith("↺")
                    askText("दूसरी कमांड ${k + 1}", a.removePrefix("↺"), "बटन का टेक्स्ट") { t ->
                        val v = cmdClean(t)
                        if (v.isNotEmpty()) setAlts(i, alts.toMutableList().also { it[k] = (if (retry) "↺" else "") + v })
                    }
                }
                add("❌ दूसरी कमांड ${k + 1} हटाएँ") {
                    if (a.startsWith("IMG:")) File(filesDir, a.substringAfterLast(":")).delete()
                    setAlts(i, alts.toMutableList().also { it.removeAt(k) })
                }
            }
            if (alts.size < 3) {
                add("➕ दूसरी कमांड जोड़ें — टेक्स्ट से (पहली न मिले तो)") {
                    askText("पहली न मिले तो यह खोजो", "", "बटन का टेक्स्ट") { t ->
                        val v = cmdClean(t)
                        if (v.isNotEmpty()) setAlts(i, alts + v)
                    }
                }
                add("➕ दूसरी कमांड जोड़ें — फोटो/स्क्रीनशॉट से (पहली न मिले तो)") { pickReplacement(i, "altnew") }
                add("🔁 पहली न मिले तो यह दबाओ, फिर पहली दोबारा खोजो (जैसे Today न मिला → Yesterday दबाओ → फिर Today)") {
                    askText("न मिले तो यह दबाओ, फिर पहली फिर खोजो", "", "बटन का टेक्स्ट") { t ->
                        val v = cmdClean(t)
                        if (v.isNotEmpty()) setAlts(i, alts + ("↺" + v))
                    }
                }
            }
        }
        add("🗑 यह कमांड हटाएँ") { val l = savedSteps(); if (i < l.size) { l.removeAt(i); saveSteps(l); refresh() } }

        // ---- सजा हुआ एडिट पेज: ऊपर टाइमर, नीचे बदलाव के बटन ----
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), dp(8)) }
        col.addView(TextView(this).apply {
            text = show(splitDelay(steps[i]).first); textSize = 15f; setTextColor(Color.parseColor("#37474F"))
            setPadding(0, 0, 0, dp(14))
        })
        col.addView(TextView(this).apply {
            text = "⏱ इस कमांड के बाद कितनी देर रुकें?"; textSize = 14f
            setTypeface(typeface, android.graphics.Typeface.BOLD); setPadding(0, 0, 0, dp(6))
        })
        val et = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setText(if (curDelay > 0) curDelay.toString() else ""); hint = "0"
            gravity = Gravity.CENTER; textSize = 20f
        }
        val timeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        timeRow.addView(et, LinearLayout.LayoutParams(dp(110), -2))
        timeRow.addView(TextView(this).apply { text = "  सेकंड  (0 = बिना रुके)"; textSize = 14f })
        col.addView(timeRow)
        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(8), 0, dp(4)) }
        for (sec in intArrayOf(0, 5, 10, 15, 20, 30, 60)) {
            chips.addView(Button(this).apply {
                text = if (sec == 0) "नहीं" else "${sec}s"; textSize = 13f; isAllCaps = false
                minWidth = 0; minimumWidth = 0; setPadding(dp(14), 0, dp(14), 0)
                setOnClickListener { et.setText(if (sec == 0) "" else sec.toString()); et.setSelection(et.text.length) }
            }, LinearLayout.LayoutParams(-2, dp(44)).apply { rightMargin = dp(6) })
        }
        col.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(chips) })

        // ---- इस कमांड को कितनी देर खोजना है (सेकंड में) ----
        col.addView(TextView(this).apply {
            text = "🔍 यह कमांड कितनी देर खोजे?"; textSize = 14f
            setTypeface(typeface, android.graphics.Typeface.BOLD); setPadding(0, dp(14), 0, dp(6))
        })
        val etL = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setText(if (curLim > 0) curLim.toString() else ""); hint = "सामान्य"
            gravity = Gravity.CENTER; textSize = 20f
        }
        val limRow2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        limRow2.addView(etL, LinearLayout.LayoutParams(dp(110), -2))
        limRow2.addView(TextView(this).apply { text = "  सेकंड  (खाली = सामान्य समय; 2 मिनट = 120)"; textSize = 13f })
        col.addView(limRow2)
        val chipsL = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(8), 0, dp(4)) }
        for (sec in intArrayOf(0, 10, 15, 30, 50, 60, 120)) {
            chipsL.addView(Button(this).apply {
                text = if (sec == 0) "सामान्य" else "${sec}s"; textSize = 13f; isAllCaps = false
                minWidth = 0; minimumWidth = 0; setPadding(dp(14), 0, dp(14), 0)
                setOnClickListener { etL.setText(if (sec == 0) "" else sec.toString()); etL.setSelection(etL.text.length) }
            }, LinearLayout.LayoutParams(-2, dp(44)).apply { rightMargin = dp(6) })
        }
        col.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(chipsL) })

        col.addView(View(this).apply { setBackgroundColor(Color.parseColor("#E0E0E0")) },
            LinearLayout.LayoutParams(-1, dp(1)).apply { topMargin = dp(14); bottomMargin = dp(10) })
        col.addView(TextView(this).apply {
            text = "✏ बदलाव"; textSize = 14f; setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, 0, 0, dp(6))
        })
        lateinit var dlg: AlertDialog
        val saveDelay = {
            setTimers(i, et.text.toString().trim().toIntOrNull() ?: 0, etL.text.toString().trim().toIntOrNull() ?: 0)
        }
        labels.forEachIndexed { k, l ->
            col.addView(Button(this).apply {
                text = l; isAllCaps = false; textSize = 14f; gravity = Gravity.START or Gravity.CENTER_VERTICAL
                setPadding(dp(14), 0, dp(14), 0)
                setOnClickListener { saveDelay(); dlg.dismiss(); acts[k]() }
            }, LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(6) })
        }
        dlg = AlertDialog.Builder(this).setTitle("कमांड ${i + 1}")
            .setView(ScrollView(this).apply { addView(col) })
            .setPositiveButton("सेव") { _, _ -> saveDelay() }
            .setNegativeButton("बंद", null).create()
        dlg.show()
    }

    private fun addStep(s: String) { val l = savedSteps(); l.add(s); saveSteps(l); refresh() }

    private val vpnBoxes = HashMap<String, EditText>()

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 88 && res == RESULT_OK && data != null) {
            startForegroundService(Intent(this, CaptureService::class.java)
                .putExtra("code", res).putExtra("data", data))
            return
        }
        if (req == 81 || req == 82 || req == 83) {        // वीपीएन के स्टेप में फोटो जोड़ना
            val u = data?.data
            if (res == RESULT_OK && u != null) {
                val bm = contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it) }
                if (bm != null) {
                    val nm = "vpn_${System.currentTimeMillis()}.png"
                    FileOutputStream(File(filesDir, nm)).use { bm.compress(Bitmap.CompressFormat.PNG, 100, it) }
                    val key = if (req == 81) "vpnOff" else if (req == 83) "vpnCountry" else "vpnOn"
                    val cur = prefs.getString(key, "")!!.trimEnd()
                    val nw = (if (cur.isEmpty()) "" else cur + "\n") + "IMG:" + nm
                    prefs.edit().putString(key, nw).apply()
                    vpnBoxes[key]?.setText(nw)
                    Toast.makeText(this, "फोटो जुड़ गई — लाइन IMG:$nm बनी", Toast.LENGTH_SHORT).show()
                }
            }
            return
        }
        if (req == 84 || req == 85) {         // "रिव्यू से पहले" वाले खाने के लिए फोटो
            val u = data?.data
            if (res == RESULT_OK && u != null) {
                val bm = contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it) }
                if (bm != null) {
                    val nm = "pre_${System.currentTimeMillis()}.png"
                    FileOutputStream(File(filesDir, nm)).use { bm.compress(Bitmap.CompressFormat.PNG, 100, it) }
                    (if (req == 84) preEdit1 else preEdit2)?.setText("IMG:$nm")
                }
            }
            return
        }
        if (req == 78) {
            val u = data?.data
            if (res == RESULT_OK && u != null) {
                val b = contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it) }
                if (b != null) {
                    val nm = "review_${System.currentTimeMillis()}.png"
                    FileOutputStream(File(filesDir, nm)).use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }
                    askReviewCommand(nm)
                }
            }
            return
        }
        if (req == 79) {            // स्क्रीनशॉट चुना → अब बताओ कौन-सी कमांड इससे जुड़ेगी
            val u = data?.data
            if (res == RESULT_OK && u != null) {
                val bm = contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it) }
                if (bm != null) {
                    val nm = "gate_${System.currentTimeMillis()}.png"
                    FileOutputStream(File(filesDir, nm)).use { bm.compress(Bitmap.CompressFormat.PNG, 100, it) }
                    askGateCommand(nm)
                }
            }
            return
        }
        if (req == 80) {            // किसी कमांड की फोटो/स्क्रीनशॉट बदलना
            val u = data?.data
            val i = editIdx; val tgt = editTarget
            editIdx = -1
            if (res == RESULT_OK && u != null && i >= 0) {
                val bm = contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it) }
                val steps = savedSteps()
                if (bm != null && i < steps.size) {
                    val nm = "edit_${System.currentTimeMillis()}.png"
                    FileOutputStream(File(filesDir, nm)).use { bm.compress(Bitmap.CompressFormat.PNG, 100, it) }
                    val (baseS, dly) = splitDelay(steps[i])
                    val (gate, inner0) = splitStep(baseS)
                    val (inner, alts) = splitAlt(inner0)
                    if (tgt == "gate" && gate != null) {
                        File(filesDir, gate).delete()
                        steps[i] = joinStep(nm, inner0) + tailOf(steps[i])
                    } else if (tgt == "altnew") {                       // दूसरी कमांड (फोटो) जोड़ना
                        steps[i] = joinStep(gate, joinAlt(inner, alts + "IMG:req:$nm")) + tailOf(steps[i])
                    } else if (tgt.startsWith("alt")) {                 // दूसरी कमांड की फोटो बदलना
                        val k = tgt.removePrefix("alt").toIntOrNull() ?: -1
                        if (k in alts.indices) {
                            File(filesDir, alts[k].substringAfterLast(":")).delete()
                            steps[i] = joinStep(gate, joinAlt(inner, alts.toMutableList().also { it[k] = "IMG:req:$nm" })) + tailOf(steps[i])
                        }
                    } else if (inner.startsWith("IMG:") || inner.contains(":IMG:")) {
                        val old = inner.substringAfterLast(":")
                        File(filesDir, old).delete()
                        steps[i] = joinStep(gate, joinAlt(inner.substringBeforeLast(":") + ":" + nm, alts)) + tailOf(steps[i])
                    }
                    saveSteps(steps); refresh()
                }
            }
            return
        }
        if (req == 77 && res != RESULT_OK) { pendingSwipeDir = null; return }
        if (req != 77 || res != RESULT_OK) return
        val uri = data?.data ?: return
        val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } ?: return
        val name = "step_${System.currentTimeMillis()}.png"
        FileOutputStream(File(filesDir, name)).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        val sd = pendingSwipeDir
        if (sd != null) {            // फोटो पर स्वाइप
            pendingSwipeDir = null
            addStep("SWIPE:$sd:IMG:req:$name")
            return
        }
        askImgMode(name)
    }

    /** स्क्रीनशॉट किस कमांड से जुड़े: पुरानी कमांड चुनो या नई लिखो */
    private fun askGateCommand(shot: String) {
        val steps = savedSteps()
        val newText = {
            val et = EditText(this).apply { hint = "बटन का टेक्स्ट, जैसे: Cancel" }
            AlertDialog.Builder(this).setTitle("स्क्रीन मिलने पर कौन-सी कमांड चले?")
                .setView(et)
                .setPositiveButton("जोड़ें") { _, _ ->
                    val t = cmdClean(et.text.toString())
                    if (t.isNotEmpty()) addStep("GATE:$shot:$t") else File(filesDir, shot).delete()
                }
                .setNegativeButton("रद्द") { _, _ -> File(filesDir, shot).delete() }
                .setOnCancelListener { File(filesDir, shot).delete() }
                .show()
        }
        if (steps.isEmpty()) { newText(); return }
        val items = steps.mapIndexed { i, st -> "कमांड ${i + 1}:  ${show(st)}" }.toMutableList()
        items.add("➕ नई कमांड लिखें")
        AlertDialog.Builder(this)
            .setTitle("यह स्क्रीनशॉट किस कमांड से जोड़ें?")
            .setItems(items.toTypedArray()) { _, i ->
                if (i == steps.size) { newText(); return@setItems }
                val cur = steps[i]
                val inner = if (cur.startsWith("GATE:")) cur.removePrefix("GATE:").substringAfter(":") else cur
                steps[i] = "GATE:$shot:$inner"
                saveSteps(steps); refresh()
            }
            .setNegativeButton("रद्द") { _, _ -> File(filesDir, shot).delete() }
            .setOnCancelListener { File(filesDir, shot).delete() }
            .show()
    }

    private fun askImgMode(name: String) {
        AlertDialog.Builder(this)
            .setTitle("यह फोटो स्क्रीन पर न मिले तो?")
            .setPositiveButton("खोजते रहो (ज़रूरी)") { _, _ -> addStep("IMG:req:$name") }
            .setNegativeButton("छोड़कर आगे बढ़ो (वैकल्पिक)") { _, _ -> addStep("IMG:opt:$name") }
            .show()
    }

    private fun launch(pkg: String) {
        val svc = ControlService.instance
        if (svc == null) {
            Toast.makeText(this, "पहले Accessibility चालू करें", Toast.LENGTH_LONG).show(); return
        }
        if (pkg.startsWith("home:")) {
            svc.startSequence(savedSteps()); svc.launchHome(pkg.removePrefix("home:")); return
        }
        val intent = packageManager.getLaunchIntentForPackage(pkg) ?: return
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val go = { svc.startSequence(savedSteps()); startActivity(intent) }
        if (prefs.getBoolean("boostBefore", true)) Shell.boost(this, setOf(pkg)) { go() } else go()
    }

    private fun addApps(list: List<String>) {
        val s = savedApps()
        val newOnes = list.filter { it !in s }
        for (p in newOnes) s.add(p)
        saveApps(s)
        if (prefs.getBoolean("ran", false) && newOnes.isNotEmpty())   // नया ऐप 'बाकी' रहे, झूठा ✔ नहीं
            prefs.edit().putString("failed", (failedList() + newOnes).distinct().joinToString("\n")).apply()
        refresh()
    }

    private fun chooseAddMode() {
        AlertDialog.Builder(this).setTitle("क्या जोड़ना है?")
            .setItems(arrayOf("📱 इंस्टॉल किए सारे ऐप", "🏠 होम स्क्रीन के आइकन / शॉर्टकट (क्रोम शॉर्टकट, क्लोन…)")) { _, w ->
                if (w == 0) showAllApps() else scanHomeShortcuts()
            }
            .setNegativeButton("रद्द", null).show()
    }

    private fun scanHomeShortcuts() {
        val svc = ControlService.instance
        if (svc == null) {
            Toast.makeText(this, "पहले Accessibility चालू करें", Toast.LENGTH_LONG).show(); return
        }
        Toast.makeText(this, "होम स्क्रीन के पेज स्कैन हो रहे हैं… (हाथ न लगाएँ)", Toast.LENGTH_LONG).show()
        svc.scanHome { labels -> runOnUiThread { showHomeItems(labels) } }
    }

    private fun showHomeItems(labels: List<String>) {
        if (labels.isEmpty()) {
            Toast.makeText(this, "होम स्क्रीन पर कुछ नहीं मिला", Toast.LENGTH_LONG).show(); return
        }
        val ids = labels.map { "home:$it" }
        val already = savedApps().toSet()
        val checked = BooleanArray(ids.size) { ids[it] in already }
        AlertDialog.Builder(this)
            .setTitle("होम स्क्रीन के आइकन (${ids.size})")
            .setMultiChoiceItems(labels.toTypedArray(), checked) { _, i, c -> checked[i] = c }
            .setPositiveButton("चुने हुए जोड़ें") { _, _ ->
                addApps(ids.filterIndexed { i, _ -> checked[i] })
            }
            .setNeutralButton("सारे जोड़ें") { _, _ -> addApps(ids) }
            .setNegativeButton("रद्द", null)
            .show()
    }

    private fun showAllApps() {
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = packageManager.queryIntentActivities(main, 0)
            .map { it.activityInfo.packageName to it.loadLabel(packageManager).toString() }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }
        val already = savedApps().toSet()
        val checked = BooleanArray(apps.size) { apps[it].first in already }
        AlertDialog.Builder(this)
            .setTitle("ऐप चुनें (✔ = पहले से जुड़ा, ${already.size})")
            .setMultiChoiceItems(apps.map { it.second }.toTypedArray(), checked) { _, i, c -> checked[i] = c }
            .setPositiveButton("चुने हुए जोड़ें") { _, _ ->
                addApps(apps.filterIndexed { i, _ -> checked[i] }.map { it.first })
            }
            .setNeutralButton("सारे जोड़ें") { _, _ -> addApps(apps.map { it.first }) }
            .setNegativeButton("रद्द", null)
            .show()
    }
}


/** कमांड का टेक्स्ट साफ़ करो: ":" और "|ALT|" हटाओ, पर "POS:50,68" (स्क्रीन की जगह पर टैप) जैसा है वैसा रखो */
fun cmdClean(t0: String): String {
    val t = t0.trim()
    if (t.startsWith("IMG:") && !t.contains("|ALT|") && !t.contains("¦")) return t      // फोटो वाली लाइन जैसी है वैसी रखो
    if (t.startsWith("POS:", ignoreCase = true)) {
        val nums = t.substring(4).replace("|ALT|", "").replace(" ", "").replace("%", "")
        return if (nums.contains(":")) t.replace(":", " ").replace("|ALT|", " ").trim() else "POS:$nums"
    }
    return t.replace(":", " ").replace("|ALT|", " ").trim()
}
