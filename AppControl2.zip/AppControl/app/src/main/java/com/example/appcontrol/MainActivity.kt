package com.example.appcontrol

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import java.io.File
import java.io.FileOutputStream
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    companion object { var cur: MainActivity? = null }

    private val prefs by lazy { getSharedPreferences("apps", Context.MODE_PRIVATE) }
    private lateinit var appList: ListView
    private lateinit var stepList: ListView
    private lateinit var status: TextView
    private lateinit var projLabel: TextView
    private lateinit var boostInfo: TextView
    private lateinit var reviewInfo: TextView
    private lateinit var reviewBox: LinearLayout
    private val binderListener = Shizuku.OnBinderReceivedListener {
        // Shizuku बाद में चालू हो तो भी अपने-आप अनुमति माँगो और स्थिति बदलो
        runOnUiThread {
            if (!Shell.rootGranted && !Shell.shizukuReady()) try { Shizuku.requestPermission(7) } catch (e: Throwable) {}
            updateBoostInfo()
        }
    }
    private val shizukuListener = Shizuku.OnRequestPermissionResultListener { _, _ -> updateBoostInfo() }

    private fun updateBoostInfo() {
        boostInfo.text = when {
            Shell.rootGranted -> "⚡ बूस्ट मोड: पूरा (Root ✅)"
            Shell.shizukuReady() -> "⚡ बूस्ट मोड: पूरा (Shizuku ✅)"
            else -> "⚡ बूस्ट मोड: हल्का (Root/Shizuku नहीं जुड़ा) — 🧰 टूल्स → पावर टूल्स"
        }
    }

    override fun onDestroy() {
        if (cur === this) cur = null
        try { Shizuku.removeRequestPermissionResultListener(shizukuListener) } catch (e: Throwable) {}
        try { Shizuku.removeBinderReceivedListener(binderListener) } catch (e: Throwable) {}
        super.onDestroy()
    }

    private fun savedApps(): MutableList<String> =
        prefs.getString("pkgs", "")!!.split("\n").filter { it.isNotBlank() }.toMutableList()
    private fun saveApps(l: List<String>) {
        val a = l.joinToString("\n")
        val e = prefs.edit().putString("pkgs", a)
        val cur = curProject()
        if (cur.isNotEmpty()) e.putString("a_$cur", a)   // खुले प्रोजेक्ट के ऐप भी अपने-आप सेव
        e.apply()
    }

    private fun savedSteps(): MutableList<String> =
        prefs.getString("steps", "")!!.split("\n").filter { it.isNotBlank() }.toMutableList()
    private fun saveSteps(l: List<String>) {
        val s = l.joinToString("\n")
        val e = prefs.edit().putString("steps", s)
        val cur = curProject()
        if (cur.isNotEmpty()) e.putString("p_$cur", s)   // खुला प्रोजेक्ट अपने-आप सेव होता रहता है
        e.apply()
    }

    // ---------- प्रोजेक्ट ----------
    private fun projectNames(): MutableList<String> =
        prefs.getString("pnames", "")!!.split("\n").filter { it.isNotBlank() }.toMutableList()
    private fun curProject(): String = prefs.getString("cur", "")!!
    private fun projSteps(name: String): List<String> =
        prefs.getString("p_$name", "")!!.split("\n").filter { it.isNotBlank() }

    private fun writeProject(name: String, steps: List<String>, apps: List<String>) {
        val n = projectNames(); if (name !in n) n.add(name)
        prefs.edit().putString("pnames", n.joinToString("\n"))
            .putString("p_$name", steps.joinToString("\n"))
            .putString("a_$name", apps.joinToString("\n"))
            .putString("cur", name).apply()
    }

    private fun loadProject(name: String) {
        val e = prefs.edit().putString("cur", name)
            .putString("steps", projSteps(name).joinToString("\n"))
        // पुराने प्रोजेक्ट (जिनमें ऐप सेव नहीं थे) में मौजूदा ऐप सूची जस की तस रहे
        if (prefs.contains("a_$name")) e.putString("pkgs", prefs.getString("a_$name", "")!!)
        e.remove("failed").putBoolean("ran", false).apply()
        refresh()
        val cnt = savedApps().size
        Toast.makeText(this, "प्रोजेक्ट खुला: $name  ($cnt ऐप)", Toast.LENGTH_SHORT).show()
    }

    private fun askName(title: String, preset: String, onOk: (String) -> Unit) {
        val et = EditText(this).apply { hint = "प्रोजेक्ट का नाम"; setText(preset) }
        AlertDialog.Builder(this).setTitle(title).setView(et)
            .setPositiveButton("ठीक है") { _, _ ->
                val n = et.text.toString().replace("\n", " ").trim()
                if (n.isEmpty()) Toast.makeText(this, "नाम लिखें", Toast.LENGTH_SHORT).show() else onOk(n)
            }.setNegativeButton("रद्द", null).show()
    }

    /** मौजूदा कमांड इस नाम से सेव (पहले से हो तो बदल जाएगा) */
    private fun saveProjectFlow() {
        askName("प्रोजेक्ट सेव करें", curProject()) { n ->
            val doSave = { writeProject(n, savedSteps(), savedApps()); refresh()
                Toast.makeText(this, "सेव हुआ: $n  (${savedApps().size} ऐप)", Toast.LENGTH_SHORT).show() }
            if (n in projectNames() && n != curProject())
                AlertDialog.Builder(this).setTitle("\"$n\" पहले से है — बदल दें?")
                    .setPositiveButton("बदलें") { _, _ -> doSave() }
                    .setNegativeButton("रद्द", null).show()
            else doSave()
        }
    }

    /** नया खाली प्रोजेक्ट; पिछला (खुला) प्रोजेक्ट पहले से सेव है */
    private fun newProjectFlow() {
        askName("नया प्रोजेक्ट", "") { n ->
            if (n in projectNames()) {
                Toast.makeText(this, "इस नाम का प्रोजेक्ट पहले से है", Toast.LENGTH_SHORT).show(); return@askName
            }
            // बिना नाम की चल रही कमांड हों तो खो न जाएँ
            if (curProject().isEmpty() && savedSteps().isNotEmpty()) {
                var k = 1; while ("बिना नाम $k" in projectNames()) k++
                writeProject("बिना नाम $k", savedSteps(), savedApps())
            }
            // कमांड/सेटिंग पिछली बार वाली ही रहें (बदल सकते हैं); ऐप सूची खाली
            writeProject(n, savedSteps(), emptyList())
            prefs.edit().putString("pkgs", "").remove("failed").putBoolean("ran", false).apply()
            refresh()
        }
    }

    /** प्रोजेक्ट चुनो (जिस क्रम में टैप करोगे उसी क्रम में चलेंगे) */
    private fun chooseVpnApp(done: () -> Unit) {
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = packageManager.queryIntentActivities(main, 0)
            .map { it.activityInfo.packageName to it.loadLabel(packageManager).toString() }
            .filter { it.first != packageName }.distinctBy { it.first }.sortedBy { it.second.lowercase() }
        AlertDialog.Builder(this).setTitle("अपना वीपीएन ऐप चुनें")
            .setItems(apps.map { it.second }.toTypedArray()) { _, i ->
                prefs.edit().putString("vpnPkg", apps[i].first).apply(); done()
            }
            .setNeutralButton("हटाएँ") { _, _ -> prefs.edit().remove("vpnPkg").apply(); done() }
            .setNegativeButton("रद्द", null).show()
    }

    private fun chainFlow() {
        if (prefs.getBoolean("vpnCycle", false) && prefs.getString("vpnPkg", "").isNullOrEmpty())
            Toast.makeText(this, "वीपीएन चालू है पर वीपीएन ऐप चुना नहीं — वीपीएन वाला हिस्सा छूट जाएगा", Toast.LENGTH_LONG).show()
        val names = projectNames()
        if (names.size < 2) { Toast.makeText(this, "कम से कम 2 प्रोजेक्ट सेव होने चाहिए", Toast.LENGTH_LONG).show(); return }
        val order = mutableListOf<String>()
        val lv = ListView(this)
        val ad = object : ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, names) {
            override fun getView(pos: Int, v: android.view.View?, p: android.view.ViewGroup): android.view.View {
                val t = super.getView(pos, v, p) as TextView
                val n = names[pos]; val k = order.indexOf(n)
                val cnt = prefs.getString("a_$n", "")!!.split("\n").count { it.isNotBlank() }
                t.text = (if (k >= 0) "${k + 1}. ✔  " else "☐  ") + n + "   ($cnt ऐप)"
                return t
            }
        }
        lv.adapter = ad
        lv.setOnItemClickListener { _, _, i, _ -> val n = names[i]; if (!order.remove(n)) order.add(n); ad.notifyDataSetChanged() }
        AlertDialog.Builder(this).setTitle("जिस क्रम में चलाना है उसी क्रम में टैप करें").setView(lv)
            .setPositiveButton("▶ चलाएँ") { _, _ ->
                val svc = ControlService.instance
                when {
                    svc == null -> Toast.makeText(this, "पहले Accessibility चालू करें", Toast.LENGTH_LONG).show()
                    order.isEmpty() -> Toast.makeText(this, "कोई प्रोजेक्ट नहीं चुना", Toast.LENGTH_SHORT).show()
                    else -> { svc.startChain(order.toList()); refresh() }
                }
            }.setNegativeButton("रद्द", null).show()
    }

    private fun openProjectFlow() {
        val names = projectNames()
        if (names.isEmpty()) { Toast.makeText(this, "अभी कोई प्रोजेक्ट सेव नहीं है", Toast.LENGTH_SHORT).show(); return }
        val dlg = AlertDialog.Builder(this).setTitle("प्रोजेक्ट चुनें (लंबा दबाकर हटाएँ)")
            .setItems(names.map { (if (it == curProject()) "▶ " else "") + it }.toTypedArray()) { _, i -> loadProject(names[i]) }
            .setNegativeButton("रद्द", null).create()
        dlg.show()
        dlg.listView.setOnItemLongClickListener { _, _, i, _ ->
            AlertDialog.Builder(this).setTitle("\"${names[i]}\" हटाएँ?")
                .setPositiveButton("हटाएँ") { _, _ ->
                    val l = projectNames(); l.remove(names[i])
                    val e = prefs.edit().putString("pnames", l.joinToString("\n")).remove("p_${names[i]}")
                    if (curProject() == names[i]) e.putString("cur", "")
                    e.apply(); dlg.dismiss(); refresh()
                }.setNegativeButton("रद्द", null).show()
            true
        }
    }

    private fun label(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) { pkg }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        cur = this
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 64, 32, (170 * resources.displayMetrics.density).toInt())   // नीचे खाली जगह, ताकि आख़िर तक स्क्रॉल हो
        }
        root.addView(Button(this).apply {
            text = "Accessibility चालू करें"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        root.addView(Button(this).apply {
            text = "🧰 फोन बूस्ट / क्लीन टूल्स"
            setOnClickListener { startActivity(Intent(this@MainActivity, ToolsActivity::class.java)) }
        })
        boostInfo = TextView(this).apply { textSize = 13f; setTextColor(Color.parseColor("#2E7D32")) }
        root.addView(boostInfo)
        try { Shizuku.addRequestPermissionResultListener(shizukuListener) } catch (e: Throwable) {}
        try { Shizuku.addBinderReceivedListenerSticky(binderListener) } catch (e: Throwable) {}
        root.addView(Button(this).apply {
            text = "🔗 Shizuku जोड़ें / अनुमति दें"
            setOnClickListener { Shell.connectShizuku(this@MainActivity) { updateBoostInfo() } }
        })

        // ---- खोजने का समय ----
        root.addView(TextView(this).apply {
            text = "हर कमांड के लिए बटन खोजने का समय (सेकंड)"; textSize = 15f; setTextColor(Color.BLACK)
        })
        val limRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        }
        val limInput = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setText(prefs.getInt("limit", 8).toString())
        }
        fun saveLimit(v: Int) {
            prefs.edit().putInt("limit", v).apply()
            limInput.setText(v.toString())
            Toast.makeText(this, "सेव: $v सेकंड", Toast.LENGTH_SHORT).show()
        }
        limRow.addView(limInput, LinearLayout.LayoutParams(0, -2, 1f))
        limRow.addView(Button(this).apply {
            text = "सेव"
            setOnClickListener {
                val v = limInput.text.toString().toIntOrNull()
                if (v == null || v < 1) Toast.makeText(this@MainActivity, "1 या उससे ज़्यादा लिखें", Toast.LENGTH_SHORT).show()
                else saveLimit(v)
            }
        })
        limRow.addView(Button(this).apply {
            text = "चुनें"
            setOnClickListener {
                val secs = intArrayOf(8, 10, 15, 20, 30, 60, 120, 240)
                val names = arrayOf("8 सेकंड", "10 सेकंड", "15 सेकंड", "20 सेकंड", "30 सेकंड", "1 मिनट", "2 मिनट", "4 मिनट")
                AlertDialog.Builder(this@MainActivity).setTitle("खोजने का समय")
                    .setItems(names) { _, i -> saveLimit(secs[i]) }.show()
            }
        })
        root.addView(limRow)
        root.addView(TextView(this).apply {
            text = "अगले ऐप पर जाते समय पिछला ऐप:"; textSize = 15f; setTextColor(Color.BLACK)
        })
        val rg = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        val modes = arrayOf("बंद न करें", "मिनिमाइज़ करके ऊपर स्वाइप से बंद करें", "App info से Force stop करें")
        modes.forEachIndexed { i, t ->
            rg.addView(RadioButton(this).apply { text = t; id = 1000 + i })
        }
        rg.check(1000 + prefs.getInt("closeMode", 1))
        rg.setOnCheckedChangeListener { _, id -> prefs.edit().putInt("closeMode", id - 1000).apply() }
        root.addView(rg)

        // ---- प्रोजेक्ट ----
        projLabel = TextView(this).apply { textSize = 16f; setTextColor(Color.parseColor("#6A1B9A")) }
        root.addView(projLabel)
        val projRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun pb(t: String, f: () -> Unit) = projRow.addView(Button(this).apply {
            text = t; textSize = 12f; setOnClickListener { f() }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        pb("💾 सेव") { saveProjectFlow() }
        pb("📂 खोलें") { openProjectFlow() }
        pb("➕ नया") { newProjectFlow() }
        root.addView(projRow)
        root.addView(Button(this).apply {
            text = "⛓ कई प्रोजेक्ट एक के बाद एक चलाएँ"
            setOnClickListener { chainFlow() }
        })
        root.addView(CheckBox(this).apply {
            text = "प्रोजेक्ट बदलते समय वाईफाई बंद-चालू (Shizuku/Root चाहिए)"
            isChecked = prefs.getBoolean("wifiCycle", true)
            setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("wifiCycle", c).apply() }
        })
        root.addView(CheckBox(this).apply {
            text = "प्रोजेक्ट बदलते समय वीपीएन बंद-चालू (Shizuku/Root चाहिए)"
            isChecked = prefs.getBoolean("vpnCycle", false)
            setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("vpnCycle", c).apply() }
        })
        val vpnBtnView = Button(this).apply { textSize = 12f }
        fun vpnLabel() {
            val p = prefs.getString("vpnPkg", "")!!
            vpnBtnView.text = "🔒 वीपीएन ऐप: " + (if (p.isEmpty()) "चुना नहीं — दबाकर चुनें" else label(p))
        }
        vpnLabel()
        vpnBtnView.setOnClickListener { chooseVpnApp { vpnLabel() } }
        root.addView(vpnBtnView)
        fun stepBox(key: String, title: String, hintTxt: String) {
            root.addView(TextView(this).apply { text = title; textSize = 14f; setTextColor(Color.BLACK) })
            root.addView(EditText(this).apply {
                hint = hintTxt; minLines = 2; gravity = Gravity.TOP
                inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
                setText(prefs.getString(key, ""))
                addTextChangedListener(object : android.text.TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                    override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                    override fun afterTextChanged(e: android.text.Editable?) {
                        prefs.edit().putString(key, e.toString()).apply()
                    }
                })
            })
        }
        stepBox("vpnOff", "वीपीएन बंद करने के स्टेप (हर लाइन में एक बटन का टेक्स्ट, क्रम से)", "जैसे:\nDisconnect\nYes   (खाली = ऐप Force stop होगा)")
        stepBox("vpnOn", "वीपीएन चालू करने के स्टेप (हर लाइन में एक बटन का टेक्स्ट, क्रम से)", "जैसे:\nConnect\nOK   (खाली = ऐप खुलते ही खुद जुड़ता है)")

        // ---- कमांड (स्टेप) ----
        root.addView(TextView(this).apply {
            text = "कमांड (क्रम से) — लंबा दबाकर हटाएँ"; textSize = 18f; setTextColor(Color.BLACK)
        })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val input = EditText(this).apply { hint = "बटन का टेक्स्ट, जैसे: Cancel" }
        row.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(Button(this).apply {
            text = "जोड़ें"
            setOnClickListener {
                val t = input.text.toString().trim()
                if (t.isNotEmpty()) {
                    val s = savedSteps(); s.add(t); saveSteps(s)
                    input.setText(""); refresh()
                }
            }
        })
        root.addView(row)
        if (Build.VERSION.SDK_INT < 30) {   // Android 10 के लिए
            root.addView(Button(this).apply {
                text = "स्क्रीन कैप्चर अनुमति दें (Android 10, फोटो कमांड के लिए)"
                setOnClickListener {
                    val m = getSystemService(MediaProjectionManager::class.java)
                    startActivityForResult(m.createScreenCaptureIntent(), 88)
                }
            })
        }
        root.addView(Button(this).apply {
            text = "🖼 फोटो कमांड जोड़ें (जैसे क्रॉस का फोटो)"
            setOnClickListener {
                startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }, 77)
            }
        })
        root.addView(Button(this).apply {
            text = "📸 स्क्रीनशॉट जोड़ें (स्क्रीन मिले तभी कमांड चले)"
            setOnClickListener {
                startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }, 79)
            }
        })
        root.addView(Button(this).apply {
            text = "↔ स्वाइप / स्क्रॉल कमांड जोड़ें"
            setOnClickListener { addSwipeFlow() }
        })
        stepList = ListView(this)
        root.addView(stepList, LinearLayout.LayoutParams(-1, (240 * resources.displayMetrics.density).toInt()))

        // ---- ऐप ----
        root.addView(TextView(this).apply {
            text = "ऐप (टैप करने पर 🚀 बूस्ट होकर खुलेगा और कमांड चलेंगे)"; textSize = 18f; setTextColor(Color.BLACK)
        })
        status = TextView(this).apply {
            textSize = 15f; setTextColor(Color.parseColor("#1565C0"))
            setOnClickListener { showFailed() }
        }
        root.addView(status)
        appList = ListView(this)
        root.addView(appList, LinearLayout.LayoutParams(-1, (280 * resources.displayMetrics.density).toInt()))
        // ---- रिव्यू फोटो (दोबारा चेक के लिए; सभी ऐप के लिए एक ही) ----
        reviewInfo = TextView(this).apply { textSize = 14f; setTextColor(Color.parseColor("#E65100")) }
        root.addView(reviewInfo)
        reviewBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(reviewBox)
        val revRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        revRow.addView(Button(this).apply {
            text = "✅ रिव्यू फोटो जोड़ें (कमांड नंबर के साथ)"; textSize = 12f
            setOnClickListener {
                startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }, 78)
            }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        revRow.addView(Button(this).apply {
            text = "🗑 सभी रिव्यू फोटो हटाएँ"; textSize = 12f
            setOnClickListener {
                reviewImgs().forEach { File(filesDir, it.substringAfter("|")).delete() }
                prefs.edit().remove("reviewImgs").apply(); updateReviewInfo()
            }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(revRow)
        root.addView(Button(this).apply {
            text = "▶ सभी ऐप चलाएँ (अधूरे अपने-आप दोहराएँ)"
            setOnClickListener {
                val svc = ControlService.instance
                val apps = savedApps().distinct()
                if (svc == null) {
                    Toast.makeText(this@MainActivity, "पहले Accessibility चालू करें", Toast.LENGTH_LONG).show()
                } else if (apps.isNotEmpty()) {
                    if (!prefs.getBoolean("ran", false)) {
                        // पहली बार: शुरू में सब 'बाकी'; पूरा होते ही हटते जाते हैं
                        prefs.edit().putString("failed", apps.joinToString("\n")).putBoolean("ran", true).apply()
                        svc.startQueue(apps, savedSteps(), true)
                    } else {
                        // ✔ सिर्फ़ 'रीस्टार्ट' से हटते हैं; यहाँ सिर्फ़ बाकी ऐप चलेंगे
                        val pending = failedList().filter { it in apps }.distinct()
                        if (pending.isEmpty())
                            Toast.makeText(this@MainActivity, "सारे ऐप ✔ हैं — दोबारा चलाने के लिए 🔄 रीस्टार्ट दबाएँ", Toast.LENGTH_LONG).show()
                        else svc.startQueue(pending, savedSteps(), true)
                    }
                }
            }
        })
        root.addView(Button(this).apply {
            text = "↻ सिर्फ़ अधूरे चलाएँ (अपने-आप दोहराएँ)"
            setOnClickListener {
                val svc = ControlService.instance
                val f = failedList().filter { it in savedApps() }.distinct()
                if (svc == null) {
                    Toast.makeText(this@MainActivity, "पहले Accessibility चालू करें", Toast.LENGTH_LONG).show()
                } else if (f.isEmpty()) {
                    Toast.makeText(this@MainActivity, "कोई अधूरा ऐप नहीं", Toast.LENGTH_SHORT).show()
                } else svc.startQueue(f, savedSteps(), true, true)
            }
        })
        root.addView(Button(this).apply {
            text = "🔄 रीस्टार्ट (सारे ✔ हटाकर फिर से तैयार करें)"
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("सारे ✔ हटा दें?")
                    .setMessage("सभी ऐप फिर से काम के लिए उपलब्ध हो जाएँगे।")
                    .setPositiveButton("हाँ, रीस्टार्ट") { _, _ ->
                        prefs.edit().remove("failed").putBoolean("ran", false).apply()
                        refresh()
                    }
                    .setNegativeButton("रद्द", null).show()
            }
        })
        root.addView(Button(this).apply {
            text = "+"; textSize = 28f
            setOnClickListener { showAllApps() }
        }, LinearLayout.LayoutParams(-1, -2).apply { gravity = Gravity.END })

        // पूरा पेज एक साथ स्क्रॉल होता है; दोनों लिस्ट अपनी पूरी लंबाई में दिखती हैं (कुछ छुपता नहीं)
        setContentView(ScrollView(this).apply { addView(root) })
        refresh()
    }

    private fun reviewImgs(): MutableList<String> =
        prefs.getString("reviewImgs", "")!!.split("\n").filter { it.isNotBlank() }.toMutableList()

    private fun updateReviewInfo() {
        val l = reviewImgs()
        reviewInfo.text = if (l.isEmpty()) "रिव्यू फोटो: कोई नहीं"
            else "रिव्यू फोटो: ${l.size} (दोबारा चेक में सिर्फ़ उसी कमांड नंबर पर खोजी जाएगी · हटाने के लिए दबाएँ)"
        reviewBox.removeAllViews()
        val d = resources.displayMetrics.density
        for (line in l) {
            val num = line.substringBefore("|", "0")
            val name = line.substringAfter("|")
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(0, (4 * d).toInt(), 0, (4 * d).toInt())
                setOnClickListener {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("यह रिव्यू फोटो हटाएँ?")
                        .setPositiveButton("हटाएँ") { _, _ ->
                            File(filesDir, name).delete()
                            val r = reviewImgs(); r.remove(line)
                            prefs.edit().putString("reviewImgs", r.joinToString("\n")).apply()
                            updateReviewInfo()
                        }
                        .setNegativeButton("रहने दें", null).show()
                }
            }
            val bmp = try { BitmapFactory.decodeFile(File(filesDir, name).path) } catch (e: Throwable) { null }
            row.addView(ImageView(this).apply { bmp?.let { setImageBitmap(it) }; adjustViewBounds = true; scaleType = ImageView.ScaleType.FIT_CENTER },
                LinearLayout.LayoutParams((64 * d).toInt(), (64 * d).toInt()))
            row.addView(TextView(this).apply {
                text = if (num == "0") "  हर कमांड पर" else "  कमांड $num पर काम करेगी"
                textSize = 15f; setTextColor(Color.BLACK)
            })
            reviewBox.addView(row)
        }
    }

    /** रिव्यू फोटो किस कमांड नंबर पर खोजी जाए, यह पूछो */
    private fun askReviewCommand(name: String) {
        val steps = savedSteps()
        if (steps.isEmpty()) {
            File(filesDir, name).delete()
            Toast.makeText(this, "पहले कमांड जोड़ें, फिर रिव्यू फोटो", Toast.LENGTH_LONG).show(); return
        }
        val items = steps.mapIndexed { i, st -> "कमांड ${i + 1}:  ${show(st)}" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("यह रिव्यू फोटो किस कमांड पर देखनी है?")
            .setItems(items) { _, i ->
                val l = reviewImgs(); l.add("${i + 1}|$name")
                prefs.edit().putString("reviewImgs", l.joinToString("\n")).apply()
                updateReviewInfo()
            }
            .setNegativeButton("रद्द") { _, _ -> File(filesDir, name).delete() }
            .setOnCancelListener { File(filesDir, name).delete() }
            .show()
    }

    private fun refresh() {
        updateReviewInfo()
        val cur = curProject()
        projLabel.text = if (cur.isNotEmpty()) "📁 प्रोजेक्ट: $cur  (बदलाव अपने-आप सेव)"
            else "📁 प्रोजेक्ट: बिना नाम — 'सेव' दबाकर नाम दें"
        val steps = savedSteps()
        stepList.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1,
            steps.mapIndexed { i, s -> "कमांड ${i + 1}:  ${show(s)}" })
        stepList.setOnItemClickListener { _, _, i, _ -> editStepFlow(i) }
        stepList.setOnItemLongClickListener { _, _, i, _ ->
            val s = savedSteps(); s.removeAt(i); saveSteps(s); refresh(); true
        }

        val pkgs = savedApps()
        val ran = prefs.getBoolean("ran", false)
        val fs = failedList().toSet()
        appList.adapter = object : ArrayAdapter<String>(
            this, android.R.layout.simple_list_item_1, pkgs.map { label(it) }) {
            override fun getView(pos: Int, v: android.view.View?, p: android.view.ViewGroup): android.view.View {
                val t = super.getView(pos, v, p) as TextView
                val done = ran && pkgs[pos] !in fs
                t.text = (if (done) "✅ " else if (ran) "⚠ " else "") + getItem(pos)
                t.setTextColor(
                    if (done) Color.parseColor("#2E7D32")
                    else if (ran) Color.parseColor("#E65100") else Color.BLACK)
                return t
            }
        }
        appList.setOnItemClickListener { _, _, i, _ -> launch(pkgs[i]) }
        appList.setOnItemLongClickListener { _, _, i, _ ->
            val s = savedApps(); s.removeAt(i); saveApps(s); refresh(); true
        }
        fit(stepList); fit(appList)
        updateStatus()
    }

    /** लिस्ट को उसकी पूरी लंबाई दो, ताकि ScrollView में कोई आइटम छुपे नहीं */
    private fun fit(lv: ListView) {
        val a = lv.adapter ?: return
        val w = if (lv.width > 0) lv.width else resources.displayMetrics.widthPixels - 64
        var total = 0
        for (i in 0 until a.count) {
            val v = a.getView(i, null, lv)
            v.measure(android.view.View.MeasureSpec.makeMeasureSpec(w, android.view.View.MeasureSpec.AT_MOST),
                android.view.View.MeasureSpec.makeMeasureSpec(0, android.view.View.MeasureSpec.UNSPECIFIED))
            total += v.measuredHeight
        }
        val minH = (60 * resources.displayMetrics.density).toInt()
        val lp = lv.layoutParams
        lp.height = maxOf(minH, total + lv.dividerHeight * maxOf(0, a.count - 1) + 8)
        lv.layoutParams = lp
    }

    override fun onResume() {
        super.onResume(); refresh(); updateBoostInfo(); Shell.autoConnect { updateBoostInfo() }
        val m = prefs.getString("stopMsg", "") ?: ""
        if (m.isNotEmpty()) {
            prefs.edit().remove("stopMsg").apply()
            AlertDialog.Builder(this).setTitle("⚠ प्रोजेक्ट रुका").setMessage(m).setPositiveButton("ठीक है", null).show()
        }
    }

    private fun failedList(): List<String> =
        prefs.getString("failed", "")!!.split("\n").filter { it.isNotBlank() }

    private fun updateStatus() {
        val apps = savedApps().distinct()
        val f = failedList().filter { it in apps }.distinct()
        status.text = if (prefs.getBoolean("ran", false))
            "कुल ${apps.size} ऐप · पूरे ${apps.size - f.size} · अधूरे/बाकी ${f.size}  (सूची देखने के लिए दबाएँ)"
        else "कुल ${apps.size} ऐप"
    }

    private fun showFailed() {
        val apps = savedApps()
        val f = failedList().filter { it in apps }.distinct()
        AlertDialog.Builder(this)
            .setTitle("अधूरे/बाकी ऐप (${f.size})")
            .setItems(f.map { label(it) }.toTypedArray(), null)
            .setPositiveButton("ठीक है", null).show()
    }

    private fun show(s: String) = prettyStep(s)

    private var pendingSwipeDir: String? = null

    /** स्वाइप कमांड जोड़ना: दिशा -> कहाँ पर (टेक्स्ट / फोटो / स्क्रीन का बीच) */
    private fun addSwipeFlow() {
        val dirs = arrayOf("left", "right", "up", "down")
        val names = arrayOf("⬅ बाएँ (उंगली दाएँ→बाएँ)", "➡ दाएँ (उंगली बाएँ→दाएँ)",
            "⬆ ऊपर (उंगली नीचे→ऊपर)", "⬇ नीचे (उंगली ऊपर→नीचे)")
        AlertDialog.Builder(this).setTitle("स्वाइप / स्क्रॉल की दिशा")
            .setItems(names) { _, i ->
                val d = dirs[i]
                AlertDialog.Builder(this).setTitle("कहाँ पर स्वाइप करें?")
                    .setItems(arrayOf("किसी टेक्स्ट पर", "किसी फोटो पर", "स्क्रीन के बीच से")) { _, w ->
                        when (w) {
                            0 -> {
                                val et = EditText(this).apply { hint = "स्क्रीन पर लिखा टेक्स्ट, जैसे: Please" }
                                AlertDialog.Builder(this).setTitle("इस टेक्स्ट वाली जगह से स्वाइप")
                                    .setView(et)
                                    .setPositiveButton("जोड़ें") { _, _ ->
                                        val t = et.text.toString().trim()
                                        if (t.isNotEmpty()) addStep("SWIPE:$d:$t")
                                    }
                                    .setNegativeButton("रद्द", null).show()
                            }
                            1 -> {
                                pendingSwipeDir = d
                                startActivityForResult(
                                    Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }, 77)
                            }
                            else -> addStep("SWIPE:$d:")
                        }
                    }.show()
            }.show()
    }


    // ---------- एक कमांड को वहीं बदलना ----------
    private var editIdx = -1
    private var editTarget = ""

    private fun splitStep(raw: String): Pair<String?, String> =
        if (raw.startsWith("GATE:")) Pair(raw.removePrefix("GATE:").substringBefore(":"), raw.removePrefix("GATE:").substringAfter(":"))
        else Pair(null, raw)

    private fun joinStep(gate: String?, inner: String) = if (gate != null) "GATE:$gate:$inner" else inner

    // कमांड के आख़िर में "~~सेकंड" जुड़ा हो तो वह उस कमांड के बाद रुकने का टाइमर है
    private fun splitDelay(raw: String): Pair<String, Int> =
        if (raw.contains("~~")) Pair(raw.substringBeforeLast("~~"), raw.substringAfterLast("~~").toIntOrNull() ?: 0)
        else Pair(raw, 0)
    private fun delaySuffix(d: Int) = if (d > 0) "~~$d" else ""

    private fun setStep(i: Int, v: String) {   // टाइमर वैसा ही रहता है
        val l = savedSteps(); if (i >= l.size) return
        l[i] = v + delaySuffix(splitDelay(l[i]).second); saveSteps(l); refresh()
    }
    private fun setDelay(i: Int, d: Int) {
        val l = savedSteps(); if (i >= l.size) return
        l[i] = splitDelay(l[i]).first + delaySuffix(d.coerceIn(0, 3600)); saveSteps(l); refresh()
    }

    private fun pickReplacement(i: Int, target: String) {
        editIdx = i; editTarget = target
        startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }, 80)
    }

    private fun askText(title: String, preset: String, hintTxt: String, onOk: (String) -> Unit) {
        val et = EditText(this).apply { setText(preset); hint = hintTxt; setSelection(text.length) }
        AlertDialog.Builder(this).setTitle(title).setView(et)
            .setPositiveButton("सेव") { _, _ -> onOk(et.text.toString().trim()) }
            .setNegativeButton("रद्द", null).show()
    }

    private fun editStepFlow(i: Int) {
        val steps = savedSteps(); if (i >= steps.size) return
        val curDelay = splitDelay(steps[i]).second
        val (gate, inner) = splitStep(splitDelay(steps[i]).first)
        val labels = ArrayList<String>(); val acts = ArrayList<() -> Unit>()
        fun add(l: String, a: () -> Unit) { labels.add(l); acts.add(a) }

        if (gate != null) {
            add("🖼 स्क्रीनशॉट (शर्त) बदलें") { pickReplacement(i, "gate") }
            add("❌ स्क्रीनशॉट शर्त हटाएँ (कमांड रहेगी)") {
                File(filesDir, gate).delete(); setStep(i, inner)
            }
        }
        if (inner.startsWith("SWIPE:")) {
            val p = inner.split(":", limit = 3); val dir = p[1]; val tgt = p.getOrElse(2) { "" }
            add("↔ दिशा बदलें") {
                val dirs = arrayOf("left", "right", "up", "down")
                AlertDialog.Builder(this).setTitle("नई दिशा")
                    .setItems(arrayOf("⬅ बाएँ", "➡ दाएँ", "⬆ ऊपर", "⬇ नीचे")) { _, k ->
                        setStep(i, joinStep(gate, "SWIPE:${dirs[k]}:$tgt"))
                    }.show()
            }
            if (tgt.startsWith("IMG:")) add("🖼 स्वाइप वाली फोटो बदलें") { pickReplacement(i, "inner") }
            add("✏ जगह (टेक्स्ट) बदलें / खाली = स्क्रीन का बीच") {
                askText("इस टेक्स्ट वाली जगह से स्वाइप", if (tgt.startsWith("IMG:")) "" else tgt, "स्क्रीन पर लिखा टेक्स्ट") { t ->
                    if (tgt.startsWith("IMG:")) File(filesDir, tgt.substringAfterLast(":")).delete()
                    setStep(i, joinStep(gate, "SWIPE:$dir:${t.replace(":", " ")}"))
                }
            }
        } else if (inner.startsWith("IMG:")) {
            val mode = inner.split(":")[1]
            add("🖼 फोटो बदलें") { pickReplacement(i, "inner") }
            add(if (mode == "req") "⏭ वैकल्पिक करें (न मिले तो आगे बढ़ो)" else "🔁 ज़रूरी करें (खोजते रहो)") {
                setStep(i, joinStep(gate, "IMG:${if (mode == "req") "opt" else "req"}:${inner.substringAfterLast(":")}"))
            }
        } else {
            add("✏ कमांड का टेक्स्ट बदलें") {
                askText("कमांड ${i + 1} बदलें", inner, "बटन का टेक्स्ट") { t ->
                    val v = t.replace(":", " ")
                    if (v.isNotEmpty()) setStep(i, joinStep(gate, v))
                }
            }
        }
        add("🗑 यह कमांड हटाएँ") { val l = savedSteps(); if (i < l.size) { l.removeAt(i); saveSteps(l); refresh() } }

        // ---- सजा हुआ एडिट पेज: ऊपर टाइमर, नीचे बदलाव के बटन ----
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), dp(8)) }
        col.addView(TextView(this).apply {
            text = show(splitDelay(steps[i]).first); textSize = 15f; setTextColor(Color.parseColor("#37474F"))
            setPadding(0, 0, 0, dp(14))
        })
        col.addView(TextView(this).apply {
            text = "⏱ इस कमांड के बाद कितनी देर रुकें?"; textSize = 14f
            setTypeface(typeface, android.graphics.Typeface.BOLD); setPadding(0, 0, 0, dp(6))
        })
        val et = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setText(if (curDelay > 0) curDelay.toString() else ""); hint = "0"
            gravity = Gravity.CENTER; textSize = 20f
        }
        val timeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        timeRow.addView(et, LinearLayout.LayoutParams(dp(110), -2))
        timeRow.addView(TextView(this).apply { text = "  सेकंड  (0 = बिना रुके)"; textSize = 14f })
        col.addView(timeRow)
        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(8), 0, dp(4)) }
        for (sec in intArrayOf(0, 5, 10, 15, 20, 30, 60)) {
            chips.addView(Button(this).apply {
                text = if (sec == 0) "नहीं" else "${sec}s"; textSize = 13f; isAllCaps = false
                minWidth = 0; minimumWidth = 0; setPadding(dp(14), 0, dp(14), 0)
                setOnClickListener { et.setText(if (sec == 0) "" else sec.toString()); et.setSelection(et.text.length) }
            }, LinearLayout.LayoutParams(-2, dp(44)).apply { rightMargin = dp(6) })
        }
        col.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(chips) })

        col.addView(View(this).apply { setBackgroundColor(Color.parseColor("#E0E0E0")) },
            LinearLayout.LayoutParams(-1, dp(1)).apply { topMargin = dp(14); bottomMargin = dp(10) })
        col.addView(TextView(this).apply {
            text = "✏ बदलाव"; textSize = 14f; setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, 0, 0, dp(6))
        })
        lateinit var dlg: AlertDialog
        val saveDelay = { setDelay(i, et.text.toString().trim().toIntOrNull() ?: 0) }
        labels.forEachIndexed { k, l ->
            col.addView(Button(this).apply {
                text = l; isAllCaps = false; textSize = 14f; gravity = Gravity.START or Gravity.CENTER_VERTICAL
                setPadding(dp(14), 0, dp(14), 0)
                setOnClickListener { saveDelay(); dlg.dismiss(); acts[k]() }
            }, LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(6) })
        }
        dlg = AlertDialog.Builder(this).setTitle("कमांड ${i + 1}")
            .setView(ScrollView(this).apply { addView(col) })
            .setPositiveButton("सेव") { _, _ -> saveDelay() }
            .setNegativeButton("बंद", null).create()
        dlg.show()
    }

    private fun addStep(s: String) { val l = savedSteps(); l.add(s); saveSteps(l); refresh() }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 88 && res == RESULT_OK && data != null) {
            startForegroundService(Intent(this, CaptureService::class.java)
                .putExtra("code", res).putExtra("data", data))
            return
        }
        if (req == 78) {
            val u = data?.data
            if (res == RESULT_OK && u != null) {
                val b = contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it) }
                if (b != null) {
                    val nm = "review_${System.currentTimeMillis()}.png"
                    FileOutputStream(File(filesDir, nm)).use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }
                    askReviewCommand(nm)
                }
            }
            return
        }
        if (req == 79) {            // स्क्रीनशॉट चुना → अब बताओ कौन-सी कमांड इससे जुड़ेगी
            val u = data?.data
            if (res == RESULT_OK && u != null) {
                val bm = contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it) }
                if (bm != null) {
                    val nm = "gate_${System.currentTimeMillis()}.png"
                    FileOutputStream(File(filesDir, nm)).use { bm.compress(Bitmap.CompressFormat.PNG, 100, it) }
                    askGateCommand(nm)
                }
            }
            return
        }
        if (req == 80) {            // किसी कमांड की फोटो/स्क्रीनशॉट बदलना
            val u = data?.data
            val i = editIdx; val tgt = editTarget
            editIdx = -1
            if (res == RESULT_OK && u != null && i >= 0) {
                val bm = contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it) }
                val steps = savedSteps()
                if (bm != null && i < steps.size) {
                    val nm = "edit_${System.currentTimeMillis()}.png"
                    FileOutputStream(File(filesDir, nm)).use { bm.compress(Bitmap.CompressFormat.PNG, 100, it) }
                    val (baseS, dly) = splitDelay(steps[i])
                    val (gate, inner) = splitStep(baseS)
                    if (tgt == "gate" && gate != null) {
                        File(filesDir, gate).delete()
                        steps[i] = joinStep(nm, inner) + delaySuffix(dly)
                    } else if (inner.startsWith("IMG:") || inner.contains(":IMG:")) {
                        val old = inner.substringAfterLast(":")
                        File(filesDir, old).delete()
                        steps[i] = joinStep(gate, inner.substringBeforeLast(":") + ":" + nm) + delaySuffix(dly)
                    }
                    saveSteps(steps); refresh()
                }
            }
            return
        }
        if (req == 77 && res != RESULT_OK) { pendingSwipeDir = null; return }
        if (req != 77 || res != RESULT_OK) return
        val uri = data?.data ?: return
        val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } ?: return
        val name = "step_${System.currentTimeMillis()}.png"
        FileOutputStream(File(filesDir, name)).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        val sd = pendingSwipeDir
        if (sd != null) {            // फोटो पर स्वाइप
            pendingSwipeDir = null
            addStep("SWIPE:$sd:IMG:req:$name")
            return
        }
        askImgMode(name)
    }

    /** स्क्रीनशॉट किस कमांड से जुड़े: पुरानी कमांड चुनो या नई लिखो */
    private fun askGateCommand(shot: String) {
        val steps = savedSteps()
        val newText = {
            val et = EditText(this).apply { hint = "बटन का टेक्स्ट, जैसे: Cancel" }
            AlertDialog.Builder(this).setTitle("स्क्रीन मिलने पर कौन-सी कमांड चले?")
                .setView(et)
                .setPositiveButton("जोड़ें") { _, _ ->
                    val t = et.text.toString().trim().replace(":", " ")
                    if (t.isNotEmpty()) addStep("GATE:$shot:$t") else File(filesDir, shot).delete()
                }
                .setNegativeButton("रद्द") { _, _ -> File(filesDir, shot).delete() }
                .setOnCancelListener { File(filesDir, shot).delete() }
                .show()
        }
        if (steps.isEmpty()) { newText(); return }
        val items = steps.mapIndexed { i, st -> "कमांड ${i + 1}:  ${show(st)}" }.toMutableList()
        items.add("➕ नई कमांड लिखें")
        AlertDialog.Builder(this)
            .setTitle("यह स्क्रीनशॉट किस कमांड से जोड़ें?")
            .setItems(items.toTypedArray()) { _, i ->
                if (i == steps.size) { newText(); return@setItems }
                val cur = steps[i]
                val inner = if (cur.startsWith("GATE:")) cur.removePrefix("GATE:").substringAfter(":") else cur
                steps[i] = "GATE:$shot:$inner"
                saveSteps(steps); refresh()
            }
            .setNegativeButton("रद्द") { _, _ -> File(filesDir, shot).delete() }
            .setOnCancelListener { File(filesDir, shot).delete() }
            .show()
    }

    private fun askImgMode(name: String) {
        AlertDialog.Builder(this)
            .setTitle("यह फोटो स्क्रीन पर न मिले तो?")
            .setPositiveButton("खोजते रहो (ज़रूरी)") { _, _ -> addStep("IMG:req:$name") }
            .setNegativeButton("छोड़कर आगे बढ़ो (वैकल्पिक)") { _, _ -> addStep("IMG:opt:$name") }
            .show()
    }

    private fun launch(pkg: String) {
        val svc = ControlService.instance
        if (svc == null) {
            Toast.makeText(this, "पहले Accessibility चालू करें", Toast.LENGTH_LONG).show(); return
        }
        val intent = packageManager.getLaunchIntentForPackage(pkg) ?: return
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val go = { svc.startSequence(savedSteps()); startActivity(intent) }
        if (prefs.getBoolean("boostBefore", true)) Shell.boost(this, setOf(pkg)) { go() } else go()
    }

    private fun addApps(list: List<String>) {
        val s = savedApps()
        val newOnes = list.filter { it !in s }
        for (p in newOnes) s.add(p)
        saveApps(s)
        if (prefs.getBoolean("ran", false) && newOnes.isNotEmpty())   // नया ऐप 'बाकी' रहे, झूठा ✔ नहीं
            prefs.edit().putString("failed", (failedList() + newOnes).distinct().joinToString("\n")).apply()
        refresh()
    }

    private fun showAllApps() {
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = packageManager.queryIntentActivities(main, 0)
            .map { it.activityInfo.packageName to it.loadLabel(packageManager).toString() }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }
        val already = savedApps().toSet()
        val checked = BooleanArray(apps.size) { apps[it].first in already }
        AlertDialog.Builder(this)
            .setTitle("ऐप चुनें (✔ = पहले से जुड़ा, ${already.size})")
            .setMultiChoiceItems(apps.map { it.second }.toTypedArray(), checked) { _, i, c -> checked[i] = c }
            .setPositiveButton("चुने हुए जोड़ें") { _, _ ->
                addApps(apps.filterIndexed { i, _ -> checked[i] }.map { it.first })
            }
            .setNeutralButton("सारे जोड़ें") { _, _ -> addApps(apps.map { it.first }) }
            .setNegativeButton("रद्द", null)
            .show()
    }
}
