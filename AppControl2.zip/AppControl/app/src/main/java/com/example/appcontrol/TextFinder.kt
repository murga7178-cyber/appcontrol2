package com.example.appcontrol

import android.graphics.Bitmap
import android.graphics.Rect
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

/** स्क्रीन/फोटो में लिखे अक्षर पढ़ना (OCR). हमेशा बैकग्राउंड थ्रेड से बुलाएँ. */
object TextFinder {
    class Hit(val text: String, val box: Rect)

    private val latin by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private val deva by lazy { TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build()) }

    /** तुलना के लिए: छोटे अक्षर, बिना खाली जगह/चिह्न (हिंदी की मात्राएँ रखकर) */
    fun norm(s: String): String = s.lowercase().filter {
        it.isLetterOrDigit() || Character.getType(it).let { t ->
            t == Character.NON_SPACING_MARK.toInt() || t == Character.COMBINING_SPACING_MARK.toInt()
        }
    }

    /** kind: 0 = अंग्रेज़ी/नंबर, 1 = हिंदी */
    fun read(b: Bitmap, kind: Int): List<Hit> = try {
        val rec = if (kind == 0) latin else deva
        val r = Tasks.await(rec.process(InputImage.fromBitmap(b, 0)))
        r.textBlocks.flatMap { it.lines }.mapNotNull { l ->
            val t = norm(l.text)
            val bx = l.boundingBox
            if (t.isNotEmpty() && bx != null) Hit(t, bx) else null
        }
    } catch (e: Throwable) { emptyList() }

    /** 0..1 — कितने मिलते-जुलते अक्षर */
    fun sim(a: String, b: String): Double {
        if (a.isEmpty() || b.isEmpty()) return 0.0
        if (a == b) return 1.0
        if (minOf(a.length, b.length) >= 3 && (a.contains(b) || b.contains(a))) return 0.9
        val n = a.length; val m = b.length
        var prev = IntArray(m + 1) { it }
        for (i in 1..n) {
            val cur = IntArray(m + 1); cur[0] = i
            for (j in 1..m) cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
            prev = cur
        }
        return 1.0 - prev[m].toDouble() / maxOf(n, m)
    }
}
