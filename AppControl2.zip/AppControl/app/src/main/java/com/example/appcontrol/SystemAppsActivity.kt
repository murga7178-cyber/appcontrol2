package com.example.appcontrol

import android.app.AlertDialog
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.*

class SystemAppsActivity : ToolPage() {
    // बहुत ज़रूरी सिस्टम ऐप्स लिस्ट में दिखाई ही नहीं जातीं
    private val protectedPkgs = setOf(
        "android", "com.android.systemui", "com.android.settings", "com.android.phone",
        "com.android.providers.settings", "com.android.providers.telephony", "com.android.shell"
    )

    override fun onCreate(b: Bundle?) { super.onCreate(b); render() }
    private var firstResume = true
    // पावर टूल्स से Root/Shizuku जोड़कर लौटने पर सूची दोबारा बने
    override fun onResume() { super.onResume(); if (firstResume) firstResume = false else render() }

    private fun render() {
        page("🗑️ सिस्टम ऐप्स")
        if (!Shell.rootGranted && !Shell.shizukuReady()) {
            box.addView(tv("पहले Root या Shizuku जोड़ें (ये बिना दोनों के नहीं हो सकता)।"))
            box.addView(btn("⚡ पावर टूल्स खोलें") { startActivity(Intent(this, PowerActivity::class.java)) })
            return
        }
        val pm = packageManager
        val home = pm.resolveActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)?.activityInfo?.packageName
        val apps = pm.getInstalledApplications(PackageManager.MATCH_UNINSTALLED_PACKAGES)
            .filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) != 0 && it.packageName !in protectedPkgs &&
                it.packageName != home && it.packageName != packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }
        box.addView(tv("${apps.size} सिस्टम ऐप्स (सबसे ज़रूरी वाली छुपाई गई हैं)। 'बंद' या 'हटाई' हुई ऐप्स भी यहीं से वापस लाई जा सकती हैं।", 13f))
        val checks = ArrayList<Pair<CheckBox, String>>()
        apps.forEach { a ->
            val tag = when {
                (a.flags and ApplicationInfo.FLAG_INSTALLED) == 0 -> " (हटाई हुई)"
                !a.enabled -> " (बंद)"
                else -> ""
            }
            val cb = CheckBox(this).apply { text = "${a.loadLabel(pm)}$tag\n${a.packageName}"; textSize = 13f }
            checks.add(cb to a.packageName); box.addView(cb)
        }
        fun act(verb: String, cmdFor: (String) -> String) {
            val sel = checks.filter { it.first.isChecked }.map { it.second }
            if (sel.isEmpty()) { toast("पहले कुछ चुनें"); return }
            AlertDialog.Builder(this).setTitle("$verb: ${sel.size} ऐप्स?").setMessage(sel.joinToString("\n"))
                .setPositiveButton("हाँ") { _, _ ->
                    Shell.best(sel.joinToString("; ") { cmdFor(it) }) { toast("हो गया"); render() }
                }
                .setNegativeButton("रद्द", null).show()
        }
        box.addView(btn("⏸ चुनी हुई बंद करें (disable)") { act("बंद करें") { "pm disable-user --user 0 $it" } })
        box.addView(btn("❌ चुनी हुई हटाएँ (user 0)") { act("हटाएँ") { "pm uninstall --user 0 $it" } })
        box.addView(btn("↩️ चुनी हुई वापस लाएँ / चालू करें") { act("वापस लाएँ") { "pm enable $it; cmd package install-existing $it" } })
    }
}
