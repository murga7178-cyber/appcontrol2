package com.example.appcontrol

import android.content.SharedPreferences

/** हर प्रोजेक्ट की अपनी सेटिंग (वीपीएन, वाईफाई, समय, बंद करने का तरीका आदि) उसी प्रोजेक्ट के साथ सेव होती है */
object ProjSettings {
    val keys = listOf(
        "vpnPkg", "vpnCycle", "ipOn", "ipEvery", "ipWord", "wifiCycle", "vpnOn", "vpnOff", "vpnCountry", "vpnCountryNames",
        "limit", "closeMode", "gatePct", "reviewImgs", "boostBefore", "missCycle", "maxRounds", "missApps", "fewTries"
    )
    private const val NONE = "\u0000none"

    /** अभी की सेटिंग इस प्रोजेक्ट में सेव करो */
    fun snap(p: SharedPreferences, name: String) {
        if (name.isEmpty()) return
        val all = p.all
        val e = p.edit()
        for (k in keys) {
            val pk = "s_${name}_$k"
            when (val v = all[k]) {
                is String -> e.putString(pk, v)
                is Boolean -> e.putBoolean(pk, v)
                is Int -> e.putInt(pk, v)
                is Long -> e.putLong(pk, v)
                is Float -> e.putFloat(pk, v)
                else -> e.putString(pk, NONE)
            }
        }
        e.putBoolean("s_${name}__saved", true).apply()
    }

    /** इस प्रोजेक्ट की सेव सेटिंग चालू करो; पुराना प्रोजेक्ट (जिसमें सेटिंग सेव नहीं थी) हो तो false और सेटिंग जस की तस */
    fun apply(p: SharedPreferences, name: String): Boolean {
        if (name.isEmpty() || !p.getBoolean("s_${name}__saved", false)) return false
        val all = p.all
        val e = p.edit()
        for (k in keys) {
            val v = all["s_${name}_$k"]
            when {
                v == null || v == NONE -> e.remove(k)
                v is String -> e.putString(k, v)
                v is Boolean -> e.putBoolean(k, v)
                v is Int -> e.putInt(k, v)
                v is Long -> e.putLong(k, v)
                v is Float -> e.putFloat(k, v)
            }
        }
        e.apply()
        return true
    }

    fun delete(p: SharedPreferences, name: String) {
        val e = p.edit()
        for (k in keys) e.remove("s_${name}_$k")
        e.remove("s_${name}__saved").apply()
    }
}
