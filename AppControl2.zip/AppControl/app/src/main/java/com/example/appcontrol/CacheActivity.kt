package com.example.appcontrol

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.widget.*

class CacheActivity : ToolPage() {
    override fun onCreate(b: Bundle?) { super.onCreate(b); render() }

    private fun render() {
        page("🧹 कैश कंट्रोल")
        val p = CachePolicy.prefs(this)
        val on = CachePolicy.enabled(this)
        val withBoost = CachePolicy.withBoost(this)
        box.addView(tv("कैश साफ करने पर ऐप्स का अस्थायी डेटा हटता है और ऐप्स उसे दोबारा इंटरनेट से डाउनलोड करती हैं (मोबाइल डेटा खर्च होता है)। इसलिए कंट्रोल आपके हाथ में है।\n\nबूस्ट का 'बैकग्राउंड ऐप्स बंद' और 'रैम खाली' आपका डाउनलोड किया डेटा नहीं हटाता।", 13f))
        box.addView(Switch(this).apply {
            text = "कैश साफ करना चालू"; isChecked = on
            setOnCheckedChangeListener { _, c -> p.edit().putBoolean("cacheOn", c).apply() }
        })
        box.addView(Switch(this).apply {
            text = "बूस्ट के साथ कैश भी साफ करें"; isChecked = withBoost
            setOnCheckedChangeListener { _, c -> p.edit().putBoolean("cacheWithBoost", c).apply() }
        })
        val keep = CachePolicy.keep(this)
        box.addView(btn("🛡 इन ऐप्स का कैश कभी साफ न करें (${keep.size})") { pickKeep() })
        if (keep.isNotEmpty()) {
            val pm = packageManager
            box.addView(tv(keep.joinToString(", ") {
                try { pm.getApplicationInfo(it, 0).loadLabel(pm).toString() } catch (e: Exception) { it }
            }, 12f))
        }
        box.addView(tv("ऐप छोड़ने की सुविधा सिर्फ़ Root में चलती है। Shizuku में कैश सब का एक साथ साफ होता है।", 12f))
        val out = tv("", 13f)
        box.addView(btn("🧹 अभी कैश साफ करें") {
            out.text = "चल रहा है..."
            CachePolicy.clear(this) { out.text = it }
        })
        box.addView(out)
    }

    private fun pickKeep() {
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName }.distinctBy { it.first }.sortedBy { it.second.lowercase() }
        val keep = CachePolicy.keep(this).toMutableSet()
        AlertDialog.Builder(this).setTitle("इनका कैश कभी साफ न करें")
            .setMultiChoiceItems(apps.map { it.second }.toTypedArray(), BooleanArray(apps.size) { apps[it].first in keep }) { _, i, on ->
                if (on) keep.add(apps[i].first) else keep.remove(apps[i].first)
            }
            .setPositiveButton("ठीक") { _, _ -> CachePolicy.saveKeep(this, keep); render() }
            .show()
    }
}
