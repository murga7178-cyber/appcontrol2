package com.example.appcontrol

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** VPN के नीचे वाले जो IP यूज़ हो चुके उनकी फाइल (ip_used.txt): हर लाइन  IP|समय.  24 घंटे तक वही IP दोबारा नहीं लेना */
object IpLog {
    private const val DAY = 24L * 60 * 60 * 1000
    private fun f(ctx: Context) = File(ctx.filesDir, "ip_used.txt")

    private fun all(ctx: Context): List<Pair<String, Long>> = try {
        if (!f(ctx).exists()) emptyList()
        else f(ctx).readLines().mapNotNull { l ->
            val p = l.split("|")
            val ms = p.getOrNull(1)?.trim()?.toLongOrNull()
            if (p[0].isBlank() || ms == null) null else Pair(p[0].trim(), ms)
        }
    } catch (e: Exception) { emptyList() }

    /** पिछले 24 घंटे में यूज़ हुए IP (पुराने से नए) */
    fun recent(ctx: Context): List<Pair<String, Long>> {
        val now = System.currentTimeMillis()
        return all(ctx).filter { now - it.second < DAY }
    }

    fun isUsed(ctx: Context, ip: String): Boolean = recent(ctx).any { it.first == ip }

    /** IP यूज़ हुआ लिखो (पहले से 24 घंटे में लिखा हो तो पहला समय ही रहेगा) */
    fun record(ctx: Context, ip: String) {
        if (isUsed(ctx, ip)) return
        val now = System.currentTimeMillis()
        val keep = all(ctx).filter { now - it.second < 2 * DAY }
        try {
            f(ctx).writeText((keep + Pair(ip, now)).joinToString("\n") { "${it.first}|${it.second}" } + "\n")
        } catch (e: Exception) {}
    }

    fun clear(ctx: Context) {
        try { f(ctx).delete() } catch (e: Exception) {}
        try { cf(ctx).delete() } catch (e: Exception) {}
    }

    // ---- देश-वार असफल कोशिशें: किसी देश में चला हुआ IP दोबारा मिला = 1 असफल कोशिश. 5 हो जाएँ तो वह देश 24 घंटे के लिए छोड़ो ----
    const val MAX_TRIES = 5
    private fun cf(ctx: Context) = File(ctx.filesDir, "ip_country_fails.txt")
    private fun failMap(ctx: Context): MutableMap<String, Pair<Int, Long>> {
        val m = LinkedHashMap<String, Pair<Int, Long>>()
        val now = System.currentTimeMillis()
        try {
            if (cf(ctx).exists()) cf(ctx).readLines().forEach { l ->
                val p = l.split("|")
                val n = p.getOrNull(1)?.toIntOrNull(); val t = p.getOrNull(2)?.toLongOrNull()
                if (p[0].isNotBlank() && n != null && t != null && now - t < DAY) m[p[0]] = Pair(n, t)     // 24 घंटे बाद गिनती नई
            }
        } catch (e: Exception) {}
        return m
    }
    fun countryFails(ctx: Context, name: String): Int = failMap(ctx)[name.lowercase().trim()]?.first ?: 0
    fun addCountryFail(ctx: Context, name: String) {
        val k = name.lowercase().trim(); if (k.isEmpty()) return
        val m = failMap(ctx)
        val old = m[k]
        m[k] = Pair((old?.first ?: 0) + 1, old?.second ?: System.currentTimeMillis())
        try { cf(ctx).writeText(m.entries.joinToString("\n") { "${it.key}|${it.value.first}|${it.value.second}" } + "\n") } catch (e: Exception) {}
    }
    fun failedCountries(ctx: Context): List<Pair<String, Int>> = failMap(ctx).map { Pair(it.key, it.value.first) }

    /** स्क्रीन पर दिखाने के लिए: हर IP कब यूज़ हुआ और कब दोबारा चल सकेगा */
    fun text(ctx: Context): String {
        val l = recent(ctx)
        if (l.isEmpty()) return "(अभी कोई IP यूज़ नहीं हुआ)" + countryText(ctx)
        val fmt = SimpleDateFormat("dd/MM HH:mm", Locale.getDefault())
        val now = System.currentTimeMillis()
        return l.reversed().joinToString("\n") {
            val left = (DAY - (now - it.second)) / 60000
            "${it.first}  — ${fmt.format(Date(it.second))} पर यूज़ · ${left / 60} घंटे ${left % 60} मिनट बाद फिर चल सकेगा"
        } + countryText(ctx)
    }

    private fun countryText(ctx: Context): String {
        val c = failedCountries(ctx)
        return if (c.isEmpty()) "" else "\n\nदेश-वार असफल कोशिश (5 पर वह देश छूटेगा):\n" + c.joinToString("\n") { "${it.first}: ${it.second}/$MAX_TRIES" }
    }
}
