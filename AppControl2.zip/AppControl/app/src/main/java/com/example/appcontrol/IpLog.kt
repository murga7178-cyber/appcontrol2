package com.example.appcontrol

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * VPN के नीचे वाले IP का हिसाब (ip_used.txt): हर लाइन  IP|पहली बार कब|कितनी कॉपी चलीं|कितनी बार फेल.
 *  - IP तब "बंद" (24 घंटे नहीं लेना) जब उस पर तय गिनती (डिफ़ॉल्ट 20) कॉपी चल चुकी हों, या 5 बार फेल हो चुका हो.
 *  - उससे कम कॉपी चली हों और 5 बार फेल न हुआ हो तो वही IP फिर लिया जा सकता है (बची हुई कॉपी उसी पर चलेंगी).
 *  - पहली बार से 24 घंटे बाद IP का हिसाब नया (सब चालू).
 */
object IpLog {
    private const val DAY = 24L * 60 * 60 * 1000
    const val MAX_TRIES = 5
    private fun f(ctx: Context) = File(ctx.filesDir, "ip_used.txt")

    data class Rec(val ip: String, val first: Long, val copies: Int, val fails: Int)

    private fun every(ctx: Context) = maxOf(1, ctx.getSharedPreferences("apps", Context.MODE_PRIVATE).getInt("ipEvery", 20))

    private fun all(ctx: Context): List<Rec> = try {
        if (!f(ctx).exists()) emptyList()
        else f(ctx).readLines().mapNotNull { l ->
            val p = l.split("|")
            val ms = p.getOrNull(1)?.trim()?.toLongOrNull()
            if (p[0].isBlank() || ms == null) null
            else Rec(p[0].trim(), ms, p.getOrNull(2)?.trim()?.toIntOrNull() ?: 9999, p.getOrNull(3)?.trim()?.toIntOrNull() ?: 0)   // पुरानी लाइन (बिना गिनती) = पूरी तरह इस्तेमाल मानो
        }
    } catch (e: Exception) { emptyList() }

    private fun save(ctx: Context, l: List<Rec>) {
        val now = System.currentTimeMillis()
        val keep = l.filter { now - it.first < 2 * DAY }
        try { f(ctx).writeText(keep.joinToString("\n") { "${it.ip}|${it.first}|${it.copies}|${it.fails}" } + "\n") } catch (e: Exception) {}
    }

    private fun live(ctx: Context): List<Rec> {
        val now = System.currentTimeMillis()
        return all(ctx).filter { now - it.first < DAY }
    }

    /** यह IP अभी (24 घंटे में) नहीं लेना है? */
    fun isBlocked(ctx: Context, ip: String): Boolean {
        val r = live(ctx).firstOrNull { it.ip == ip } ?: return false
        return r.copies >= every(ctx) || r.fails >= MAX_TRIES
    }

    /** इस IP का हिसाब 24 घंटे के भीतर पहले से दर्ज है (पहले चल चुका, चाहे बंद न हुआ हो)? */
    fun isKnown(ctx: Context, ip: String): Boolean = live(ctx).any { it.ip == ip }

    /** यह IP अब चलेगा: हिसाब न हो (या 24 घंटे पुराना हो) तो नया बनाओ. लौटाता है इस IP पर अब तक चली कॉपी की गिनती */
    fun activate(ctx: Context, ip: String): Int {
        val now = System.currentTimeMillis()
        val l = all(ctx).toMutableList()
        val i = l.indexOfFirst { it.ip == ip }
        if (i >= 0 && now - l[i].first < DAY) return l[i].copies
        if (i >= 0) l.removeAt(i)
        l.add(Rec(ip, now, 0, 0))
        save(ctx, l)
        return 0
    }

    private fun update(ctx: Context, ip: String, fn: (Rec) -> Rec) {
        if (ip.isBlank()) return
        val l = all(ctx).toMutableList()
        val i = l.indexOfFirst { it.ip == ip && System.currentTimeMillis() - it.first < DAY }
        if (i < 0) return
        l[i] = fn(l[i]); save(ctx, l)
    }
    fun addCopy(ctx: Context, ip: String) = update(ctx, ip) { it.copy(copies = it.copies + 1) }
    fun addFail(ctx: Context, ip: String) = update(ctx, ip) { it.copy(fails = it.fails + 1) }

    fun clear(ctx: Context) {
        try { f(ctx).delete() } catch (e: Exception) {}
        try { cf(ctx).delete() } catch (e: Exception) {}
    }

    // ---- देश-वार असफल कोशिशें: किसी देश में बंद IP दोबारा मिला = 1 असफल कोशिश. 5 हो जाएँ तो वह देश 24 घंटे के लिए छोड़ो; 24 घंटे बाद सब गिनती नई ----
    private fun cf(ctx: Context) = File(ctx.filesDir, "ip_country_fails.txt")
    private fun failMap(ctx: Context): MutableMap<String, Pair<Int, Long>> {
        val m = LinkedHashMap<String, Pair<Int, Long>>()
        val now = System.currentTimeMillis()
        try {
            if (cf(ctx).exists()) cf(ctx).readLines().forEach { l ->
                val p = l.split("|")
                val n = p.getOrNull(1)?.toIntOrNull(); val t = p.getOrNull(2)?.toLongOrNull()
                if (p[0].isNotBlank() && n != null && t != null && now - t < DAY) m[p[0]] = Pair(n, t)
            }
        } catch (e: Exception) {}
        return m
    }
    fun countryFails(ctx: Context, name: String): Int = failMap(ctx)[name.lowercase().trim()]?.first ?: 0
    fun addCountryFail(ctx: Context, name: String) {
        val k = name.lowercase().trim(); if (k.isEmpty()) return
        val m = failMap(ctx)
        val old = m[k]
        m[k] = Pair((old?.first ?: 0) + 1, old?.second ?: System.currentTimeMillis())
        try { cf(ctx).writeText(m.entries.joinToString("\n") { "${it.key}|${it.value.first}|${it.value.second}" } + "\n") } catch (e: Exception) {}
    }
    fun failedCountries(ctx: Context): List<Pair<String, Int>> = failMap(ctx).map { Pair(it.key, it.value.first) }

    /** स्क्रीन पर दिखाने के लिए */
    fun text(ctx: Context): String {
        val l = live(ctx)
        val ev = every(ctx)
        val fmt = SimpleDateFormat("dd/MM HH:mm", Locale.getDefault())
        val now = System.currentTimeMillis()
        val head = if (l.isEmpty()) "(अभी कोई IP दर्ज नहीं)" else l.reversed().joinToString("\n") {
            val left = (DAY - (now - it.first)) / 60000
            val blocked = it.copies >= ev || it.fails >= MAX_TRIES
            "${it.ip}  — ${fmt.format(Date(it.first))} · कॉपी ${if (it.copies > 9000) "पूरी" else "${it.copies}/$ev"} · फेल ${it.fails}/$MAX_TRIES · " +
                (if (blocked) "🚫 ${left / 60} घंटे ${left % 60} मिनट बाद फिर चलेगा" else "✔ अभी चल सकता है")
        }
        return head + countryText(ctx)
    }

    private fun countryText(ctx: Context): String {
        val c = failedCountries(ctx)
        return if (c.isEmpty()) "" else "\n\nदेश-वार असफल कोशिश (5 पर वह देश छूटेगा, 24 घंटे में सब नई):\n" + c.joinToString("\n") { "${it.first}: ${it.second}/$MAX_TRIES" }
    }
}
