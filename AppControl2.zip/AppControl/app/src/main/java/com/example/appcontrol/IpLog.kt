package com.example.appcontrol

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** VPN के नीचे वाले जो IP यूज़ हो चुके उनकी फाइल (ip_used.txt): हर लाइन  IP|समय.  24 घंटे तक वही IP दोबारा नहीं लेना */
object IpLog {
    private const val DAY = 24L * 60 * 60 * 1000
    private fun f(ctx: Context) = File(ctx.filesDir, "ip_used.txt")

    private fun all(ctx: Context): List<Pair<String, Long>> = try {
        if (!f(ctx).exists()) emptyList()
        else f(ctx).readLines().mapNotNull { l ->
            val p = l.split("|")
            val ms = p.getOrNull(1)?.trim()?.toLongOrNull()
            if (p[0].isBlank() || ms == null) null else Pair(p[0].trim(), ms)
        }
    } catch (e: Exception) { emptyList() }

    /** पिछले 24 घंटे में यूज़ हुए IP (पुराने से नए) */
    fun recent(ctx: Context): List<Pair<String, Long>> {
        val now = System.currentTimeMillis()
        return all(ctx).filter { now - it.second < DAY }
    }

    fun isUsed(ctx: Context, ip: String): Boolean = recent(ctx).any { it.first == ip }

    /** IP यूज़ हुआ लिखो (पहले से 24 घंटे में लिखा हो तो पहला समय ही रहेगा) */
    fun record(ctx: Context, ip: String) {
        if (isUsed(ctx, ip)) return
        val now = System.currentTimeMillis()
        val keep = all(ctx).filter { now - it.second < 2 * DAY }
        try {
            f(ctx).writeText((keep + Pair(ip, now)).joinToString("\n") { "${it.first}|${it.second}" } + "\n")
        } catch (e: Exception) {}
    }

    fun clear(ctx: Context) { try { f(ctx).delete() } catch (e: Exception) {} }

    /** स्क्रीन पर दिखाने के लिए: हर IP कब यूज़ हुआ और कब दोबारा चल सकेगा */
    fun text(ctx: Context): String {
        val l = recent(ctx)
        if (l.isEmpty()) return "(अभी कोई IP यूज़ नहीं हुआ)"
        val fmt = SimpleDateFormat("dd/MM HH:mm", Locale.getDefault())
        val now = System.currentTimeMillis()
        return l.reversed().joinToString("\n") {
            val left = (DAY - (now - it.second)) / 60000
            "${it.first}  — ${fmt.format(Date(it.second))} पर यूज़ · ${left / 60} घंटे ${left % 60} मिनट बाद फिर चल सकेगा"
        }
    }
}
