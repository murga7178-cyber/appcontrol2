package com.example.appcontrol

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * VPN के नीचे वाले IP का हिसाब (ip_used.txt): हर लाइन  IP|पहली बार कब|कितनी कॉपी चलीं|कितनी बार फेल|पहला फेल कब.
 *  - कॉपी की गिनती का 24 घंटे IP पहली बार चलने से; फेल की गिनती का 24 घंटे पहला फेल (1/3) लिखते ही से चालू.
 *  - IP तब "बंद" जब उस पर तय गिनती (डिफ़ॉल्ट 20) कॉपी चल चुकी हों, या 3 बार फेल हो चुका हो. 24 घंटे बाद वह गिनती नई, IP फिर चालू.
 *  - उससे कम कॉपी चली हों और 3 बार फेल न हुआ हो तो वही IP फिर लिया जा सकता है.
 *  - देश-वार असफल गिनती का 24 घंटे भी पहली असफल कोशिश (1/3) से चालू.
 */
object IpLog {
    private const val DAY = 24L * 60 * 60 * 1000
    const val MAX_TRIES = 3
    private fun f(ctx: Context) = File(ctx.filesDir, "ip_used.txt")

    data class Rec(val ip: String, val first: Long, val copies: Int, val fails: Int, val ff: Long)

    private fun every(ctx: Context) = maxOf(1, ctx.getSharedPreferences("apps", Context.MODE_PRIVATE).getInt("ipEvery", 20))

    /** समय बीतने के हिसाब से गिनती नई: कॉपी की गिनती पहली बार से 24 घंटे बाद, फेल की गिनती पहले फेल से 24 घंटे बाद */
    private fun norm(r: Rec, now: Long): Rec {
        var x = r
        if (now - x.first >= DAY) x = x.copy(copies = 0)
        if (x.fails > 0 && x.ff > 0 && now - x.ff >= DAY) x = x.copy(fails = 0, ff = 0L)
        return x
    }

    private fun alive(r: Rec, now: Long): Boolean = now - r.first < DAY || r.fails > 0

    private fun all(ctx: Context): List<Rec> = try {
        if (!f(ctx).exists()) emptyList()
        else f(ctx).readLines().mapNotNull { l ->
            val p = l.split("|")
            val ms = p.getOrNull(1)?.trim()?.toLongOrNull()
            if (p[0].isBlank() || ms == null) null
            else {
                val fails = p.getOrNull(3)?.trim()?.toIntOrNull() ?: 0
                Rec(p[0].trim(), ms, p.getOrNull(2)?.trim()?.toIntOrNull() ?: 9999, fails,
                    p.getOrNull(4)?.trim()?.toLongOrNull() ?: (if (fails > 0) ms else 0L))        // पुरानी लाइन (बिना गिनती) = पूरी तरह इस्तेमाल मानो
            }
        }
    } catch (e: Exception) { emptyList() }

    private fun save(ctx: Context, l: List<Rec>) {
        val now = System.currentTimeMillis()
        val keep = l.map { norm(it, now) }.filter { alive(it, now) }
        try { f(ctx).writeText(keep.joinToString("\n") { "${it.ip}|${it.first}|${it.copies}|${it.fails}|${it.ff}" } + "\n") } catch (e: Exception) {}
    }

    private fun live(ctx: Context): List<Rec> {
        val now = System.currentTimeMillis()
        return all(ctx).map { norm(it, now) }.filter { alive(it, now) }
    }

    /** अभी (24 घंटे में) दर्ज सारे IP, नए पहले */
    fun recs(ctx: Context): List<Rec> = live(ctx).sortedByDescending { it.first }
    fun threshold(ctx: Context): Int = every(ctx)
    fun isBlockedRec(ctx: Context, r: Rec): Boolean = r.copies >= every(ctx) || r.fails >= MAX_TRIES
    fun leftText(since: Long): String = left(since)
    fun countriesText(ctx: Context): String = countryText(ctx).trim()
    fun countryCount(ctx: Context): Int = failedCountries(ctx).size

    /** यह IP अभी (24 घंटे में) नहीं लेना है? */
    fun isBlocked(ctx: Context, ip: String): Boolean {
        val r = live(ctx).firstOrNull { it.ip == ip } ?: return false
        return r.copies >= every(ctx) || r.fails >= MAX_TRIES
    }

    /** इस IP का हिसाब 24 घंटे के भीतर पहले से दर्ज है (पहले चल चुका, चाहे बंद न हुआ हो)? */
    /** सिर्फ़ तब "पहले चल चुका" जब उस पर सच में कॉपी चली हो, फेल हुआ हो या नंबर दर्ज हों. सिर्फ़ पढ़ा गया IP (0 कॉपी, 0 फेल) पुराना नहीं गिना जाता */
    fun isKnown(ctx: Context, ip: String): Boolean =
        live(ctx).any { it.ip == ip && (it.copies > 0 || it.fails > 0 || IpNum.numbersFor(ctx, ip).isNotEmpty()) }

    /** यह IP अब चलेगा: हिसाब न हो तो नया बनाओ (24 घंटे अभी से चालू). लौटाता है इस IP पर अब तक चली कॉपी की गिनती */
    fun activate(ctx: Context, ip: String): Int {
        val now = System.currentTimeMillis()
        val l = all(ctx).map { norm(it, now) }.toMutableList()
        val i = l.indexOfFirst { it.ip == ip }
        if (i >= 0) {
            if (now - l[i].first >= DAY) { l[i] = l[i].copy(first = now, copies = 0); save(ctx, l) }
            return l[i].copies
        }
        l.add(Rec(ip, now, 0, 0, 0L))
        save(ctx, l)
        return 0
    }

    private fun update(ctx: Context, ip: String, fn: (Rec) -> Rec) {
        if (ip.isBlank()) return
        val now = System.currentTimeMillis()
        val l = all(ctx).map { norm(it, now) }.toMutableList()
        val i = l.indexOfFirst { it.ip == ip }
        if (i < 0) return
        var r = l[i]
        if (now - r.first >= DAY) r = r.copy(first = now, copies = 0)
        l[i] = fn(r); save(ctx, l)
    }
    fun addCopy(ctx: Context, ip: String) = update(ctx, ip) { it.copy(copies = it.copies + 1) }
    /** फेल: पहला फेल (1/3) लिखते ही उसके 24 घंटे चालू */
    fun addFail(ctx: Context, ip: String) = update(ctx, ip) { it.copy(fails = it.fails + 1, ff = if (it.fails == 0) System.currentTimeMillis() else it.ff) }

    fun clear(ctx: Context) {
        try { f(ctx).delete() } catch (e: Exception) {}
        try { cf(ctx).delete() } catch (e: Exception) {}
        IpNum.clear(ctx)
    }

    // ---- देश-वार असफल कोशिशें: किसी देश में बंद/पहले चला IP दोबारा मिला = 1 असफल कोशिश. पहली (1/3) से 24 घंटे चालू; 3 हो जाएँ तो वह देश 24 घंटे छोड़ो ----
    private fun cf(ctx: Context) = File(ctx.filesDir, "ip_country_fails.txt")
    private fun failMap(ctx: Context): MutableMap<String, Pair<Int, Long>> {
        val m = LinkedHashMap<String, Pair<Int, Long>>()
        val now = System.currentTimeMillis()
        try {
            if (cf(ctx).exists()) cf(ctx).readLines().forEach { l ->
                val p = l.split("|")
                val n = p.getOrNull(1)?.toIntOrNull(); val t = p.getOrNull(2)?.toLongOrNull()
                if (p[0].isNotBlank() && n != null && t != null && now - t < DAY) m[p[0]] = Pair(n, t)     // पहली असफल कोशिश से 24 घंटे बाद गिनती नई
            }
        } catch (e: Exception) {}
        return m
    }
    fun countryFails(ctx: Context, name: String): Int = failMap(ctx)[name.lowercase().trim()]?.first ?: 0
    fun addCountryFail(ctx: Context, name: String) {
        val k = name.lowercase().trim(); if (k.isEmpty()) return
        val m = failMap(ctx)
        val old = m[k]
        m[k] = Pair((old?.first ?: 0) + 1, old?.second ?: System.currentTimeMillis())      // पहली बार: अभी से 24 घंटे गिनो
        try { cf(ctx).writeText(m.entries.joinToString("\n") { "${it.key}|${it.value.first}|${it.value.second}" } + "\n") } catch (e: Exception) {}
    }
    fun failedCountries(ctx: Context): List<Triple<String, Int, Long>> = failMap(ctx).map { Triple(it.key, it.value.first, it.value.second) }

    private fun left(since: Long): String {
        val m = (DAY - (System.currentTimeMillis() - since)) / 60000
        return "${m / 60} घंटे ${m % 60} मिनट"
    }

    /** स्क्रीन पर दिखाने के लिए */
    fun text(ctx: Context): String {
        val l = live(ctx)
        val ev = every(ctx)
        val fmt = SimpleDateFormat("dd/MM HH:mm", Locale.getDefault())
        val head = if (l.isEmpty()) "(अभी कोई IP दर्ज नहीं)" else l.reversed().joinToString("\n") {
            val blocked = it.copies >= ev || it.fails >= MAX_TRIES
            "${it.ip}  — ${fmt.format(Date(it.first))} · कॉपी ${if (it.copies > 9000) "पूरी" else "${it.copies}/$ev"} · फेल ${it.fails}/$MAX_TRIES" +
                (if (it.fails > 0 && it.ff > 0) " (फेल की गिनती ${left(it.ff)} में नई)" else "") + " · " +
                (if (blocked) "🚫 बंद" else "✔ अभी चल सकता है")
        }
        return head + countryText(ctx) + IpNum.text(ctx)
    }

    private fun countryText(ctx: Context): String {
        val c = failedCountries(ctx)
        return if (c.isEmpty()) "" else "\n\nदेश-वार असफल कोशिश (पहले सब देश आज़माए जाते हैं; $MAX_TRIES पर वह देश छूटेगा; पहली गिनती से 24 घंटे में नई):\n" +
            c.joinToString("\n") { "${it.first}: ${it.second}/$MAX_TRIES · ${left(it.third)} में नई" }
    }
}

/**
 * किस IP पर कौन-सा नंबर (कॉपी) खुला: ip_numbers.txt, हर लाइन  कमांड-चाबी|IP|नंबर|समय.  48 घंटे (2 दिन) का रिकॉर्ड.
 * अगले दिन वही IP पढ़ा जाए तो वही नंबर उसी IP पर खोले जाते हैं.
 */
object IpNum {
    private const val KEEP = 48L * 60 * 60 * 1000
    private fun f(ctx: Context) = File(ctx.filesDir, "ip_numbers.txt")

    data class E(val key: String, val ip: String, val n: Int, val t: Long)

    private fun all(ctx: Context): List<E> = try {
        if (!f(ctx).exists()) emptyList()
        else f(ctx).readLines().mapNotNull { l ->
            val p = l.split("|")
            val n = p.getOrNull(2)?.toIntOrNull(); val t = p.getOrNull(3)?.toLongOrNull()
            if (p.size < 4 || n == null || t == null || p[1].isBlank()) null else E(p[0], p[1], n, t)
        }
    } catch (e: Exception) { emptyList() }

    private fun live(ctx: Context): List<E> {
        val now = System.currentTimeMillis()
        return all(ctx).filter { now - it.t < KEEP }
    }

    /** नंबर n इस IP पर खुला: पुराना रिकॉर्ड (किसी और IP पर) हटाकर नया लिखो */
    fun record(ctx: Context, key: String, ip: String, n: Int) {
        if (ip.isBlank()) return
        val l = live(ctx).filter { !(it.key == key && it.n == n) }.toMutableList()
        l.add(E(key, ip, n, System.currentTimeMillis()))
        try { f(ctx).writeText(l.joinToString("\n") { "${it.key}|${it.ip}|${it.n}|${it.t}" } + "\n") } catch (e: Exception) {}
    }

    /** इस कमांड के हर नंबर का IP (48 घंटे के भीतर) */
    fun map(ctx: Context, key: String): Map<Int, String> {
        val m = HashMap<Int, String>()
        for (e in live(ctx)) if (e.key == key) m[e.n] = e.ip
        return m
    }

    fun clear(ctx: Context) { try { f(ctx).delete() } catch (e: Exception) {}; try { cc(ctx).delete() } catch (e: Exception) {} }

    // ---- IP किस देश का था (VPN में जो देश चुना हुआ था): उसी देश को पहले चुनो तो वही IP आने की संभावना ----
    private fun cc(ctx: Context) = File(ctx.filesDir, "ip_country.txt")
    private fun countryAll(ctx: Context): List<Triple<String, String, Long>> = try {
        val now = System.currentTimeMillis()
        if (!cc(ctx).exists()) emptyList()
        else cc(ctx).readLines().mapNotNull { l ->
            val p = l.split("|"); val t = p.getOrNull(2)?.toLongOrNull()
            if (p.size < 3 || t == null || now - t > KEEP) null else Triple(p[0], p[1], t)
        }
    } catch (e: Exception) { emptyList() }

    fun setCountry(ctx: Context, ip: String, country: String) {
        if (ip.isBlank() || country.isBlank()) return
        val l = countryAll(ctx).filter { it.first != ip }.toMutableList()
        l.add(Triple(ip, country.lowercase().trim(), System.currentTimeMillis()))
        try { cc(ctx).writeText(l.joinToString("\n") { "${it.first}|${it.second}|${it.third}" } + "\n") } catch (e: Exception) {}
    }
    fun countryOf(ctx: Context, ip: String): String = countryAll(ctx).firstOrNull { it.first == ip }?.second ?: ""

    fun numbersFor(ctx: Context, ip: String): List<Int> = live(ctx).filter { it.ip == ip }.map { it.n }.distinct().sorted()

    /** इस IP पर चले (कमांड-चाबी, नंबर) जोड़े */
    fun entriesFor(ctx: Context, ip: String): List<Pair<String, Int>> = live(ctx).filter { it.ip == ip }.map { Pair(it.key, it.n) }.distinct().sortedBy { it.second }

    /** इस कमांड के सारे नंबर-बंधन हटाओ (गिनती रीसेट) */
    fun clearKey(ctx: Context, key: String) {
        val l = live(ctx)
        try { f(ctx).writeText(l.filter { it.key != key }.joinToString("\n") { "${it.key}|${it.ip}|${it.n}|${it.t}" } + "\n") } catch (e: Exception) {}
    }

    /** हर IP → देश (48 घंटे) */
    fun countryMap(ctx: Context): Map<String, String> = countryAll(ctx).associate { it.first to it.second }

    /** जिन IP का नंबर या देश दर्ज है उन सबकी सूची */
    fun allIps(ctx: Context): List<String> = (live(ctx).map { it.ip } + countryAll(ctx).map { it.first }).distinct()

    /** नंबर n का बंधन हटाओ (वह फेल हुआ: अब किसी भी देश/IP पर चल सकेगा और नए पर दर्ज होगा) */
    fun forget(ctx: Context, key: String, n: Int) {
        val l = live(ctx)
        val keep = l.filter { !(it.key == key && it.n == n) }
        if (keep.size == l.size) return
        try { f(ctx).writeText(keep.joinToString("\n") { "${it.key}|${it.ip}|${it.n}|${it.t}" } + "\n") } catch (e: Exception) {}
    }

    fun text(ctx: Context): String {
        val l = live(ctx)
        if (l.isEmpty()) return ""
        val by = l.groupBy { it.ip }
        return "\n\nIP पर खुले नंबर (48 घंटे; अगले दिन वही IP आए तो वही नंबर):\n" +
            by.entries.joinToString("\n") { en -> "${en.key}: " + en.value.map { it.n }.sorted().joinToString(", ") }
    }
}
