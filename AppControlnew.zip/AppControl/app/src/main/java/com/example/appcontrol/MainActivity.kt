package com.example.appcontrol

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import java.io.File
import java.io.FileOutputStream
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {

    private val prefs by lazy { getSharedPreferences("apps", Context.MODE_PRIVATE) }
    private lateinit var appList: ListView
    private lateinit var stepList: ListView

    private fun savedApps(): MutableList<String> =
        prefs.getString("pkgs", "")!!.split("\n").filter { it.isNotBlank() }.toMutableList()
    private fun saveApps(l: List<String>) = prefs.edit().putString("pkgs", l.joinToString("\n")).apply()

    private fun savedSteps(): MutableList<String> =
        prefs.getString("steps", "")!!.split("\n").filter { it.isNotBlank() }.toMutableList()
    private fun saveSteps(l: List<String>) = prefs.edit().putString("steps", l.joinToString("\n")).apply()

    private fun label(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) { pkg }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 64, 32, 32)
        }
        root.addView(Button(this).apply {
            text = "Accessibility चालू करें"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })

        // ---- कमांड (स्टेप) ----
        root.addView(TextView(this).apply {
            text = "कमांड (क्रम से) — लंबा दबाकर हटाएँ"; textSize = 18f; setTextColor(Color.BLACK)
        })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val input = EditText(this).apply { hint = "बटन का टेक्स्ट, जैसे: Cancel" }
        row.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(Button(this).apply {
            text = "जोड़ें"
            setOnClickListener {
                val t = input.text.toString().trim()
                if (t.isNotEmpty()) {
                    val s = savedSteps(); s.add(t); saveSteps(s)
                    input.setText(""); refresh()
                }
            }
        })
        root.addView(row)
        if (Build.VERSION.SDK_INT < 30) {   // Android 10 के लिए
            root.addView(Button(this).apply {
                text = "स्क्रीन कैप्चर अनुमति दें (Android 10, फोटो कमांड के लिए)"
                setOnClickListener {
                    val m = getSystemService(MediaProjectionManager::class.java)
                    startActivityForResult(m.createScreenCaptureIntent(), 88)
                }
            })
        }
        root.addView(Button(this).apply {
            text = "🖼 फोटो कमांड जोड़ें (जैसे क्रॉस का फोटो)"
            setOnClickListener {
                startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }, 77)
            }
        })
        stepList = ListView(this)
        root.addView(stepList, LinearLayout.LayoutParams(-1, 0, 1f))

        // ---- ऐप ----
        root.addView(TextView(this).apply {
            text = "ऐप (टैप करने पर खुलेगा और कमांड चलेंगे)"; textSize = 18f; setTextColor(Color.BLACK)
        })
        appList = ListView(this)
        root.addView(appList, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(Button(this).apply {
            text = "+"; textSize = 28f
            setOnClickListener { showAllApps() }
        }, LinearLayout.LayoutParams(-1, -2).apply { gravity = Gravity.END })

        setContentView(root)
        refresh()
    }

    private fun refresh() {
        val steps = savedSteps()
        stepList.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1,
            steps.mapIndexed { i, s -> "कमांड ${i + 1}:  ${show(s)}" })
        stepList.setOnItemLongClickListener { _, _, i, _ ->
            val s = savedSteps(); s.removeAt(i); saveSteps(s); refresh(); true
        }

        val pkgs = savedApps()
        appList.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, pkgs.map { label(it) })
        appList.setOnItemClickListener { _, _, i, _ -> launch(pkgs[i]) }
        appList.setOnItemLongClickListener { _, _, i, _ ->
            val s = savedApps(); s.removeAt(i); saveApps(s); refresh(); true
        }
    }

    private fun show(s: String) = when {
        s.startsWith("IMG:opt:") -> "🖼 फोटो (वैकल्पिक)"
        s.startsWith("IMG:req:") -> "🖼 फोटो (ज़रूरी)"
        else -> s
    }

    private fun addStep(s: String) { val l = savedSteps(); l.add(s); saveSteps(l); refresh() }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 88 && res == RESULT_OK && data != null) {
            startForegroundService(Intent(this, CaptureService::class.java)
                .putExtra("code", res).putExtra("data", data))
            return
        }
        if (req != 77 || res != RESULT_OK) return
        val uri = data?.data ?: return
        val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } ?: return
        val name = "step_${System.currentTimeMillis()}.png"
        FileOutputStream(File(filesDir, name)).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        AlertDialog.Builder(this)
            .setTitle("यह फोटो स्क्रीन पर न मिले तो?")
            .setPositiveButton("खोजते रहो (ज़रूरी)") { _, _ -> addStep("IMG:req:$name") }
            .setNegativeButton("छोड़कर आगे बढ़ो (वैकल्पिक)") { _, _ -> addStep("IMG:opt:$name") }
            .show()
    }

    private fun launch(pkg: String) {
        val svc = ControlService.instance
        if (svc == null) {
            Toast.makeText(this, "पहले Accessibility चालू करें", Toast.LENGTH_LONG).show(); return
        }
        val intent = packageManager.getLaunchIntentForPackage(pkg) ?: return
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        svc.startSequence(savedSteps())
        startActivity(intent)
    }

    private fun showAllApps() {
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = packageManager.queryIntentActivities(main, 0)
            .map { it.activityInfo.packageName to it.loadLabel(packageManager).toString() }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }
        AlertDialog.Builder(this)
            .setTitle("ऐप चुनें")
            .setItems(apps.map { it.second }.toTypedArray()) { _, i ->
                val s = savedApps(); s.add(apps[i].first); saveApps(s); refresh()
            }.show()
    }
}
