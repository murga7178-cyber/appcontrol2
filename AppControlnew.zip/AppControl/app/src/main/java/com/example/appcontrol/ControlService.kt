package com.example.appcontrol

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Path
import android.os.Build
import android.view.Display
import java.io.File
import java.util.concurrent.Executors
import kotlin.math.abs
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.TextView
import android.widget.Toast

class ControlService : AccessibilityService() {

    companion object { var instance: ControlService? = null }

    private val handler = Handler(Looper.getMainLooper())
    private var steps: List<String> = emptyList()
    private var index = 0
    private var running = false
    private var badge: TextView? = null
    private var stepStart = 0L
    private val bg = Executors.newSingleThreadExecutor()
    private var busy = false
    private val tplCache = HashMap<String, Bitmap?>()

    override fun onServiceConnected() { instance = this }

    /** कमांड 1, 2, 3... क्रम से चलाना शुरू */
    fun startSequence(list: List<String>) {
        stop()
        if (list.isEmpty()) { toast("कोई कमांड नहीं जोड़ी"); return }
        steps = list; index = 0; running = true
        stepStart = System.currentTimeMillis() + 1500
        showBadge()
        handler.postDelayed(tick, 1500) // ऐप खुलने का इंतज़ार
    }

    private fun stop() {
        running = false
        handler.removeCallbacksAndMessages(null)
        badge?.let { try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } catch (_: Exception) {} }
        badge = null
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            val cmd = steps[index]
            val isImg = cmd.startsWith("IMG:")
            val optional = isCross(cmd) || cmd.startsWith("IMG:opt:")
            // वैकल्पिक कमांड ~4 सेकंड में न मिले तो आगे बढ़ जाओ
            if (optional && !busy && System.currentTimeMillis() - stepStart > 4000) {
                if (!advance()) return
                handler.postDelayed(this, 600); return
            }
            val root = rootInActiveWindow
            // हमारे अपने ऐप की स्क्रीन पर नहीं खोजना
            if (root != null && root.packageName != packageName) {
                if (isImg) {
                    if (!busy) findAndTapImage(cmd)
                    handler.postDelayed(this, 1000); return
                }
                val node = if (isCross(cmd)) findCross(root) else findNode(root, cmd)
                if (node != null && clickNode(node)) {
                    if (!advance()) return
                    handler.postDelayed(this, 1200) // अगली स्क्रीन का इंतज़ार
                    return
                }
            }
            handler.postDelayed(this, 600) // मिला नहीं तो खोजते रहो
        }
    }

    // ---------- फोटो से खोजना ----------
    private fun loadTemplate(name: String): Bitmap? = tplCache.getOrPut(name) {
        BitmapFactory.decodeFile(File(filesDir, name).path)
    }

    private fun findAndTapImage(cmd: String) {
        val tpl = loadTemplate(cmd.substringAfterLast(":")) ?: return
        val my = index
        if (Build.VERSION.SDK_INT >= 30) {
            busy = true
            shotApi30 { bmp -> finishMatch(bmp, tpl, my) }
        } else {
            val cs = CaptureService.instance
            if (cs == null) {
                if (System.currentTimeMillis() % 5 == 0L) toast("मुख्य ऐप में 'स्क्रीन कैप्चर अनुमति' दें")
                return
            }
            busy = true
            bg.execute { finishMatch(cs.capture(), tpl, my) }
        }
    }

    @android.annotation.TargetApi(30)
    private fun shotApi30(done: (Bitmap?) -> Unit) {
        takeScreenshot(Display.DEFAULT_DISPLAY, bg, object : AccessibilityService.TakeScreenshotCallback {
            override fun onSuccess(r: AccessibilityService.ScreenshotResult) {
                val hb = r.hardwareBuffer
                val bmp = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)?.copy(Bitmap.Config.ARGB_8888, false)
                hb.close()
                done(bmp)
            }
            override fun onFailure(code: Int) { done(null) }
        })
    }

    /** (bg थ्रेड पर) मिलान करो, फिर मुख्य थ्रेड पर टैप */
    private fun finishMatch(bmp: Bitmap?, tpl: Bitmap, my: Int) {
        val pos = if (bmp != null) match(bmp, tpl) else null
        handler.post {
            if (!running || index != my || pos == null) { busy = false; return@post }
            val path = Path().apply { moveTo(pos.first.toFloat(), pos.second.toFloat()) }
            val g = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 60)).build()
            val ok = dispatchGesture(g, object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(d: GestureDescription?) {
                    busy = false
                    if (running && index == my && advance()) {
                        handler.removeCallbacks(tick); handler.postDelayed(tick, 1200)
                    }
                }
                override fun onCancelled(d: GestureDescription?) { busy = false }
            }, null)
            if (!ok) busy = false
        }
    }

    private fun gray(b: Bitmap, w: Int, h: Int): IntArray {
        val px = IntArray(w * h)
        b.getPixels(px, 0, w, 0, 0, w, h)
        for (i in px.indices) {
            val c = px[i]
            px[i] = (((c shr 16) and 255) * 3 + ((c shr 8) and 255) * 6 + (c and 255)) / 10
        }
        return px
    }

    /** स्क्रीनशॉट में फोटो की सबसे मिलती जगह (केंद्र x, y) या null */
    private fun match(scr: Bitmap, tpl: Bitmap): Pair<Int, Int>? {
        val f = 2                       // तेज़ी के लिए आधा आकार
        val sw = scr.width / f; val sh = scr.height / f
        val tw = tpl.width / f; val th = tpl.height / f
        if (tw < 4 || th < 4 || tw > sw || th > sh) return null
        val S = gray(Bitmap.createScaledBitmap(scr, sw, sh, true), sw, sh)
        val T = gray(Bitmap.createScaledBitmap(tpl, tw, th, true), tw, th)
        var best = Long.MAX_VALUE; var bx = -1; var by = -1
        var y = 0
        while (y <= sh - th) {
            var x = 0
            while (x <= sw - tw) {
                var sum = 0L
                for (ty in 0 until th) {
                    val so = (y + ty) * sw + x; val to = ty * tw
                    for (tx in 0 until tw) sum += abs(S[so + tx] - T[to + tx])
                    if (sum >= best) break
                }
                if (sum < best) { best = sum; bx = x; by = y }
                x += 2
            }
            y += 2
        }
        val avg = best.toDouble() / (tw * th)
        return if (avg < 15.0) Pair((bx + tw / 2) * f, (by + th / 2) * f) else null
    }

    /** अगली कमांड पर जाओ; सब पूरी हों तो false */
    private fun advance(): Boolean {
        index++
        if (index >= steps.size) { finish(); return false }
        stepStart = System.currentTimeMillis()
        updateBadge()
        return true
    }

    private fun isCross(cmd: String) = cmd.trim().lowercase() in
        setOf("क्रॉस", "cross", "x", "×", "close", "बंद")

    // क्रॉस/बंद का निशान: टेक्स्ट ×, ✕, X या description/ID में close, dismiss आदि
    private fun findCross(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val marks = setOf("×", "✕", "✖", "✗", "╳", "x")
        val words = listOf("close", "dismiss", "cross", "बंद", "क्रॉस")
        val all = ArrayList<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            all.add(n)
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return all.firstOrNull { n ->
            val t = n.text?.toString()?.trim()?.lowercase()
            val d = n.contentDescription?.toString()?.trim()?.lowercase()
            val id = n.viewIdResourceName?.lowercase()
            (t != null && t in marks) || (d != null && d in marks) ||
            (d != null && words.any { d.contains(it) }) ||
            (id != null && words.any { id.contains(it) })
        }
    }

    private fun finish() {
        toast("सारी कमांड पूरी ✔")
        stop()
    }

    private fun clickNode(n: AccessibilityNodeInfo): Boolean {
        var x: AccessibilityNodeInfo? = n
        while (x != null && !x.isClickable) x = x.parent
        return x?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true
    }

    // पहले exact match, फिर contains (अंग्रेज़ी में बड़े-छोटे अक्षर का फ़र्क नहीं)
    private fun findNode(root: AccessibilityNodeInfo, target: String): AccessibilityNodeInfo? {
        val t = target.trim().lowercase()
        val all = ArrayList<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            all.add(n)
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        fun txt(n: AccessibilityNodeInfo) =
            (n.text ?: n.contentDescription)?.toString()?.trim()?.lowercase()
        return all.firstOrNull { txt(it) == t }
            ?: all.firstOrNull { val s = txt(it); s != null && s.contains(t) }
    }

    // छोटा बैज: कौन सी कमांड चल रही है; टैप करने पर रुक जाएगा
    private fun showBadge() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        badge = TextView(this).apply {
            textSize = 14f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                cornerRadius = 40f; setColor(Color.parseColor("#CC C62828".replace(" ", "")))
            }
            setPadding(24, 12, 24, 12)
            setOnClickListener { toast("रोक दिया"); stop() }
        }
        updateBadge()
        wm.addView(badge, WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; y = 120 })
    }

    private fun updateBadge() {
        badge?.text = "⏹ कमांड ${index + 1}/${steps.size}: ${steps[index]}"
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() { stop(); instance = null; super.onDestroy() }
}
